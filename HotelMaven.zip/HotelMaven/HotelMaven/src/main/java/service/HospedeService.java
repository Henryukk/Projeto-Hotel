/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import model.DAO.HospedeDAO;
import model.Hospede;

/**
 *
 * @author aluno
 */
public class HospedeService {

    public static void Criar(Hospede objeto) {
        
        HospedeDAO.getInstance().Create(objeto);
    }

    public static Hospede Carregar(int id) {
        return HospedeDAO.getInstance().Retrieve(id);
    }

    public static List<Hospede> Carregar(String atributo, String valor) {
         return HospedeDAO.getInstance().Retrieve(atributo, valor);
    }

    public static void Atualizar(Hospede objeto) {
         HospedeDAO.getInstance().Update(objeto);
    }

    public static void Apagar(Hospede objeto) {
         HospedeDAO.getInstance().Delete(objeto);
    }

    
}
