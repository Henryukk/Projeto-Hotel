package controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import model.Check;
import model.CheckHospede;
import model.CheckQuarto;
import model.Fornecedor;
import model.Funcionario;
import model.Hospede;
import model.Quarto;
import model.DAO.CheckDAO;
import view.TelaBuscaFornecedor;
import view.TelaBuscaFuncionario;
import view.TelaBuscaQuarto;
import view.TelaBuscasHospede;
import view.TelaMovimentos;

/**
 * Controller da TelaMovimentos.
 *
 * O botão BUSCAR é único em cada aba:
 *   - Check-In: exibe um menu "O que deseja buscar?" →
 *     Hóspede / Funcionário / Fornecedor / Quarto
 *   - Check-Out: abre diretamente a busca de Hóspede para
 *     localizar o Check-In ativo desse hóspede.
 *
 * Após a TelaBusca fechar, os campos são preenchidos automaticamente.
 */
public class ControllerMovimentos {

    // IDs retornados pelas telas de busca
    public static int codigoHospede = 0;
    public static int codigoQuarto  = 0;

    private final TelaMovimentos tela;
    private final CheckDAO checkDAO = CheckDAO.getInstance();

    public ControllerMovimentos(TelaMovimentos tela) {
        this.tela = tela;
        registrarListeners();
    }

    // =========================================================
    // LISTENERS
    // =========================================================
    private void registrarListeners() {

        // ABA CHECK-IN
        tela.getBtnBuscar1().addActionListener(e  -> abrirMenuBuscaCheckIn());
        tela.getBtnNovo1().addActionListener(e    -> limparCheckIn());
        tela.getBtnGravar1().addActionListener(e  -> gravarCheckIn());
        tela.getBtnCancelar1().addActionListener(e -> limparCheckIn());
        tela.getBtnSair1().addActionListener(e    -> tela.dispose());

        // ABA CHECK-OUT
        tela.getBtnBuscar().addActionListener(e   -> abrirBuscaHospedeCheckOut());
        tela.getBtnNovo().addActionListener(e     -> limparCheckOut());
        tela.getBtnGravar().addActionListener(e   -> gravarCheckOut());
        tela.getBtnCancelar().addActionListener(e -> limparCheckOut());
        tela.getBtnSair().addActionListener(e     -> tela.dispose());

        // Troca de aba carrega o check-out mais recente
        tela.getjTabbedPane1().addChangeListener(e -> {
            if (tela.getjTabbedPane1().getSelectedIndex() == 1) carregarCheckOut();
        });
    }

    // =========================================================
    // CHECK-IN: MENU DE BUSCA
    // =========================================================
    private void abrirMenuBuscaCheckIn() {
        String[] opcoes = {"Hospede", "Funcionario", "Fornecedor", "Quarto", "Veiculo"};
        int escolha = JOptionPane.showOptionDialog(
                tela,
                "O que deseja buscar?",
                "Buscar",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]);

        switch (escolha) {
            case 0:
                abrirBuscaHospede();
                break;
            case 1:
                abrirBuscaFuncionario();
                break;
            case 2:
                abrirBuscaFornecedor();
                break;
            case 3:
                abrirBuscaQuarto();
                break;
            case 4:
                abrirBuscaVeiculo();
                break;
            default:
                break;
        }
    }

    // ── Hóspede ───────────────────────────────────────────────────────────
    private void abrirBuscaHospede() {
        ControllerCadHospede.codigo = 0;
        TelaBuscasHospede telaBusca = new TelaBuscasHospede(null, true);
        new ControllerBuscaHospede(telaBusca);   // controller original com todos os filtros
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadHospede.codigo;  // lê o id que o controller original setou
        if (codigoHospede != 0) {
            Hospede h = service.HospedeService.Carregar(codigoHospede);
            if (h != null) preencherPessoaCheckIn(
                h.getNome(), h.getCpf(), h.getCnpj(),
                h.getContato(), h.getFone1(), h.getFone2(), "Hospede");
        }
    }

    // ── Funcionário ───────────────────────────────────────────────────────
    private void abrirBuscaFuncionario() {
        ControllerCadFuncionario.codigo = 0;
        TelaBuscaFuncionario telaBusca = new TelaBuscaFuncionario(null, true);
        new ControllerBuscaFuncionario(telaBusca);   // controller original com todos os filtros
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadFuncionario.codigo;
        if (codigoHospede != 0) {
            Funcionario f = service.FuncionarioService.Carregar(codigoHospede);
            if (f != null) preencherPessoaCheckIn(
                f.getNome(), f.getCpf(), "",
                "", f.getFone1(), f.getFone2(), "Funcionario");
        }
    }

    // ── Fornecedor ────────────────────────────────────────────────────────
    private void abrirBuscaFornecedor() {
        ControllerCadFornecedor.codigo = 0;
        TelaBuscaFornecedor telaBusca = new TelaBuscaFornecedor(null, true);
        new ControllerBuscaFornecedor(telaBusca);   // controller original com todos os filtros
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadFornecedor.codigo;
        if (codigoHospede != 0) {
            Fornecedor f = service.FornecedorService.Carregar(codigoHospede);
            if (f != null) preencherPessoaCheckIn(
                f.getNome(), f.getCpf(), f.getCnpj(),
                f.getContato(), f.getFone1(), f.getFone2(), "Fornecedor");
        }
    }

    private void preencherPessoaCheckIn(String nome, String cpf, String cnpj,
            String contato, String fone1, String fone2, String tipo) {
        tela.getjTextFieldNome().setText(nome != null ? nome : "");
        tela.getjTextFieldCPF().setText(cpf != null ? cpf : "");
        tela.getjTextFieldCNPJ().setText(cnpj != null ? cnpj : "");
        tela.getjTextFieldContato().setText(contato != null ? contato : "");
        tela.getjTextFieldTelefone().setText(fone1 != null ? fone1 : "");
        tela.getjTextFieldTelefone2().setText(fone2 != null ? fone2 : "");
        tela.getjComboBoxTipoHospede().setSelectedItem(tipo);
    }

    // ── Quarto ────────────────────────────────────────────────────────────
    private void abrirBuscaQuarto() {
        ControllerCadQuarto.codigo = 0;
        TelaBuscaQuarto telaBusca = new TelaBuscaQuarto(null, true);
        new ControllerBuscaQuarto(telaBusca);   // controller original com todos os filtros
        telaBusca.setVisible(true);
        codigoQuarto = ControllerCadQuarto.codigo;
        if (codigoQuarto != 0) {
            Quarto q = service.QuartoService.Carregar(codigoQuarto);
            if (q != null) {
                tela.getjTextFieldNumeroQuarto().setText(q.getIdentificacao() != null ? q.getIdentificacao() : "");
                tela.getjTextFieldAndarQuarto().setText(String.valueOf(q.getAndar()));
                tela.getjTextFieldCapacidadeQuarto().setText(String.valueOf(q.getCapacidadeHospedes()));
                tela.getjComboBoxPossuiAnimais().setSelectedItem(q.getFlagAnimais() ? "Sim" : "Não");
            }
        }
    }

    // ── Veículo ───────────────────────────────────────────────────────────
    private void abrirBuscaVeiculo() {
        ControllerCadVeiculo.codigo = 0;
        view.TelaBuscaVeiculo telaBusca = new view.TelaBuscaVeiculo(null, true);
        new ControllerBuscaVeiculo(telaBusca);   // controller original com todos os filtros
        telaBusca.setVisible(true);
        int codigoVeiculo = ControllerCadVeiculo.codigo;
        if (codigoVeiculo != 0) {
            model.Veiculo v = service.VeiculoService.Carregar(codigoVeiculo);
            if (v != null) {
                tela.getjTextFieldPlaca().setText(v.getPlaca() != null ? v.getPlaca() : "");
                tela.getjComboBoxCor().setSelectedItem(v.getCor() != null ? v.getCor() : "");
                // Campo Veículo recebe "Marca / Modelo"
                String descVeiculo = "";
                if (v.getModelo() != null) {
                    descVeiculo = v.getModelo().getDescricao() != null ? v.getModelo().getDescricao() : "";
                    if (v.getModelo().getMarca() != null && v.getModelo().getMarca().getDescricao() != null) {
                        descVeiculo = v.getModelo().getMarca().getDescricao() + " / " + descVeiculo;
                    }
                }
                tela.getjTextFieldVeiculo().setText(descVeiculo);
            }
        }
    }

    // =========================================================
    // CHECK-IN: GRAVAR
    // =========================================================
    private void gravarCheckIn() {
        if (codigoHospede == 0) {
            JOptionPane.showMessageDialog(tela, "Use Buscar > Hospede/Funcionario/Fornecedor para selecionar a pessoa.");
            return;
        }
        if (codigoQuarto == 0) {
            JOptionPane.showMessageDialog(tela, "Use Buscar > Quarto para selecionar o quarto.");
            return;
        }
        try {
            String idTxt = tela.getjTextFieldNumeroReserva().getText().trim();
            Check check;
            if (idTxt.isEmpty()) {
                check = new Check();
                check.setStatus('A');
            } else {
                check = checkDAO.Retrieve(Integer.parseInt(idTxt));
                if (check == null) { JOptionPane.showMessageDialog(tela, "Check-In não encontrado."); return; }
            }

            check.setDataHoraEntrada(tela.getjTextFieldDataHoraEntrada().getText().trim());
            check.setDataHoraSaida(tela.getjTextFieldDataHoraSaida().getText().trim());
            check.setObs(tela.getjTextFieldObservacao().getText().trim());
            check.setDataHoraCadastro(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));

            Quarto quarto = service.QuartoService.Carregar(codigoQuarto);
            CheckQuarto cq = new CheckQuarto();
            cq.setQuarto(quarto);
            cq.setDataHoraInicio(tela.getjTextFieldHoraInicio().getText().trim());
            cq.setDataHoraFim(tela.getjTextFieldHoraTermino().getText().trim());
            cq.setStatus('A');
            check.setCheckQuarto(cq);

            if (idTxt.isEmpty()) checkDAO.Create(check);
            else checkDAO.Update(check);

            Hospede hospede = service.HospedeService.Carregar(codigoHospede);
            if (hospede != null) {
                CheckHospede ch = new CheckHospede();
                ch.setCheck(check);
                ch.setHospede(hospede);
                ch.setTipoHospede(tela.getjComboBoxTipoHospede().getSelectedItem() != null
                        ? tela.getjComboBoxTipoHospede().getSelectedItem().toString() : "Hospede");
                ch.setStatus("A");
                model.DAO.CheckHospedeDAO.getInstance().Create(ch);
            }

            JOptionPane.showMessageDialog(tela, "Check-In gravado com sucesso!");
            tela.getjTextFieldNumeroReserva().setText(String.valueOf(check.getId()));

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela, "Erro ao gravar: " + ex.getMessage());
        }
    }

    // =========================================================
    // CHECK-OUT: BUSCA E PREENCHIMENTO
    // =========================================================
    private void abrirBuscaHospedeCheckOut() {
        ControllerCadHospede.codigo = 0;
        TelaBuscasHospede telaBusca = new TelaBuscasHospede(null, true);
        new ControllerBuscaHospede(telaBusca);   // controller original com todos os filtros
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadHospede.codigo;
        if (codigoHospede != 0) carregarCheckOutPorHospede(codigoHospede);
    }

    private void carregarCheckOutPorHospede(int idHospede) {
        try {
            for (Check c : checkDAO.buscarCheckIns()) {
                CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
                if (ch != null && ch.getHospede() != null && ch.getHospede().getId() == idHospede) {
                    preencherCamposCheckOut(c, ch); return;
                }
            }
            JOptionPane.showMessageDialog(tela, "Nenhum Check-In ativo encontrado para esse hóspede.");
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    private void carregarCheckOut() {
        try {
            List<Check> lista = checkDAO.buscarCheckIns();
            if (!lista.isEmpty()) preencherCamposCheckOut(lista.get(0),
                    checkDAO.buscarHospedeDoCheck(lista.get(0).getId()));
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    private void preencherCamposCheckOut(Check c, CheckHospede ch) {
        tela.getjTextFieldDataHoraEntrada2().setText(c.getDataHoraEntrada() != null ? c.getDataHoraEntrada() : "");
        tela.getjTextFieldDataHoraSaida2().setText(c.getDataHoraSaida() != null ? c.getDataHoraSaida() : "");
        tela.getjTextFieldObservacao2().setText(c.getObs() != null ? c.getObs() : "");
        if (c.getCheckQuarto() != null && c.getCheckQuarto().getQuarto() != null) {
            tela.getjTextFieldQuarto2().setText(c.getCheckQuarto().getQuarto().getIdentificacao() != null
                    ? c.getCheckQuarto().getQuarto().getIdentificacao() : "");
            tela.getjTextFieldAndar2().setText(String.valueOf(c.getCheckQuarto().getQuarto().getAndar()));
        }
        if (ch != null && ch.getHospede() != null) {
            tela.getjTextFieldHospede2().setText(ch.getHospede().getNome() != null ? ch.getHospede().getNome() : "");
            tela.getjTextFieldCPF2().setText(ch.getHospede().getCpf() != null ? ch.getHospede().getCpf() : "");
            tela.getjTextFieldCNPJ2().setText(ch.getHospede().getCnpj() != null ? ch.getHospede().getCnpj() : "");
        }
    }

    // =========================================================
    // CHECK-OUT: GRAVAR
    // =========================================================
    private void gravarCheckOut() {
        if (codigoHospede == 0) {
            JOptionPane.showMessageDialog(tela, "Use o botão Buscar para selecionar o hóspede.");
            return;
        }
        try {
            Check checkAlvo = null;
            for (Check c : checkDAO.buscarCheckIns()) {
                CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
                if (ch != null && ch.getHospede() != null && ch.getHospede().getId() == codigoHospede) {
                    checkAlvo = c; break;
                }
            }
            if (checkAlvo == null) {
                JOptionPane.showMessageDialog(tela, "Nenhum Check-In ativo encontrado para esse hóspede.");
                return;
            }
            String saida = tela.getjTextFieldDataHoraSaida2().getText().trim();
            if (saida.isEmpty()) saida = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
            checkAlvo.setDataHoraSaida(saida);
            checkAlvo.setObs(tela.getjTextFieldObservacao2().getText().trim());
            checkDAO.Update(checkAlvo);
            JOptionPane.showMessageDialog(tela, "Check-Out registrado com sucesso!");
            limparCheckOut();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela, "Erro ao gravar Check-Out: " + ex.getMessage());
        }
    }

    // =========================================================
    // LIMPAR CAMPOS
    // =========================================================
    private void limparCheckIn() {
        codigoHospede = 0; codigoQuarto = 0;
        tela.getjTextFieldNumeroReserva().setText("");
        tela.getjTextFieldDataHoraEntrada().setText("");
        tela.getjTextFieldDataHoraSaida().setText("");
        tela.getjTextFieldNumeroQuarto().setText("");
        tela.getjTextFieldAndarQuarto().setText("");
        tela.getjTextFieldCapacidadeQuarto().setText("");
        tela.getjTextFieldHoraInicio().setText("");
        tela.getjTextFieldHoraTermino().setText("");
        tela.getjTextFieldNome().setText("");
        tela.getjTextFieldCNPJ().setText("");
        tela.getjTextFieldCPF().setText("");
        tela.getjTextFieldContato().setText("");
        tela.getjTextFieldTelefone().setText("");
        tela.getjTextFieldTelefone2().setText("");
        tela.getjTextFieldObservacao().setText("");
        tela.getjTextFieldVeiculo().setText("");
        tela.getjTextFieldVagaEstacionamento().setText("");
        tela.getjTextFieldPlaca().setText("");
        tela.getjComboBoxPossuiAnimais().setSelectedIndex(-1);
        tela.getjComboBoxTipoHospede().setSelectedIndex(-1);
        tela.getjComboBoxCor().setSelectedIndex(-1);
    }

    private void limparCheckOut() {
        codigoHospede = 0;
        tela.getjTextFieldHospede2().setText("");
        tela.getjTextFieldCPF2().setText("");
        tela.getjTextFieldCNPJ2().setText("");
        tela.getjTextFieldQuarto2().setText("");
        tela.getjTextFieldAndar2().setText("");
        tela.getjTextFieldDataHoraEntrada2().setText("");
        tela.getjTextFieldDataHoraSaida2().setText("");
        tela.getjTextFieldTotal().setText("");
        tela.getjTextFieldObservacao2().setText("");
    }

}
