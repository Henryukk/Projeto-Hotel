package controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import model.Check;
import model.CheckHospede;
import model.CheckQuarto;
import model.Fornecedor;
import model.Funcionario;
import model.Hospede;
import model.Quarto;
import model.DAO.CheckDAO;
import model.DAO.CheckHospedeDAO;
import model.DAO.CheckQuartoDAO;
import view.TelaBuscaFornecedor;
import view.TelaBuscaFuncionario;
import view.TelaBuscaQuarto;
import view.TelaBuscasHospede;
import view.TelaMovimentos;

public class ControllerMovimentos {

    // IDs selecionados pelas telas de busca (Check-In)
    public static int codigoHospede = 0;
    public static int codigoQuarto  = 0;

    // Check ativo localizado no Check-Out (para gravar a saída)
    private Check checkAtivoCheckOut = null;

    private final TelaMovimentos   tela;
    private final CheckDAO         checkDAO        = CheckDAO.getInstance();
    private final CheckQuartoDAO   checkQuartoDAO  = CheckQuartoDAO.getInstance();
    private final CheckHospedeDAO  checkHospedeDAO = CheckHospedeDAO.getInstance();
    private final SimpleDateFormat sdf             = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    public ControllerMovimentos(TelaMovimentos tela) {
        this.tela = tela;
        registrarListeners();
    }

    // =========================================================================
    //  LISTENERS
    // =========================================================================
    private void registrarListeners() {

        // ABA CHECK-IN
        tela.getBtnBuscar1()              .addActionListener(e -> abrirMenuBuscaCheckIn());
        tela.getBtnBuscarHospedeCheckIn() .addActionListener(e -> abrirMenuBuscaCheckIn());
        tela.getBtnBuscarQuartoCheckIn()  .addActionListener(e -> abrirBuscaQuarto());
        tela.getBtnGravar1()              .addActionListener(e -> gravarCheckIn());
        tela.getBtnNovo1()                .addActionListener(e -> limparCheckIn());
        tela.getBtnCancelar1()            .addActionListener(e -> limparCheckIn());
        tela.getBtnSair1()                .addActionListener(e -> tela.dispose());

        // ABA CHECK-OUT
        tela.getBtnBuscar()               .addActionListener(e -> abrirBuscaHospedeCheckOut());
        tela.getBtnBuscarHospedeCheckOut().addActionListener(e -> abrirBuscaHospedeCheckOut());
        tela.getBtnGravar()               .addActionListener(e -> gravarCheckOut());
        tela.getBtnNovo()                 .addActionListener(e -> limparCheckOut());
        tela.getBtnCancelar()             .addActionListener(e -> limparCheckOut());
        tela.getBtnSair()                 .addActionListener(e -> tela.dispose());
    }

    // =========================================================================
    //  CHECK-IN — BUSCA
    // =========================================================================
    private void abrirMenuBuscaCheckIn() {
        String[] opcoes = {"Hospede", "Funcionario", "Fornecedor", "Quarto", "Veiculo"};
        int escolha = JOptionPane.showOptionDialog(
                tela, "O que deseja buscar?", "Buscar",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, opcoes, opcoes[0]);

        switch (escolha) {
            case 0: abrirBuscaHospede();     break;
            case 1: abrirBuscaFuncionario(); break;
            case 2: abrirBuscaFornecedor();  break;
            case 3: abrirBuscaQuarto();      break;
            case 4: abrirBuscaVeiculo();     break;
        }
    }

    private void abrirBuscaHospede() {
        ControllerCadHospede.codigo = 0;
        TelaBuscasHospede telaBusca = new TelaBuscasHospede(null, true);
        new ControllerBuscaHospede(telaBusca);
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadHospede.codigo;
        if (codigoHospede != 0) {
            Hospede h = service.HospedeService.Carregar(codigoHospede);
            if (h != null) preencherPessoaCheckIn(
                    h.getNome(), h.getCpf(), h.getCnpj(),
                    h.getContato(), h.getFone1(), h.getFone2(), "Hospede");
        }
    }

    private void abrirBuscaFuncionario() {
        ControllerCadFuncionario.codigo = 0;
        TelaBuscaFuncionario telaBusca = new TelaBuscaFuncionario(null, true);
        new ControllerBuscaFuncionario(telaBusca);
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadFuncionario.codigo;
        if (codigoHospede != 0) {
            Funcionario f = service.FuncionarioService.Carregar(codigoHospede);
            if (f != null) preencherPessoaCheckIn(
                    f.getNome(), f.getCpf(), "",
                    "", f.getFone1(), f.getFone2(), "Funcionario");
        }
    }

    private void abrirBuscaFornecedor() {
        ControllerCadFornecedor.codigo = 0;
        TelaBuscaFornecedor telaBusca = new TelaBuscaFornecedor(null, true);
        new ControllerBuscaFornecedor(telaBusca);
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadFornecedor.codigo;
        if (codigoHospede != 0) {
            Fornecedor f = service.FornecedorService.Carregar(codigoHospede);
            if (f != null) preencherPessoaCheckIn(
                    f.getNome(), f.getCpf(), f.getCnpj(),
                    f.getContato(), f.getFone1(), f.getFone2(), "Fornecedor");
        }
    }

    private void preencherPessoaCheckIn(String nome, String cpf, String cnpj,
            String contato, String fone1, String fone2, String tipo) {
        tela.getjTextFieldNome()         .setText(nvl(nome));
        tela.getjTextFieldCPF()          .setText(nvl(cpf));
        tela.getjTextFieldCNPJ()         .setText(nvl(cnpj));
        tela.getjTextFieldContato()      .setText(nvl(contato));
        tela.getjTextFieldTelefone()     .setText(nvl(fone1));
        tela.getjTextFieldTelefone2()    .setText(nvl(fone2));
        tela.getjComboBoxTipoHospede()   .setSelectedItem(tipo);
    }

    private void abrirBuscaQuarto() {
        ControllerCadQuarto.codigo = 0;
        TelaBuscaQuarto telaBusca = new TelaBuscaQuarto(null, true);
        new ControllerBuscaQuarto(telaBusca);
        telaBusca.setVisible(true);
        codigoQuarto = ControllerCadQuarto.codigo;
        if (codigoQuarto != 0) {
            Quarto q = service.QuartoService.Carregar(codigoQuarto);
            if (q != null) {
                tela.getjTextFieldNumeroQuarto()    .setText(nvl(q.getIdentificacao()));
                tela.getjTextFieldAndarQuarto()     .setText(String.valueOf(q.getAndar()));
                tela.getjTextFieldCapacidadeQuarto().setText(String.valueOf(q.getCapacidadeHospedes()));
                tela.getjComboBoxPossuiAnimais()    .setSelectedItem(q.getFlagAnimais() ? "Sim" : "Não");
            }
        }
    }

    private void abrirBuscaVeiculo() {
        ControllerCadVeiculo.codigo = 0;
        view.TelaBuscaVeiculo telaBusca = new view.TelaBuscaVeiculo(null, true);
        new ControllerBuscaVeiculo(telaBusca);
        telaBusca.setVisible(true);
        int codigoVeiculo = ControllerCadVeiculo.codigo;
        if (codigoVeiculo != 0) {
            model.Veiculo v = service.VeiculoService.Carregar(codigoVeiculo);
            if (v != null) {
                tela.getjTextFieldPlaca()   .setText(nvl(v.getPlaca()));
                tela.getjComboBoxCor()      .setSelectedItem(nvl(v.getCor()));
                String descVeiculo = "";
                if (v.getModelo() != null) {
                    descVeiculo = nvl(v.getModelo().getDescricao());
                    if (v.getModelo().getMarca() != null)
                        descVeiculo = nvl(v.getModelo().getMarca().getDescricao()) + " / " + descVeiculo;
                }
                tela.getjTextFieldVeiculo().setText(descVeiculo);
            }
        }
    }

    // =========================================================================
    //  CHECK-IN — GRAVAR
    //  Ordem obrigatória: 1) CheckQuarto  2) Check  3) CheckHospede
    // =========================================================================
    private void gravarCheckIn() {

        if (codigoHospede == 0) {
            JOptionPane.showMessageDialog(tela,
                    "Selecione um hóspede usando o botão Buscar.");
            return;
        }
        if (codigoQuarto == 0) {
            JOptionPane.showMessageDialog(tela,
                    "Selecione um quarto usando o botão Buscar > Quarto.");
            return;
        }

        try {
            String agora = sdf.format(new Date());

            // ── 1. CheckQuarto — salva PRIMEIRO (FK necessária pelo Check) ────
            Quarto quarto = service.QuartoService.Carregar(codigoQuarto);

            CheckQuarto cq = new CheckQuarto();
            cq.setQuarto(quarto);
            cq.setDataHoraInicio(textoOuAgora(tela.getjTextFieldHoraInicio()  .getText(), agora));
            cq.setDataHoraFim(                tela.getjTextFieldHoraTermino() .getText().trim());
            cq.setStatus('A');
            cq.setObs("");

            checkQuartoDAO.Create(cq);          // ← persiste antes do Check

            // ── 2. Check — salva SEGUNDO com FK do CheckQuarto já gerada ─────
            Check check = new Check();
            check.setCheckQuarto(cq);
            check.setDataHoraCadastro(agora);
            check.setDataHoraEntrada(textoOuAgora(tela.getjTextFieldDataHoraEntrada().getText(), agora));
            check.setDataHoraSaida(             tela.getjTextFieldDataHoraSaida()  .getText().trim());
            check.setObs(                        tela.getjTextFieldObservacao()    .getText().trim());
            check.setStatus('A');

            checkDAO.Create(check);             // ← persiste com FK do cq

            // ── 3. CheckHospede — salva TERCEIRO com FK do Check já gerada ───
            Hospede hospede = service.HospedeService.Carregar(codigoHospede);
            if (hospede != null) {
                CheckHospede ch = new CheckHospede();
                ch.setCheck(check);
                ch.setHospede(hospede);
                ch.setTipoHospede(
                        tela.getjComboBoxTipoHospede().getSelectedItem() != null
                        ? tela.getjComboBoxTipoHospede().getSelectedItem().toString()
                        : "Hospede");
                ch.setObs("");
                ch.setStatus("A");
                checkHospedeDAO.Create(ch);
            }

            JOptionPane.showMessageDialog(tela,
                    "Check-In gravado com sucesso!\nID do Check: " + check.getId());

            // Exibe o ID gerado no campo para referência futura
            tela.getjTextFieldNumeroReserva().setText(String.valueOf(check.getId()));

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela,
                    "Erro ao gravar Check-In:\n" + ex.getMessage());
        }
    }

    // =========================================================================
    //  CHECK-OUT — BUSCA
    //  Abre TelaBuscasHospede → acha o Check ativo → preenche todos os campos
    // =========================================================================
    private void abrirBuscaHospedeCheckOut() {
        ControllerCadHospede.codigo = 0;
        TelaBuscasHospede telaBusca = new TelaBuscasHospede(null, true);
        new ControllerBuscaHospede(telaBusca);
        telaBusca.setVisible(true);

        int idHospede = ControllerCadHospede.codigo;
        if (idHospede == 0) return;

        try {
            Check checkEncontrado = null;

            for (Check c : checkDAO.buscarCheckIns()) {
                CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
                if (ch != null && ch.getHospede() != null
                        && ch.getHospede().getId() == idHospede) {
                    checkEncontrado = c;
                    break;
                }
            }

            if (checkEncontrado == null) {
                JOptionPane.showMessageDialog(tela,
                        "Nenhum Check-In ativo encontrado para esse hóspede.");
                return;
            }

            checkAtivoCheckOut = checkEncontrado;
            preencherCamposCheckOut(checkEncontrado);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela,
                    "Erro ao buscar Check-In:\n" + ex.getMessage());
        }
    }

    /**
     * Preenche TODOS os campos do Check-Out com os dados do Check ativo.
     */
    private void preencherCamposCheckOut(Check c) {

        // Dados do Check
        tela.getjTextFieldDataHoraEntrada2().setText(nvl(c.getDataHoraEntrada()));
        tela.getjTextFieldDataHoraSaida2()  .setText(nvl(c.getDataHoraSaida()));
        tela.getjTextFieldObservacao2()     .setText(nvl(c.getObs()));

        // Dados do Quarto (via CheckQuarto)
        CheckQuarto cq = c.getCheckQuarto();
        if (cq != null && cq.getQuarto() != null) {
            tela.getjTextFieldQuarto2().setText(nvl(cq.getQuarto().getIdentificacao()));
            tela.getjTextFieldAndar2() .setText(String.valueOf(cq.getQuarto().getAndar()));
        }

        // Dados do Hóspede (via CheckHospede)
        CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
        if (ch != null && ch.getHospede() != null) {
            Hospede h = ch.getHospede();
            tela.getjTextFieldHospede2().setText(nvl(h.getNome()));
            tela.getjTextFieldCPF2()    .setText(nvl(h.getCpf()));
            tela.getjTextFieldCNPJ2()   .setText(nvl(h.getCnpj()));
        }

        // Total zerado por enquanto — será calculado ao implementar consumos
        tela.getjTextFieldTotal().setText("0,00");
    }

    // =========================================================================
    //  CHECK-OUT — GRAVAR
    //  Registra saída e muda status do Check para 'F' (Fechado)
    // =========================================================================
    private void gravarCheckOut() {
        if (checkAtivoCheckOut == null) {
            JOptionPane.showMessageDialog(tela,
                    "Use o botão Buscar para localizar o hóspede antes de gravar.");
            return;
        }

        try {
            String saida = tela.getjTextFieldDataHoraSaida2().getText().trim();
            if (saida.isEmpty()) {
                saida = sdf.format(new Date());
                tela.getjTextFieldDataHoraSaida2().setText(saida);
            }

            checkAtivoCheckOut.setDataHoraSaida(saida);
            checkAtivoCheckOut.setObs(tela.getjTextFieldObservacao2().getText().trim());
            checkAtivoCheckOut.setStatus('F');   // Fechado

            checkDAO.Update(checkAtivoCheckOut);

            JOptionPane.showMessageDialog(tela,
                    "Check-Out registrado com sucesso!\nID do Check: "
                    + checkAtivoCheckOut.getId());

            checkAtivoCheckOut = null;
            limparCheckOut();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela,
                    "Erro ao gravar Check-Out:\n" + ex.getMessage());
        }
    }

    // =========================================================================
    //  LIMPAR
    // =========================================================================
    private void limparCheckIn() {
        codigoHospede = 0;
        codigoQuarto  = 0;
        tela.getjTextFieldNumeroReserva()     .setText("");
        tela.getjTextFieldDataHoraEntrada()   .setText("");
        tela.getjTextFieldDataHoraSaida()     .setText("");
        tela.getjTextFieldNumeroQuarto()      .setText("");
        tela.getjTextFieldAndarQuarto()       .setText("");
        tela.getjTextFieldCapacidadeQuarto()  .setText("");
        tela.getjTextFieldHoraInicio()        .setText("");
        tela.getjTextFieldHoraTermino()       .setText("");
        tela.getjTextFieldNome()              .setText("");
        tela.getjTextFieldCNPJ()              .setText("");
        tela.getjTextFieldCPF()               .setText("");
        tela.getjTextFieldContato()           .setText("");
        tela.getjTextFieldTelefone()          .setText("");
        tela.getjTextFieldTelefone2()         .setText("");
        tela.getjTextFieldObservacao()        .setText("");
        tela.getjTextFieldVeiculo()           .setText("");
        tela.getjTextFieldVagaEstacionamento().setText("");
        tela.getjTextFieldPlaca()             .setText("");
        tela.getjComboBoxPossuiAnimais()      .setSelectedIndex(-1);
        tela.getjComboBoxTipoHospede()        .setSelectedIndex(-1);
        tela.getjComboBoxCor()                .setSelectedIndex(-1);
    }

    private void limparCheckOut() {
        checkAtivoCheckOut = null;
        tela.getjTextFieldHospede2()         .setText("");
        tela.getjTextFieldCPF2()             .setText("");
        tela.getjTextFieldCNPJ2()            .setText("");
        tela.getjTextFieldQuarto2()          .setText("");
        tela.getjTextFieldAndar2()           .setText("");
        tela.getjTextFieldDataHoraEntrada2() .setText("");
        tela.getjTextFieldDataHoraSaida2()   .setText("");
        tela.getjTextFieldTotal()            .setText("");
        tela.getjTextFieldObservacao2()      .setText("");
    }

    // =========================================================================
    //  UTILITÁRIOS
    // =========================================================================

    /** Retorna o texto se não vazio, senão retorna o fallback. */
    private String textoOuAgora(String texto, String fallback) {
        return (texto != null && !texto.trim().isEmpty()) ? texto.trim() : fallback;
    }

    /** Null-safe: retorna "" se o valor for null. */
    private String nvl(String valor) {
        return valor != null ? valor : "";
    }
}
