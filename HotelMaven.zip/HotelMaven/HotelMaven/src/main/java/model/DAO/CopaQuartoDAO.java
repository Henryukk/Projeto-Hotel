package model.DAO;
import java.util.List;
import model.CopaQuarto;
import model.CheckQuarto;           // necessário para a FK
import java.util.ArrayList;        // necessário para a lista
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CopaQuartoDAO implements InterfaceDAO<CopaQuarto>{
    
    private static CopaQuartoDAO instance;
    protected EntityManager entityManager;

    public CopaQuartoDAO() {
        entityManager = getEntityManager();
    }

    public static CopaQuartoDAO getInstance() {
        if (instance == null) {
            instance = new CopaQuartoDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

   @Override
    public void Create(CopaQuarto objeto) {
        

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public CopaQuarto Retrieve(int id) {

        CopaQuarto copaQuarto = new CopaQuarto();
        copaQuarto = entityManager.find(CopaQuarto.class, id);
        
        return copaQuarto;
    }

    @Override
    public List<CopaQuarto> Retrieve(String atributo, String valor) {

        List<CopaQuarto> ListaCopaQuarto = new ArrayList<>();
        ListaCopaQuarto = entityManager.createQuery(" SELECT copa FROM CopaQuarto copa" +
                                                 " WHERE " + atributo +
                                                 " LIKE (% " + valor + " %)",CopaQuarto.class).getResultList();
                
        return ListaCopaQuarto;
    }

    @Override
    public void Update(CopaQuarto objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(CopaQuarto objeto) {
        try{
            entityManager.getTransaction().begin();
            CopaQuarto copaQuarto = new CopaQuarto();
            copaQuarto = entityManager.find(CopaQuarto.class, objeto.getId());
            if (copaQuarto != null) {
                entityManager.remove(copaQuarto);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}