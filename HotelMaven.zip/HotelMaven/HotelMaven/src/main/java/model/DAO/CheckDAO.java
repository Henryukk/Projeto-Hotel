package model.DAO;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Check;
import model.CheckHospede;
import model.CheckQuarto;

public class CheckDAO implements InterfaceDAO<Check> {

    private static CheckDAO instance;
    protected EntityManager entityManager;

    public CheckDAO() {
        entityManager = getEntityManager();
    }

    public static CheckDAO getInstance() {
        if (instance == null) {
            instance = new CheckDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(Check objeto) {
        try {
            entityManager.getTransaction().begin();

            // ── CORREÇÃO: reanexa o CheckQuarto ao EntityManager deste DAO ──
            // O CheckQuarto foi persistido por outro EM (CheckQuartoDAO),
            // então aqui ele está "detached". merge() o reaneza antes do persist.
            if (objeto.getCheckQuarto() != null && objeto.getCheckQuarto().getId() != 0) {
                CheckQuarto cqManaged = entityManager.merge(objeto.getCheckQuarto());
                objeto.setCheckQuarto(cqManaged);
            }

            entityManager.persist(objeto);
            entityManager.getTransaction().commit();

        } catch (Exception ex) {
            ex.printStackTrace();
            // ── CORREÇÃO: só faz rollback se a transação ainda estiver ativa ──
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    @Override
    public Check Retrieve(int id) {
        return entityManager.find(Check.class, id);
    }

    @Override
    public List<Check> Retrieve(String atributo, String valor) {
        List<Check> lista = new ArrayList<>();
        lista = entityManager.createQuery(
                "SELECT c FROM Check c WHERE "
                + (atributo.equalsIgnoreCase("status")
                        ? "c.status = :valor"
                        : "c." + atributo + " LIKE :valor"),
                Check.class)
                .setParameter("valor",
                        atributo.equalsIgnoreCase("status")
                        ? valor.trim().charAt(0)
                        : "%" + valor.trim() + "%")
                .getResultList();
        return lista;
    }

    @Override
    public void Update(Check objeto) {
        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    @Override
    public void Delete(Check objeto) {
        try {
            entityManager.getTransaction().begin();
            Check check = entityManager.find(Check.class, objeto.getId());
            if (check != null) {
                entityManager.remove(check);
            }
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    /**
     * Retorna todos os Check-Ins ativos (sem dataHoraSaida = ainda hospedado).
     */
    public List<Check> buscarCheckIns() {
        return entityManager.createQuery(
                "SELECT c FROM Check c WHERE c.status = :status "
                + "AND (c.dataHoraSaida IS NULL OR c.dataHoraSaida = '')",
                Check.class)
                .setParameter("status", 'A')
                .getResultList();
    }

    /**
     * Retorna todos os Check-Outs (dataHoraSaida preenchida).
     */
    public List<Check> buscarCheckOuts() {
        return entityManager.createQuery(
                "SELECT c FROM Check c WHERE c.status = :status "
                + "AND c.dataHoraSaida IS NOT NULL AND c.dataHoraSaida <> ''",
                Check.class)
                .setParameter("status", 'A')
                .getResultList();
    }

    /**
     * Retorna o CheckHospede associado a um Check (primeiro hóspede encontrado).
     */
    public CheckHospede buscarHospedeDoCheck(int checkId) {
        List<CheckHospede> lista = entityManager.createQuery(
                "SELECT ch FROM CheckHospede ch WHERE ch.check.id = :checkId",
                CheckHospede.class)
                .setParameter("checkId", checkId)
                .setMaxResults(1)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }
}
