package model.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Caixa;

public class CaixaDAO implements InterfaceDAO<Caixa>{
    
    private static CaixaDAO instance;
    protected EntityManager entityManager;

    public CaixaDAO() {
        entityManager = getEntityManager();
    }

    public static CaixaDAO getInstance() {
        if (instance == null) {
            instance = new CaixaDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(Caixa objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public Caixa Retrieve(int id) {

        Caixa caixa = new Caixa();
        caixa = entityManager.find(Caixa.class, id);
        
        return caixa;
    }

    @Override
    public List<Caixa> Retrieve(String atributo, String valor) {

        List<Caixa> ListaCaixa = new ArrayList<>();
        ListaCaixa = entityManager.createQuery(" SELECT caix FROM Caixa caix" +
                                                 " WHERE " + atributo +
                                                 " LIKE (% " + valor + " %)",Caixa.class).getResultList();
                
        return ListaCaixa;
    }

    @Override
    public void Update(Caixa objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(Caixa objeto) {
        
        try{
            entityManager.getTransaction().begin();
            Caixa caixa = new Caixa();
            caixa = entityManager.find(Caixa.class, objeto.getId());
            if (caixa != null) {
                entityManager.remove(caixa);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}