package model.DAO;
import java.util.List;
import model.CheckQuarto;
import model.Check;
import model.Quarto;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CheckQuartoDAO implements InterfaceDAO<CheckQuarto>{
    
    private static CheckQuartoDAO instance;
    protected EntityManager entityManager;

    public CheckQuartoDAO() {
        entityManager = getEntityManager();
    }

    public static CheckQuartoDAO getInstance() {
        if (instance == null) {
            instance = new CheckQuartoDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(CheckQuarto objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public CheckQuarto Retrieve(int id) {

        CheckQuarto checkQuarto = new CheckQuarto();
        checkQuarto = entityManager.find(CheckQuarto.class, id);
        
        return checkQuarto;
    }

    @Override
    public List<CheckQuarto> Retrieve(String atributo, String valor) {

        List<CheckQuarto> ListaCheckQuarto = new ArrayList<>();
        ListaCheckQuarto = entityManager.createQuery(" SELECT checkqua FROM CheckQuarto checkqua" +
                                                 " WHERE " + atributo +
                                                 " LIKE (% " + valor + " %)",CheckQuarto.class).getResultList();
                
        return ListaCheckQuarto;
    }

    @Override
    public void Update(CheckQuarto objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(CheckQuarto objeto) {
        try{
            entityManager.getTransaction().begin();
            CheckQuarto checkQuarto = new CheckQuarto();
            checkQuarto = entityManager.find(CheckQuarto.class, objeto.getId());
            if (checkQuarto != null) {
                entityManager.remove(checkQuarto);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}