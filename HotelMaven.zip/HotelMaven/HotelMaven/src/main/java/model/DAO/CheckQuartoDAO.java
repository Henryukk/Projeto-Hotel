package model.DAO;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.CheckQuarto;
import model.Quarto;

public class CheckQuartoDAO implements InterfaceDAO<CheckQuarto> {

    private static CheckQuartoDAO instance;
    protected EntityManager entityManager;

    public CheckQuartoDAO() {
        entityManager = getEntityManager();
    }

    public static CheckQuartoDAO getInstance() {
        if (instance == null) {
            instance = new CheckQuartoDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(CheckQuarto objeto) {
        try {
            entityManager.getTransaction().begin();

            // ── CORREÇÃO: reaneja o Quarto ao EntityManager deste DAO ──
            // O Quarto veio de outro DAO (QuartoDAO), então está "detached".
            // merge() o reaneja antes do persist.
            if (objeto.getQuarto() != null && objeto.getQuarto().getId() != 0) {
                Quarto quartoManaged = entityManager.merge(objeto.getQuarto());
                objeto.setQuarto(quartoManaged);
            }

            entityManager.persist(objeto);
            entityManager.getTransaction().commit();

        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    @Override
    public CheckQuarto Retrieve(int id) {
        return entityManager.find(CheckQuarto.class, id);
    }

    @Override
    public List<CheckQuarto> Retrieve(String atributo, String valor) {
        List<CheckQuarto> lista = new ArrayList<>();
        lista = entityManager.createQuery(
                "SELECT cq FROM CheckQuarto cq WHERE "
                + (atributo.equalsIgnoreCase("status")
                        ? "cq.status = :valor"
                        : "cq." + atributo + " LIKE :valor"),
                CheckQuarto.class)
                .setParameter("valor",
                        atributo.equalsIgnoreCase("status")
                        ? valor.trim().charAt(0)
                        : "%" + valor.trim() + "%")
                .getResultList();
        return lista;
    }

    @Override
    public void Update(CheckQuarto objeto) {
        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    @Override
    public void Delete(CheckQuarto objeto) {
        try {
            entityManager.getTransaction().begin();
            CheckQuarto cq = entityManager.find(CheckQuarto.class, objeto.getId());
            if (cq != null) {
                entityManager.remove(cq);
            }
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }
}
