package model.DAO;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.AlocacaoVaga;

public class AlocacaoVagaDAO implements InterfaceDAO<AlocacaoVaga>{
    
    private static AlocacaoVagaDAO instance;
    protected EntityManager entityManager;

    public AlocacaoVagaDAO() {
        entityManager = getEntityManager();
    }

    public static AlocacaoVagaDAO getInstance() {
        if (instance == null) {
            instance = new AlocacaoVagaDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }


    @Override
    public void Create(AlocacaoVaga objeto) {
        try {
                entityManager.getTransaction().begin();
                entityManager.persist(objeto);
                entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public AlocacaoVaga Retrieve(int id) {
        AlocacaoVaga alocacaoVaga = new AlocacaoVaga();
        alocacaoVaga = entityManager.find(AlocacaoVaga.class, id);
        
        return alocacaoVaga;
    }
    

    @Override
    public List<AlocacaoVaga> Retrieve(String atributo, String valor) {
       List<AlocacaoVaga> ListaAlocacaoVaga = new ArrayList<>();
        ListaAlocacaoVaga = entityManager.createQuery(" SELECT aloc FROM AlocacaoCaixa aloc" +
                                                 " WHERE " + atributo +
                                                 " LIKE (% " + valor + " %)",AlocacaoVaga.class).getResultList();
                
        return ListaAlocacaoVaga; 
    }

    @Override
    public void Update(AlocacaoVaga objeto) {
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(AlocacaoVaga objeto) {
        try{
            entityManager.getTransaction().begin();
            AlocacaoVaga alocacaoVaga = new AlocacaoVaga();
            alocacaoVaga = entityManager.find(AlocacaoVaga.class, objeto.getId());
            if (alocacaoVaga != null) {
                entityManager.remove(alocacaoVaga);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
    
}
