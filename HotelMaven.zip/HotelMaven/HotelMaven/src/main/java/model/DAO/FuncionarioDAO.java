package model.DAO;

import java.util.List;
import model.Funcionario;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.DAO.InterfaceDAO;


public class FuncionarioDAO implements InterfaceDAO<Funcionario> {

    private static FuncionarioDAO instance;
    protected EntityManager entityManager;

    public FuncionarioDAO() {
        entityManager = getEntityManager();
    }

    public static FuncionarioDAO getInstance() {
        if (instance == null) {
            instance = new FuncionarioDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(Funcionario objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    public Funcionario Retrieve(int id) {
        Funcionario funcionario = new Funcionario();
        funcionario = entityManager.find(Funcionario.class, id);
        
        return funcionario;
    }


    @Override
    public List<Funcionario> Retrieve(String atributo, String valor) {

        List<Funcionario> ListaFuncionario = new ArrayList<>();
        ListaFuncionario = entityManager.createQuery(" SELECT func FROM Funcionario func" +
                                                 " WHERE " + atributo +
                                                 " LIKE (% " + valor + " %)",Funcionario.class).getResultList();
                
        return ListaFuncionario;
        
        }
    

    @Override
    public void Update(Funcionario objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }

    }

    @Override
    public void Delete(Funcionario objeto) {
        
        try{
            entityManager.getTransaction().begin();
            Funcionario funcionario = new Funcionario();
            funcionario = entityManager.find(Funcionario.class, objeto.getId());
            if (funcionario != null) {
                entityManager.remove(funcionario);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}
