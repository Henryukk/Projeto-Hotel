package model.DAO;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Check;
import model.CheckHospede;

public class CheckHospedeDAO implements InterfaceDAO<CheckHospede> {

    private static CheckHospedeDAO instance;
    protected EntityManager entityManager;

    public CheckHospedeDAO() {
        entityManager = getEntityManager();
    }

    public static CheckHospedeDAO getInstance() {
        if (instance == null) {
            instance = new CheckHospedeDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(CheckHospede objeto) {
        try {
            entityManager.getTransaction().begin();

            // ── CORREÇÃO: reaneja o Check ao EntityManager deste DAO ──
            // O Check foi persistido por outro EM (CheckDAO), então
            // está "detached" aqui. merge() o reaneja antes do persist.
            if (objeto.getCheck() != null && objeto.getCheck().getId() != 0) {
                Check checkManaged = entityManager.merge(objeto.getCheck());
                objeto.setCheck(checkManaged);
            }

            // Hospede não precisa de merge pois vem de uma busca (já está no banco)
            if (objeto.getHospede() != null && objeto.getHospede().getId() != 0) {
                model.Hospede hospedeManaged = entityManager.merge(objeto.getHospede());
                objeto.setHospede(hospedeManaged);
            }

            entityManager.persist(objeto);
            entityManager.getTransaction().commit();

        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    @Override
    public CheckHospede Retrieve(int id) {
        return entityManager.find(CheckHospede.class, id);
    }

    @Override
    public List<CheckHospede> Retrieve(String atributo, String valor) {
        List<CheckHospede> lista = new ArrayList<>();
        lista = entityManager.createQuery(
                "SELECT ch FROM CheckHospede ch WHERE "
                + (atributo.equalsIgnoreCase("status")
                        ? "ch.status = :valor"
                        : "ch." + atributo + " LIKE :valor"),
                CheckHospede.class)
                .setParameter("valor",
                        atributo.equalsIgnoreCase("status")
                        ? valor.trim().charAt(0)
                        : "%" + valor.trim() + "%")
                .getResultList();
        return lista;
    }

    @Override
    public void Update(CheckHospede objeto) {
        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }

    @Override
    public void Delete(CheckHospede objeto) {
        try {
            entityManager.getTransaction().begin();
            CheckHospede ch = entityManager.find(CheckHospede.class, objeto.getId());
            if (ch != null) {
                entityManager.remove(ch);
            }
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
        }
    }
}
