package model.DAO;
import java.util.List;
import model.CheckHospede;
import model.Check;
import model.Hospede;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CheckHospedeDAO implements InterfaceDAO<CheckHospede>{
    private static CheckHospedeDAO instance;
    protected EntityManager entityManager;

    public CheckHospedeDAO() {
        entityManager = getEntityManager();
    }

    public static CheckHospedeDAO getInstance() {
        if (instance == null) {
            instance = new CheckHospedeDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(CheckHospede objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public CheckHospede Retrieve(int id) {

        CheckHospede checkHospede = new CheckHospede();
        checkHospede = entityManager.find(CheckHospede.class, id);
        
        return checkHospede;
    }

    @Override
    public List<CheckHospede> Retrieve(String atributo, String valor) {

        List<CheckHospede> ListaCheckHospede = new ArrayList<>();
        ListaCheckHospede = entityManager.createQuery(" SELECT checkhosp FROM CheckHospede checkhosp" +
                                                 " WHERE " + atributo +
                                                 " LIKE (% " + valor + " %)",CheckHospede.class).getResultList();
                
        return ListaCheckHospede;
    }

    @Override
    public void Update(CheckHospede objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(CheckHospede objeto) {
        try{
            entityManager.getTransaction().begin();
            CheckHospede checkHospede = new CheckHospede();
            checkHospede = entityManager.find(CheckHospede.class, objeto.getId());
            if (checkHospede != null) {
                entityManager.remove(checkHospede);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}