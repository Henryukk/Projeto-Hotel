/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Funcionario;
import view.TelaBuscaFuncionario;

/**
 *
 * @author aluno
 */
public class ControllerBuscaFuncionario implements ActionListener {

    TelaBuscaFuncionario telaBuscaFuncionario;

    public ControllerBuscaFuncionario(TelaBuscaFuncionario telaBuscaFuncionario) {
        this.telaBuscaFuncionario = telaBuscaFuncionario;

        this.telaBuscaFuncionario.getjButtonCarregar().addActionListener(this);
        this.telaBuscaFuncionario.getjButtonFiltrar().addActionListener(this);
        this.telaBuscaFuncionario.getjButtonSair().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscaFuncionario.getjButtonCarregar()) {

            if (this.telaBuscaFuncionario.getjTableColunas().getRowCount() == 0
                    || this.telaBuscaFuncionario.getjTableColunas().getSelectedRow() == -1) {
                JOptionPane.showMessageDialog(null, "Errou. \nNão Existe Dados Selecionados");
            } else {
                
                ControllerCadFuncionario.codigo = (int) this.telaBuscaFuncionario.getjTableColunas().getValueAt(this.telaBuscaFuncionario.getjTableColunas().getSelectedRow(), 0);
                
                this.telaBuscaFuncionario.dispose();
                
                
            }

        } else if (evento.getSource() == this.telaBuscaFuncionario.getjButtonFiltrar()) {

            if (this.telaBuscaFuncionario.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem Dados para a Seleção...");
            } else {
                if (this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex() == 0) {

                    // ── Busca por ID ───────────────────────────────────────
                    try {
                        Funcionario funcionario = service.FuncionarioService.Carregar(
                            Integer.parseInt(this.telaBuscaFuncionario.getjTextFieldValor().getText().trim()));
                        DefaultTableModel tabela = (DefaultTableModel) this.telaBuscaFuncionario.getjTableColunas().getModel();
                        tabela.setRowCount(0);
                        if (funcionario != null) {
                            tabela.addRow(new Object[]{funcionario.getId(), funcionario.getNome(),
                                funcionario.getCpf(), funcionario.getStatus()});
                        } else {
                            JOptionPane.showMessageDialog(null, "Nenhum funcionário encontrado com esse ID.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "ID inválido. Digite apenas números.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Erro na busca por ID:\n" + ex.getMessage());
                    }

                } else if (this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex() == 1) {

                    // ── Busca por Nome ─────────────────────────────────────
                    try {
                        List<Funcionario> lista = service.FuncionarioService.Carregar("nome",
                            this.telaBuscaFuncionario.getjTextFieldValor().getText().trim());
                        DefaultTableModel tabela = (DefaultTableModel) this.telaBuscaFuncionario.getjTableColunas().getModel();
                        tabela.setRowCount(0);
                        for (Funcionario f : lista) {
                            tabela.addRow(new Object[]{f.getId(), f.getNome(), f.getCpf(), f.getStatus()});
                        }
                        if (lista.isEmpty()) JOptionPane.showMessageDialog(null, "Nenhum funcionário encontrado com esse nome.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Erro na busca por nome:\n" + ex.getMessage());
                    }

                } else if (this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex() == 2) {

                    // ── Busca por CPF ──────────────────────────────────────
                    try {
                        List<Funcionario> lista = service.FuncionarioService.Carregar("cpf",
                            this.telaBuscaFuncionario.getjTextFieldValor().getText().trim());
                        DefaultTableModel tabela = (DefaultTableModel) this.telaBuscaFuncionario.getjTableColunas().getModel();
                        tabela.setRowCount(0);
                        for (Funcionario f : lista) {
                            tabela.addRow(new Object[]{f.getId(), f.getNome(), f.getCpf(), f.getStatus()});
                        }
                        if (lista.isEmpty()) JOptionPane.showMessageDialog(null, "Nenhum funcionário encontrado com esse CPF.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Erro na busca por CPF:\n" + ex.getMessage());
                    }

                } else if (this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex() == 3) {

                    // ── Busca por Status ───────────────────────────────────
                    try {
                        List<Funcionario> lista = service.FuncionarioService.Carregar("status",
                            this.telaBuscaFuncionario.getjTextFieldValor().getText().trim());
                        DefaultTableModel tabela = (DefaultTableModel) this.telaBuscaFuncionario.getjTableColunas().getModel();
                        tabela.setRowCount(0);
                        for (Funcionario f : lista) {
                            tabela.addRow(new Object[]{f.getId(), f.getNome(), f.getCpf(), f.getStatus()});
                        }
                        if (lista.isEmpty()) JOptionPane.showMessageDialog(null, "Nenhum funcionário encontrado com esse status.");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Erro na busca por status:\n" + ex.getMessage());
                    }

                }
            }
        } else if (evento.getSource() == this.telaBuscaFuncionario.getjButtonSair()) {
            this.telaBuscaFuncionario.dispose();

        }
    }

}
