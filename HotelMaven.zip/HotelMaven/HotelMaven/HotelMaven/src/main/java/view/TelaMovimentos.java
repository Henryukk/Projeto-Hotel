package view;

import java.util.List;
import model.Check;
import model.CheckHospede;
import model.CheckQuarto;
import model.Hospede;
import model.Quarto;
import model.DAO.CheckDAO;

/**
 *
 * @author aluno
 */
public class TelaMovimentos extends javax.swing.JDialog {

    private CheckDAO checkDAO = CheckDAO.getInstance();

    /**
     * Creates new form TemplateCadastro2025
     */
    public TelaMovimentos(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        // Adiciona botões de busca na aba Check-In (acima dos campos de hóspede e quarto)
        btnBuscarHospedeCheckIn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Find.png")));
        btnBuscarQuartoCheckIn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Find.png")));
        btnBuscarHospedeCheckOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Find.png")));

        jPanel2.add(btnBuscarHospedeCheckIn);
        jPanel2.add(btnBuscarQuartoCheckIn);
        jPanel5.add(btnBuscarHospedeCheckOut);

        // Instancia o controller — ele registra todos os listeners
        new controller.ControllerMovimentos(this);
    }

    /*
     * Carrega o primeiro Check-In ativo nos campos da aba Check-In.
     */
    private void carregarCheckIn() {
        try {
            List<Check> checkIns = checkDAO.buscarCheckIns();
            if (!checkIns.isEmpty()) {
                preencherCamposCheckIn(checkIns.get(0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Carrega o primeiro Check-Out encontrado nos campos da aba Check-Out.
     */
    private void carregarCheckOut() {
        try {
            List<Check> checkOuts = checkDAO.buscarCheckOuts();
            if (!checkOuts.isEmpty()) {
                preencherCamposCheckOut(checkOuts.get(0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * Preenche os campos da aba Check-In com os dados de um Check.
     */
    private void preencherCamposCheckIn(Check check) {
        jTextFieldNumeroReserva.setText(String.valueOf(check.getId()));
        jTextFieldDataHoraEntrada.setText(check.getDataHoraEntrada() != null ? check.getDataHoraEntrada() : "");
        jTextFieldDataHoraSaida.setText(check.getDataHoraSaida() != null ? check.getDataHoraSaida() : "");
        jTextFieldObservacao.setText(check.getObs() != null ? check.getObs() : "");

        CheckQuarto cq = check.getCheckQuarto();
        if (cq != null) {
            Quarto q = cq.getQuarto();
            if (q != null) {
                jTextFieldNumeroQuarto.setText(q.getIdentificacao() != null ? q.getIdentificacao() : "");
                jTextFieldAndarQuarto.setText(String.valueOf(q.getAndar()));
                jTextFieldCapacidadeQuarto.setText(String.valueOf(q.getCapacidadeHospedes()));
                jComboBoxPossuiAnimais.setSelectedItem(q.getFlagAnimais() ? "Sim" : "Não");
            }
            jTextFieldHoraInicio.setText(cq.getDataHoraInicio() != null ? cq.getDataHoraInicio() : "");
            jTextFieldHoraTermino.setText(cq.getDataHoraFim() != null ? cq.getDataHoraFim() : "");
        }

        CheckHospede ch = checkDAO.buscarHospedeDoCheck(check.getId());
        if (ch != null) {
            jComboBoxTipoHospede.setSelectedItem(ch.getTipoHospede());
            Hospede h = ch.getHospede();
            if (h != null) {
                jTextFieldNome.setText(h.getNome() != null ? h.getNome() : "");
                jTextFieldCNPJ.setText(h.getCnpj() != null ? h.getCnpj() : "");
                jTextFieldCPF.setText(h.getCpf() != null ? h.getCpf() : "");
                jTextFieldContato.setText(h.getContato() != null ? h.getContato() : "");
                jTextFieldTelefone.setText(h.getFone1() != null ? h.getFone1() : "");
                jTextFieldTelefone2.setText(h.getFone2() != null ? h.getFone2() : "");
            }
        }
    }

    /*
     * Preenche os campos da aba Check-Out com os dados de um Check.
     */
    private void preencherCamposCheckOut(Check check) {
        jTextFieldDataHoraEntrada2.setText(check.getDataHoraEntrada() != null ? check.getDataHoraEntrada() : "");
        jTextFieldDataHoraSaida2.setText(check.getDataHoraSaida() != null ? check.getDataHoraSaida() : "");
        jTextFieldObservacao2.setText(check.getObs() != null ? check.getObs() : "");

        CheckQuarto cq = check.getCheckQuarto();
        if (cq != null && cq.getQuarto() != null) {
            jTextFieldQuarto2.setText(cq.getQuarto().getIdentificacao() != null ? cq.getQuarto().getIdentificacao() : "");
            jTextFieldAndar2.setText(String.valueOf(cq.getQuarto().getAndar()));
        }

        CheckHospede ch = checkDAO.buscarHospedeDoCheck(check.getId());
        if (ch != null && ch.getHospede() != null) {
            Hospede h = ch.getHospede();
            jTextFieldHospede2.setText(h.getNome() != null ? h.getNome() : "");
            jTextFieldCPF2.setText(h.getCpf() != null ? h.getCpf() : "");
            jTextFieldCNPJ2.setText(h.getCnpj() != null ? h.getCnpj() : "");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator2 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jlabelNumeroReserva = new javax.swing.JLabel();
        jTextFieldNumeroReserva = new javax.swing.JTextField();
        jLabelDataHoraEntrada = new javax.swing.JLabel();
        jLabelDataHoraSaida = new javax.swing.JLabel();
        jTextFieldDataHoraEntrada = new javax.swing.JTextField();
        jTextFieldDataHoraSaida = new javax.swing.JTextField();
        jLabelVeiculo = new javax.swing.JLabel();
        jTextFieldVeiculo = new javax.swing.JTextField();
        jLabelVagaEstacionamento = new javax.swing.JLabel();
        jTextFieldVagaEstacionamento = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabelDadosHospede = new javax.swing.JLabel();
        jLabelNome = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jLabelCNPJ = new javax.swing.JLabel();
        jTextFieldCNPJ = new javax.swing.JTextField();
        jLabelDadosReserva = new javax.swing.JLabel();
        jLabel1NumeroQuarto = new javax.swing.JLabel();
        jTextFieldNumeroQuarto = new javax.swing.JTextField();
        jLabelAndarQuarto = new javax.swing.JLabel();
        jTextFieldAndarQuarto = new javax.swing.JTextField();
        jLabelCapacidadeQuarto = new javax.swing.JLabel();
        jTextFieldCapacidadeQuarto = new javax.swing.JTextField();
        jLabelCPF = new javax.swing.JLabel();
        jTextFieldCPF = new javax.swing.JTextField();
        jLabelContato = new javax.swing.JLabel();
        jTextFieldContato = new javax.swing.JTextField();
        jLabelTelefone1 = new javax.swing.JLabel();
        jTextFieldTelefone = new javax.swing.JTextField();
        jLabelPossuiAnimais = new javax.swing.JLabel();
        jComboBoxPossuiAnimais = new javax.swing.JComboBox<>();
        jLabelHoraInicio = new javax.swing.JLabel();
        jTextFieldHoraInicio = new javax.swing.JTextField();
        jLabelHoraTermino = new javax.swing.JLabel();
        jTextFieldHoraTermino = new javax.swing.JTextField();
        jLabelPlaca = new javax.swing.JLabel();
        jTextFieldPlaca = new javax.swing.JTextField();
        jLabelCor = new javax.swing.JLabel();
        jComboBoxCor = new javax.swing.JComboBox<>();
        jLabelTipoHospede = new javax.swing.JLabel();
        jComboBoxTipoHospede = new javax.swing.JComboBox<>();
        jLabelObservacao = new javax.swing.JLabel();
        jTextFieldObservacao = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jButtonNovo1 = new javax.swing.JButton();
        jButtonCancelar1 = new javax.swing.JButton();
        jButtonBuscar1 = new javax.swing.JButton();
        jButtonSair1 = new javax.swing.JButton();
        jButtonGravar1 = new javax.swing.JButton();
        jLabelTelefone2 = new javax.swing.JLabel();
        jTextFieldTelefone2 = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabelHospede2 = new javax.swing.JLabel();
        jLabelQuarto2 = new javax.swing.JLabel();
        jLabelDataHoraEntrada2 = new javax.swing.JLabel();
        jLabelDataHoraSaida2 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jTextFieldHospede2 = new javax.swing.JTextField();
        jLabelCPF2 = new javax.swing.JLabel();
        jLabelCNPJ2 = new javax.swing.JLabel();
        jLabelAndar2 = new javax.swing.JLabel();
        jTextFieldCPF2 = new javax.swing.JTextField();
        jTextFieldCNPJ2 = new javax.swing.JTextField();
        jLabelDadosHospede2 = new javax.swing.JLabel();
        jTextFieldQuarto2 = new javax.swing.JTextField();
        jTextFieldDataHoraEntrada2 = new javax.swing.JTextField();
        jTextFieldDataHoraSaida2 = new javax.swing.JTextField();
        jTextFieldAndar2 = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jTextFieldTotal = new javax.swing.JTextField();
        jLabelTotal = new javax.swing.JLabel();
        jLabelObservacao2 = new javax.swing.JLabel();
        jTextFieldObservacao2 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jButtonNovo = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonBuscar = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();
        jButtonGravar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(102, 102, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Movimentos");
        jLabel1.setToolTipText("");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jlabelNumeroReserva.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jlabelNumeroReserva.setText("Número da Reserva");

        jLabelDataHoraEntrada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelDataHoraEntrada.setText("Data/Hora Entrada");

        jLabelDataHoraSaida.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelDataHoraSaida.setText("Data/Hora Saida");

        jTextFieldDataHoraSaida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldDataHoraSaidaActionPerformed(evt);
            }
        });

        jLabelVeiculo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelVeiculo.setText("Veículo");

        jLabelVagaEstacionamento.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelVagaEstacionamento.setText("Vaga de Estacionamento");

        jLabelDadosHospede.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelDadosHospede.setText("Dados do Hóspede");

        jLabelNome.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelNome.setText("Nome / Razão Social");

        jLabelCNPJ.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelCNPJ.setText("CNPJ");
        jLabelCNPJ.setInheritsPopupMenu(false);

        jTextFieldCNPJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCNPJActionPerformed(evt);
            }
        });

        jLabelDadosReserva.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelDadosReserva.setText("Dados de Reserva");

        jLabel1NumeroQuarto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1NumeroQuarto.setText("Número Quarto Reservado");

        jLabelAndarQuarto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelAndarQuarto.setText("Andar Quarto");

        jLabelCapacidadeQuarto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelCapacidadeQuarto.setText("Capacidade do Quarto");

        jLabelCPF.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelCPF.setText("CPF");

        jLabelContato.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelContato.setText("Contato");

        jLabelTelefone1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelTelefone1.setText("Telefone 1");

        jLabelPossuiAnimais.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelPossuiAnimais.setText("Possui Animais");

        jComboBoxPossuiAnimais.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sim", "Não", " " }));
        jComboBoxPossuiAnimais.setSelectedIndex(-1);

        jLabelHoraInicio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelHoraInicio.setText("Hora de Início");

        jLabelHoraTermino.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelHoraTermino.setText("Hora de Término");

        jLabelPlaca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelPlaca.setText("Placa");

        jTextFieldPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldPlacaActionPerformed(evt);
            }
        });

        jLabelCor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelCor.setText("Cor");

        jComboBoxCor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Preto", "Prata", "Branco", "Vermelho", "Azul", "Verde", "Amarelo", "Violeta", "Laranja", "Marrom", "Rosa" }));
        jComboBoxCor.setSelectedIndex(-1);
        jComboBoxCor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCorActionPerformed(evt);
            }
        });

        jLabelTipoHospede.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelTipoHospede.setText("Tipo de Hóspede");

        jComboBoxTipoHospede.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Funcionario", "Hospede", "Fornecedor" }));
        jComboBoxTipoHospede.setSelectedIndex(-1);

        jLabelObservacao.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelObservacao.setText("Observação");

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel4.setPreferredSize(new java.awt.Dimension(821, 51));

        jButtonNovo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Create.png"))); // NOI18N
        jButtonNovo1.setText("Novo");
        jButtonNovo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovo1ActionPerformed(evt);
            }
        });

        jButtonCancelar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Cancel.png"))); // NOI18N
        jButtonCancelar1.setText("Cancelar");

        jButtonBuscar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Find.png"))); // NOI18N
        jButtonBuscar1.setText("Buscar");

        jButtonSair1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Exit.png"))); // NOI18N
        jButtonSair1.setText("Sair");

        jButtonGravar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Load.png"))); // NOI18N
        jButtonGravar1.setText("Gravar");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addComponent(jButtonNovo1)
                .addGap(108, 108, 108)
                .addComponent(jButtonCancelar1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 140, Short.MAX_VALUE)
                .addComponent(jButtonGravar1)
                .addGap(133, 133, 133)
                .addComponent(jButtonBuscar1)
                .addGap(114, 114, 114)
                .addComponent(jButtonSair1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(110, 110, 110))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonNovo1)
                    .addComponent(jButtonCancelar1)
                    .addComponent(jButtonBuscar1)
                    .addComponent(jButtonSair1)
                    .addComponent(jButtonGravar1))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jLabelTelefone2.setFont(new java.awt.Font("Liberation Sans", 1, 12)); // NOI18N
        jLabelTelefone2.setText("Telefone 2");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jSeparator1)
                        .addGap(6, 6, 6))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabelDadosReserva)
                        .addContainerGap(1196, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlabelNumeroReserva)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jTextFieldDataHoraEntrada, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                                .addComponent(jTextFieldDataHoraSaida, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextFieldNumeroReserva, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabelDataHoraEntrada)
                            .addComponent(jLabelDataHoraSaida))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1NumeroQuarto, javax.swing.GroupLayout.DEFAULT_SIZE, 287, Short.MAX_VALUE)
                            .addComponent(jTextFieldAndarQuarto)
                            .addComponent(jTextFieldNumeroQuarto)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelCapacidadeQuarto)
                                    .addComponent(jLabelAndarQuarto))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jTextFieldCapacidadeQuarto))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelPossuiAnimais)
                                    .addComponent(jLabelHoraInicio)
                                    .addComponent(jLabelHoraTermino))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jTextFieldHoraTermino)
                            .addComponent(jComboBoxPossuiAnimais, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jTextFieldHoraInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelTipoHospede)
                            .addComponent(jLabelObservacao)
                            .addComponent(jTextFieldObservacao)
                            .addComponent(jComboBoxTipoHospede, 0, 387, Short.MAX_VALUE))
                        .addGap(16, 16, 16))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelNome)
                            .addComponent(jLabelDadosHospede, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelCNPJ)
                            .addComponent(jLabelCPF)
                            .addComponent(jTextFieldNome, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                            .addComponent(jTextFieldCNPJ)
                            .addComponent(jTextFieldCPF))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldContato, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelContato))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelTelefone1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabelTelefone2)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jTextFieldTelefone2)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jTextFieldVeiculo)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabelVeiculo)
                                        .addGap(264, 264, 264)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelCor)
                                    .addComponent(jComboBoxCor, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabelVagaEstacionamento)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jTextFieldVagaEstacionamento))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelPlaca)
                                    .addComponent(jTextFieldPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(80, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelDadosReserva)
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jlabelNumeroReserva)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldNumeroReserva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelDataHoraEntrada)
                        .addGap(15, 15, 15)
                        .addComponent(jTextFieldDataHoraEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jLabelDataHoraSaida)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextFieldDataHoraSaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1NumeroQuarto)
                            .addComponent(jLabelPossuiAnimais)
                            .addComponent(jLabelTipoHospede))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldNumeroQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxPossuiAnimais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxTipoHospede, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelAndarQuarto)
                            .addComponent(jLabelHoraInicio)
                            .addComponent(jLabelObservacao))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextFieldAndarQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldHoraInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(15, 15, 15)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabelCapacidadeQuarto)
                                    .addComponent(jLabelHoraTermino))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextFieldCapacidadeQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldHoraTermino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jTextFieldObservacao))))
                .addGap(31, 31, 31)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabelDadosHospede, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(jLabelNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelCNPJ)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldCNPJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelCPF)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelContato)
                            .addComponent(jLabelTelefone1)
                            .addComponent(jLabelTelefone2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldContato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextFieldTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextFieldTelefone2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCor)
                            .addComponent(jLabelVeiculo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBoxCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelPlaca, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelVagaEstacionamento))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldVagaEstacionamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        jTabbedPane1.addTab("Check-In", jPanel2);

        jLabelHospede2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelHospede2.setText("Hóspede");

        jLabelQuarto2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelQuarto2.setText("Quarto");

        jLabelDataHoraEntrada2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelDataHoraEntrada2.setText("Data/Hora Entrada");

        jLabelDataHoraSaida2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelDataHoraSaida2.setText("Data/Hora Saída");

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel28.setText("Pagamento");

        jLabelCPF2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelCPF2.setText("CPF");

        jLabelCNPJ2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelCNPJ2.setText("CNPJ");

        jLabelAndar2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelAndar2.setText("Andar");

        jLabelDadosHospede2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelDadosHospede2.setText("Dados Hóspede");

        jTextFieldDataHoraSaida2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldDataHoraSaida2ActionPerformed(evt);
            }
        });

        jTextFieldAndar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldAndar2ActionPerformed(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel33.setText("Consumos");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Tipo", "Descrição / Produto", "Data/Hora", "Qtd", "Valor Unit", "Total(R$)"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jTextFieldTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldTotalActionPerformed(evt);
            }
        });

        jLabelTotal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabelTotal.setText("Total (R$)");

        jLabelObservacao2.setFont(new java.awt.Font("Liberation Sans", 1, 12)); // NOI18N
        jLabelObservacao2.setText("Observação");

        jTextFieldObservacao2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldObservacao2ActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setPreferredSize(new java.awt.Dimension(821, 51));

        jButtonNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Create.png"))); // NOI18N
        jButtonNovo.setText("Novo");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });

        jButtonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Cancel.png"))); // NOI18N
        jButtonCancelar.setText("Cancelar");

        jButtonBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Find.png"))); // NOI18N
        jButtonBuscar.setText("Buscar");

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Exit.png"))); // NOI18N
        jButtonSair.setText("Sair");

        jButtonGravar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Load.png"))); // NOI18N
        jButtonGravar.setText("Gravar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jButtonNovo)
                .addGap(71, 71, 71)
                .addComponent(jButtonCancelar)
                .addGap(72, 72, 72)
                .addComponent(jButtonGravar)
                .addGap(72, 72, 72)
                .addComponent(jButtonBuscar)
                .addGap(71, 71, 71)
                .addComponent(jButtonSair)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonNovo)
                    .addComponent(jButtonCancelar)
                    .addComponent(jButtonBuscar)
                    .addComponent(jButtonSair)
                    .addComponent(jButtonGravar))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldAndar2)
                    .addComponent(jLabelDataHoraSaida2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextFieldDataHoraSaida2)
                    .addComponent(jTextFieldTotal)
                    .addComponent(jTextFieldObservacao2)
                    .addComponent(jTextFieldDataHoraEntrada2)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCPF2)
                            .addComponent(jLabelCNPJ2)
                            .addComponent(jLabelQuarto2)
                            .addComponent(jLabelDadosHospede2)
                            .addComponent(jLabelHospede2)
                            .addComponent(jLabelAndar2)
                            .addComponent(jLabelDataHoraEntrada2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelObservacao2))
                        .addGap(0, 44, Short.MAX_VALUE))
                    .addComponent(jTextFieldQuarto2)
                    .addComponent(jTextFieldCNPJ2)
                    .addComponent(jTextFieldCPF2)
                    .addComponent(jTextFieldHospede2))
                .addGap(46, 46, 46)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 934, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 934, Short.MAX_VALUE))
                .addGap(57, 57, 57))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDadosHospede2)
                    .addComponent(jLabel28))
                .addGap(24, 24, 24)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabelHospede2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldHospede2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelCPF2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldCPF2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelCNPJ2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldCNPJ2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelQuarto2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldQuarto2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelAndar2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldAndar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelDataHoraEntrada2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldDataHoraEntrada2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelDataHoraSaida2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldDataHoraSaida2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelTotal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextFieldTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelObservacao2))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextFieldObservacao2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Check-Out", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldDataHoraSaidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDataHoraSaidaActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldDataHoraSaidaActionPerformed

    private void jTextFieldCNPJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCNPJActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldCNPJActionPerformed

    private void jTextFieldPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldPlacaActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldPlacaActionPerformed

    private void jTextFieldAndar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldAndar2ActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldAndar2ActionPerformed

    private void jTextFieldTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldTotalActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldTotalActionPerformed

    private void jTextFieldDataHoraSaida2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDataHoraSaida2ActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldDataHoraSaida2ActionPerformed

    private void jTextFieldObservacao2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldObservacao2ActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jTextFieldObservacao2ActionPerformed

    private void jComboBoxCorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCorActionPerformed
        // sem ação necessária
    }//GEN-LAST:event_jComboBoxCorActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        limparCamposCheckOut();
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonNovo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovo1ActionPerformed
        limparCamposCheckIn();
    }//GEN-LAST:event_jButtonNovo1ActionPerformed

    // =========================================================
    // GRAVAR CHECK-IN
    // =========================================================
    private void gravarCheckIn() {
        try {
            String idTxt = jTextFieldNumeroReserva.getText().trim();
            Check check;

            if (idTxt.isEmpty()) {
                // Novo Check-In
                check = new Check();
                check.setStatus('A');
            } else {
                // Atualiza existente
                check = checkDAO.Retrieve(Integer.parseInt(idTxt));
                if (check == null) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Check-In não encontrado para atualização.");
                    return;
                }
            }

            check.setDataHoraEntrada(jTextFieldDataHoraEntrada.getText().trim());
            check.setDataHoraSaida(jTextFieldDataHoraSaida.getText().trim());
            check.setObs(jTextFieldObservacao.getText().trim());
            check.setDataHoraCadastro(new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date()));

            if (idTxt.isEmpty()) {
                checkDAO.Create(check);
            } else {
                checkDAO.Update(check);
            }

            javax.swing.JOptionPane.showMessageDialog(this, "Check-In gravado com sucesso!");
            carregarCheckIn();
        } catch (Exception ex) {
            ex.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this, "Erro ao gravar Check-In: " + ex.getMessage());
        }
    }

    // =========================================================
    // GRAVAR CHECK-OUT: registra dataHoraSaida no Check existente
    // =========================================================
    private void gravarCheckOut() {
        try {
            String hospedeTxt = jTextFieldHospede2.getText().trim();
            String quartoTxt  = jTextFieldQuarto2.getText().trim();

            if (hospedeTxt.isEmpty() && quartoTxt.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Carregue um Check-Out antes de gravar.");
                return;
            }

            // Busca o check ativo sem saída pelo quarto ou pelo hóspede
            List<Check> pendentes = checkDAO.buscarCheckIns();
            Check checkAlvo = null;
            for (Check c : pendentes) {
                model.CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
                if (ch != null && ch.getHospede() != null) {
                    String nomeHospede = ch.getHospede().getNome() != null ? ch.getHospede().getNome() : "";
                    if (!hospedeTxt.isEmpty() && nomeHospede.toLowerCase().contains(hospedeTxt.toLowerCase())) {
                        checkAlvo = c;
                        break;
                    }
                }
                if (c.getCheckQuarto() != null && c.getCheckQuarto().getQuarto() != null) {
                    String ident = c.getCheckQuarto().getQuarto().getIdentificacao() != null
                            ? c.getCheckQuarto().getQuarto().getIdentificacao() : "";
                    if (!quartoTxt.isEmpty() && ident.equalsIgnoreCase(quartoTxt)) {
                        checkAlvo = c;
                        break;
                    }
                }
            }

            if (checkAlvo == null) {
                javax.swing.JOptionPane.showMessageDialog(this, "Nenhum Check-In ativo encontrado para esse hóspede/quarto.");
                return;
            }

            String saida = jTextFieldDataHoraSaida2.getText().trim();
            if (saida.isEmpty()) {
                saida = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date());
            }
            checkAlvo.setDataHoraSaida(saida);
            checkAlvo.setObs(jTextFieldObservacao2.getText().trim());
            checkDAO.Update(checkAlvo);

            javax.swing.JOptionPane.showMessageDialog(this, "Check-Out registrado com sucesso!");
            limparCamposCheckOut();
        } catch (Exception ex) {
            ex.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this, "Erro ao gravar Check-Out: " + ex.getMessage());
        }
    }

    /*
     * Busca Check-In pelo número digitado no campo Número da Reserva (id).
     */
    private void buscarCheckInPorId() {
        try {
            String texto = jTextFieldNumeroReserva.getText().trim();
            if (!texto.isEmpty()) {
                int id = Integer.parseInt(texto);
                Check check = checkDAO.Retrieve(id);
                if (check != null) {
                    preencherCamposCheckIn(check);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(this, "Nenhum Check-In encontrado para o ID informado.");
                }
            } else {
                carregarCheckIn();
            }
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Digite um número válido no campo Número da Reserva.");
        }
    }

    /*
     * Limpa os campos da aba Check-In.
     */
    private void limparCamposCheckIn() {
        jTextFieldNumeroReserva.setText("");
        jTextFieldDataHoraEntrada.setText("");
        jTextFieldDataHoraSaida.setText("");
        jTextFieldNumeroQuarto.setText("");
        jTextFieldAndarQuarto.setText("");
        jTextFieldCapacidadeQuarto.setText("");
        jTextFieldHoraInicio.setText("");
        jTextFieldHoraTermino.setText("");
        jTextFieldNome.setText("");
        jTextFieldCNPJ.setText("");
        jTextFieldCPF.setText("");
        jTextFieldContato.setText("");
        jTextFieldTelefone.setText("");
        jTextFieldTelefone2.setText("");
        jTextFieldObservacao.setText("");
        jTextFieldVeiculo.setText("");
        jTextFieldVagaEstacionamento.setText("");
        jTextFieldPlaca.setText("");
        jComboBoxPossuiAnimais.setSelectedIndex(-1);
        jComboBoxTipoHospede.setSelectedIndex(-1);
        jComboBoxCor.setSelectedIndex(-1);
    }

    /*
     * Limpa os campos da aba Check-Out.
     */
    private void limparCamposCheckOut() {
        jTextFieldHospede2.setText("");
        jTextFieldCPF2.setText("");
        jTextFieldCNPJ2.setText("");
        jTextFieldQuarto2.setText("");
        jTextFieldAndar2.setText("");
        jTextFieldDataHoraEntrada2.setText("");
        jTextFieldDataHoraSaida2.setText("");
        jTextFieldTotal.setText("");
        jTextFieldObservacao2.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TemplateCadastro2025.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TemplateCadastro2025.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TemplateCadastro2025.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TemplateCadastro2025.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TemplateCadastro2025 dialog = new TemplateCadastro2025(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBuscar;
    private javax.swing.JButton jButtonBuscar1;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonCancelar1;
    private javax.swing.JButton jButtonGravar;
    private javax.swing.JButton jButtonGravar1;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonNovo1;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSair1;
    private javax.swing.JComboBox<String> jComboBoxCor;
    private javax.swing.JComboBox<String> jComboBoxPossuiAnimais;
    private javax.swing.JComboBox<String> jComboBoxTipoHospede;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel1NumeroQuarto;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabelAndar2;
    private javax.swing.JLabel jLabelAndarQuarto;
    private javax.swing.JLabel jLabelCNPJ;
    private javax.swing.JLabel jLabelCNPJ2;
    private javax.swing.JLabel jLabelCPF;
    private javax.swing.JLabel jLabelCPF2;
    private javax.swing.JLabel jLabelCapacidadeQuarto;
    private javax.swing.JLabel jLabelContato;
    private javax.swing.JLabel jLabelCor;
    private javax.swing.JLabel jLabelDadosHospede;
    private javax.swing.JLabel jLabelDadosHospede2;
    private javax.swing.JLabel jLabelDadosReserva;
    private javax.swing.JLabel jLabelDataHoraEntrada;
    private javax.swing.JLabel jLabelDataHoraEntrada2;
    private javax.swing.JLabel jLabelDataHoraSaida;
    private javax.swing.JLabel jLabelDataHoraSaida2;
    private javax.swing.JLabel jLabelHoraInicio;
    private javax.swing.JLabel jLabelHoraTermino;
    private javax.swing.JLabel jLabelHospede2;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelObservacao;
    private javax.swing.JLabel jLabelObservacao2;
    private javax.swing.JLabel jLabelPlaca;
    private javax.swing.JLabel jLabelPossuiAnimais;
    private javax.swing.JLabel jLabelQuarto2;
    private javax.swing.JLabel jLabelTelefone1;
    private javax.swing.JLabel jLabelTelefone2;
    private javax.swing.JLabel jLabelTipoHospede;
    private javax.swing.JLabel jLabelTotal;
    private javax.swing.JLabel jLabelVagaEstacionamento;
    private javax.swing.JLabel jLabelVeiculo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextFieldAndar2;
    private javax.swing.JTextField jTextFieldAndarQuarto;
    private javax.swing.JTextField jTextFieldCNPJ;
    private javax.swing.JTextField jTextFieldCNPJ2;
    private javax.swing.JTextField jTextFieldCPF;
    private javax.swing.JTextField jTextFieldCPF2;
    private javax.swing.JTextField jTextFieldCapacidadeQuarto;
    private javax.swing.JTextField jTextFieldContato;
    private javax.swing.JTextField jTextFieldDataHoraEntrada;
    private javax.swing.JTextField jTextFieldDataHoraEntrada2;
    private javax.swing.JTextField jTextFieldDataHoraSaida;
    private javax.swing.JTextField jTextFieldDataHoraSaida2;
    private javax.swing.JTextField jTextFieldHoraInicio;
    private javax.swing.JTextField jTextFieldHoraTermino;
    private javax.swing.JTextField jTextFieldHospede2;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldNumeroQuarto;
    private javax.swing.JTextField jTextFieldNumeroReserva;
    private javax.swing.JTextField jTextFieldObservacao;
    private javax.swing.JTextField jTextFieldObservacao2;
    private javax.swing.JTextField jTextFieldPlaca;
    private javax.swing.JTextField jTextFieldQuarto2;
    private javax.swing.JTextField jTextFieldTelefone;
    private javax.swing.JTextField jTextFieldTelefone2;
    private javax.swing.JTextField jTextFieldTotal;
    private javax.swing.JTextField jTextFieldVagaEstacionamento;
    private javax.swing.JTextField jTextFieldVeiculo;
    private javax.swing.JLabel jlabelNumeroReserva;
    // End of variables declaration//GEN-END:variables

    // ── Botões adicionados fora do bloco gerado (busca de Hóspede e Quarto) ──
    private javax.swing.JButton btnBuscarHospedeCheckIn  = new javax.swing.JButton("Buscar Hóspede");
    private javax.swing.JButton btnBuscarQuartoCheckIn   = new javax.swing.JButton("Buscar Quarto");
    private javax.swing.JButton btnBuscarHospedeCheckOut = new javax.swing.JButton("Buscar Hóspede");

    // ── Getters para o ControllerMovimentos ──────────────────────────────────
    public javax.swing.JButton getBtnBuscarHospedeCheckIn()  { return btnBuscarHospedeCheckIn; }
    public javax.swing.JButton getBtnBuscarQuartoCheckIn()   { return btnBuscarQuartoCheckIn; }
    public javax.swing.JButton getBtnBuscarHospedeCheckOut() { return btnBuscarHospedeCheckOut; }
    public javax.swing.JButton getBtnNovo1()      { return jButtonNovo1; }
    public javax.swing.JButton getBtnGravar1()    { return jButtonGravar1; }
    public javax.swing.JButton getBtnCancelar1()  { return jButtonCancelar1; }
    public javax.swing.JButton getBtnSair1()      { return jButtonSair1; }
    public javax.swing.JButton getBtnBuscar1()    { return jButtonBuscar1; }
    public javax.swing.JButton getBtnNovo()       { return jButtonNovo; }
    public javax.swing.JButton getBtnGravar()     { return jButtonGravar; }
    public javax.swing.JButton getBtnCancelar()   { return jButtonCancelar; }
    public javax.swing.JButton getBtnSair()       { return jButtonSair; }
    public javax.swing.JButton getBtnBuscar()     { return jButtonBuscar; }
    public javax.swing.JTabbedPane getjTabbedPane1()            { return jTabbedPane1; }
    public javax.swing.JTextField getjTextFieldNumeroReserva()  { return jTextFieldNumeroReserva; }
    public javax.swing.JTextField getjTextFieldDataHoraEntrada(){ return jTextFieldDataHoraEntrada; }
    public javax.swing.JTextField getjTextFieldDataHoraSaida()  { return jTextFieldDataHoraSaida; }
    public javax.swing.JTextField getjTextFieldNumeroQuarto()   { return jTextFieldNumeroQuarto; }
    public javax.swing.JTextField getjTextFieldAndarQuarto()    { return jTextFieldAndarQuarto; }
    public javax.swing.JTextField getjTextFieldCapacidadeQuarto(){ return jTextFieldCapacidadeQuarto; }
    public javax.swing.JTextField getjTextFieldHoraInicio()     { return jTextFieldHoraInicio; }
    public javax.swing.JTextField getjTextFieldHoraTermino()    { return jTextFieldHoraTermino; }
    public javax.swing.JTextField getjTextFieldNome()           { return jTextFieldNome; }
    public javax.swing.JTextField getjTextFieldCNPJ()           { return jTextFieldCNPJ; }
    public javax.swing.JTextField getjTextFieldCPF()            { return jTextFieldCPF; }
    public javax.swing.JTextField getjTextFieldContato()        { return jTextFieldContato; }
    public javax.swing.JTextField getjTextFieldTelefone()       { return jTextFieldTelefone; }
    public javax.swing.JTextField getjTextFieldTelefone2()      { return jTextFieldTelefone2; }
    public javax.swing.JTextField getjTextFieldObservacao()     { return jTextFieldObservacao; }
    public javax.swing.JTextField getjTextFieldVeiculo()        { return jTextFieldVeiculo; }
    public javax.swing.JTextField getjTextFieldVagaEstacionamento(){ return jTextFieldVagaEstacionamento; }
    public javax.swing.JTextField getjTextFieldPlaca()          { return jTextFieldPlaca; }
    public javax.swing.JComboBox<String> getjComboBoxPossuiAnimais(){ return jComboBoxPossuiAnimais; }
    public javax.swing.JComboBox<String> getjComboBoxTipoHospede()  { return jComboBoxTipoHospede; }
    public javax.swing.JComboBox<String> getjComboBoxCor()          { return jComboBoxCor; }
    // Check-Out
    public javax.swing.JTextField getjTextFieldHospede2()       { return jTextFieldHospede2; }
    public javax.swing.JTextField getjTextFieldCPF2()           { return jTextFieldCPF2; }
    public javax.swing.JTextField getjTextFieldCNPJ2()          { return jTextFieldCNPJ2; }
    public javax.swing.JTextField getjTextFieldQuarto2()        { return jTextFieldQuarto2; }
    public javax.swing.JTextField getjTextFieldAndar2()         { return jTextFieldAndar2; }
    public javax.swing.JTextField getjTextFieldDataHoraEntrada2(){ return jTextFieldDataHoraEntrada2; }
    public javax.swing.JTextField getjTextFieldDataHoraSaida2() { return jTextFieldDataHoraSaida2; }
    public javax.swing.JTextField getjTextFieldTotal()          { return jTextFieldTotal; }
    public javax.swing.JTextField getjTextFieldObservacao2()    { return jTextFieldObservacao2; }
}
