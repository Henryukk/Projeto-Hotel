/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Utilities {

    /**
     * Converte data de dd/MM/yyyy para yyyy-MM-dd (formato MySQL).
     * Se já estiver no formato correto ou vazia, retorna como está.
     */
    public static String converterData(String data) {
        if (data == null) return null;
        data = data.trim();
        if (data.isEmpty()) return null;
        try {
            // dd/MM/yyyy → yyyy-MM-dd
            if (data.matches("\\d{2}/\\d{2}/\\d{4}")) {
                String[] partes = data.split("/");
                return partes[2] + "-" + partes[1] + "-" + partes[0];
            }
            // já está em yyyy-MM-dd, retorna direto
            if (data.matches("\\d{4}-\\d{2}-\\d{2}.*")) {
                return data;
            }
        } catch (Exception e) {
            // ignora e retorna null para não quebrar o banco
        }
        return null;
    }

    public static void ativaDesativa(JPanel painel, boolean ativa) {

        Component[] vetComponentes = painel.getComponents();
        for (Component componenteAtual : vetComponentes) {

            if (componenteAtual instanceof JButton) {
                if (((JButton) componenteAtual).getActionCommand() == "0") {
                    componenteAtual.setEnabled(ativa);
                } else {
                    componenteAtual.setEnabled(!ativa);
                }

            }
        }
    }
    /**
     * Converte data do formato do banco (yyyy-MM-dd ou yyyy-MM-dd HH:mm:ss)
     * para o formato de exibição na tela (dd/MM/yyyy).
     * Se já estiver em dd/MM/yyyy ou vazia, retorna como está.
     */
    public static String formatarDataParaExibicao(String data) {
        if (data == null || data.trim().isEmpty()) return "";
        data = data.trim();
        // yyyy-MM-dd HH:mm:ss ou yyyy-MM-dd HH:mm
        if (data.matches("\\d{4}-\\d{2}-\\d{2}.*")) {
            String[] partes = data.substring(0, 10).split("-");
            return partes[2] + "/" + partes[1] + "/" + partes[0];
        }
        // já está em dd/MM/yyyy
        if (data.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return data;
        }
        return data;
    }

        public static void limpaComponentes(JPanel painel, boolean ativa){
        Component [] vetComponents = painel.getComponents();
        for (Component componenteAtual : vetComponents) {
            if (componenteAtual instanceof JTextField) {
                ((JTextField) componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JFormattedTextField){
                ((JTextField)componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JComboBox){
                ((JComboBox) componenteAtual).setSelectedIndex(-1);
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JCheckBox){
                ((JCheckBox) componenteAtual).setSelected(false);
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JPasswordField){
                ((JPasswordField)componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JTextArea){
                ((JTextArea)componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }
        }
    }
}

