package utilities;

import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Utilities {

    public static void ativaDesativa(JPanel painel, boolean ativa) {
        Component[] vetComponentes = painel.getComponents();
        for (Component componenteAtual : vetComponentes) {

            if (componenteAtual instanceof JButton) {
                if (((JButton) componenteAtual).getActionCommand() == "0") {
                    componenteAtual.setEnabled(ativa);
                } else {
                    componenteAtual.setEnabled(!ativa);
                }
            }
        }
    }

    public static void limpaComponentes(JPanel painel, boolean ativa) {
        Component[] vetComponents = painel.getComponents();
        for (Component componenteAtual : vetComponents) {
            if (componenteAtual instanceof JTextField) {
                ((JTextField) componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            } else if (componenteAtual instanceof JFormattedTextField) {
                ((JFormattedTextField) componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            } else if (componenteAtual instanceof JComboBox) {
                ((JComboBox) componenteAtual).setSelectedIndex(-1);
                componenteAtual.setEnabled(ativa);
            } else if (componenteAtual instanceof JCheckBox) {
                ((JCheckBox) componenteAtual).setSelected(false);
                componenteAtual.setEnabled(ativa);
            } else if (componenteAtual instanceof JPasswordField) {
                ((JPasswordField) componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            } else if (componenteAtual instanceof JTextArea) {
                ((JTextArea) componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }
        }
    }

    //Validar cpf
    
    public static boolean validarCPF(String cpf) {

        if (cpf == null) return false;

        cpf = cpf.replace(".", "").replace("-", "").trim();

        if (cpf.length() != 11) return false;

        if (cpf.matches("(\\d)\\1{10}")) return false;

        try {
            int soma = 0;
            int peso = 10;

            for (int i = 0; i < 9; i++) {
                int num = cpf.charAt(i) - '0';
                soma += num * peso--;
            }

            int resto = soma % 11;
            int digito1 = (resto < 2) ? 0 : 11 - resto;

            if (digito1 != (cpf.charAt(9) - '0')) return false;

            soma = 0;
            peso = 11;

            for (int i = 0; i < 10; i++) {
                int num = cpf.charAt(i) - '0';
                soma += num * peso--;
            }

            resto = soma % 11;
            int digito2 = (resto < 2) ? 0 : 11 - resto;

            return digito2 == (cpf.charAt(10) - '0');

        } catch (Exception e) {
            return false;
        }
    }

    // ---------------------------------------------------------
    //                  VALIDAÇÃO CNPJ
    // ---------------------------------------------------------
    public static boolean validarCNPJ(String cnpj) {

        if (cnpj == null) return false;

        cnpj = cnpj.replace(".", "").replace("-", "").replace("/", "").trim();

        if (cnpj.length() != 14) return false;

        if (cnpj.matches("(\\d)\\1{13}")) return false;

        try {
            int soma = 0;
            int peso = 2;

            // Primeiro dígito
            for (int i = 11; i >= 0; i--) {
                soma += (cnpj.charAt(i) - '0') * peso;
                peso = (peso == 9 ? 2 : peso + 1);
            }

            int resto = soma % 11;
            int digito1 = (resto < 2) ? 0 : 11 - resto;

            if (digito1 != (cnpj.charAt(12) - '0')) return false;

            // Segundo dígito
            soma = 0;
            peso = 2;

            for (int i = 12; i >= 0; i--) {
                soma += (cnpj.charAt(i) - '0') * peso;
                peso = (peso == 9 ? 2 : peso + 1);
            }

            resto = soma % 11;
            int digito2 = (resto < 2) ? 0 : 11 - resto;

            return digito2 == (cnpj.charAt(13) - '0');

        } catch (Exception e) {
            return false;
        }
    }
}
