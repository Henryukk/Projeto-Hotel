package model.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Check;
import model.CheckQuarto;

public class CheckDAO implements InterfaceDAO<Check>{
    
    private static CheckDAO instance;
    protected EntityManager entityManager;

    public CheckDAO() {
        entityManager = getEntityManager();
    }

    public static CheckDAO getInstance() {
        if (instance == null) {
            instance = new CheckDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(Check objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public Check Retrieve(int id) {

        Check check = new Check();
        check = entityManager.find(Check.class, id);
        
        return check;
    }

    @Override
    public List<Check> Retrieve(String atributo, String valor) {

        List<Check> ListaCheck = new ArrayList<>();
        ListaCheck = entityManager.createQuery(
                    "SELECT che FROM Check che WHERE " +
                    (atributo.equalsIgnoreCase("status") ? "che.status = :valor" : "che." + atributo + " LIKE :valor"),
                    Check.class)
                .setParameter("valor", atributo.equalsIgnoreCase("status") ? valor.trim().charAt(0) : "%" + valor.trim() + "%")
                .getResultList();
                
        return ListaCheck;
    }

    @Override
    public void Update(Check objeto) {

        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(Check objeto) {
        try{
            entityManager.getTransaction().begin();
            Check check = new Check();
            check = entityManager.find(Check.class, objeto.getId());
            if (check != null) {
                entityManager.remove(check);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    /**
     * Retorna todos os Check-Ins (dataHoraSaida nula ou vazia = ainda hospedado).
     */
    public List<Check> buscarCheckIns() {
        return entityManager.createQuery(
            "SELECT c FROM Check c WHERE c.status = :status AND (c.dataHoraSaida IS NULL OR c.dataHoraSaida = '')",
            Check.class)
            .setParameter("status", 'A')
            .getResultList();
    }

    /**
     * Retorna todos os Check-Outs (dataHoraSaida preenchida).
     */
    public List<Check> buscarCheckOuts() {
        return entityManager.createQuery(
            "SELECT c FROM Check c WHERE c.status = :status AND c.dataHoraSaida IS NOT NULL AND c.dataHoraSaida <> ''",
            Check.class)
            .setParameter("status", 'A')
            .getResultList();
    }

    /**
     * Retorna o CheckHospede associado a um Check (primeiro hóspede encontrado).
     */
    public model.CheckHospede buscarHospedeDoCheck(int checkId) {
        List<model.CheckHospede> lista = entityManager.createQuery(
            "SELECT ch FROM CheckHospede ch WHERE ch.check.id = :checkId",
            model.CheckHospede.class)
            .setParameter("checkId", checkId)
            .setMaxResults(1)
            .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }
}