/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author aluno
 */
@Entity
public class Veiculo implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String placa;
    @Column
    private String cor;
    @ManyToOne
    @JoinColumn(name="modelo_id")
    private Modelo modelo;
    @ManyToOne
    @JoinColumn(name="hospede_id")
    private Hospede hospede;
    @ManyToOne
    @JoinColumn(name="funcionario_id")
    private Funcionario funcionario;
    @ManyToOne
    @JoinColumn(name="fornecedor_id")
    private Fornecedor fornecedor;
    @Column
    private char status;

    public Veiculo() {
    }

    public Veiculo(int id, String placa, String cor, Modelo modelo, Hospede hospede, Funcionario funcionario, Fornecedor fornecedor) {
        this.id = id;
        this.placa = placa;
        this.cor = cor;
        this.modelo = modelo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public Modelo getModelo() {
        return modelo;
    }

    public void setModelo(Modelo modelo) {
        this.modelo = modelo;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public Hospede getHospede() {
        return hospede;
    }

    public void setHospede(Hospede hospede) {
        this.hospede = hospede;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    @Override
    public String toString() {
        return "Id = " + this.getId()
                + "\nModelo = " + this.getModelo()
                + "\nCor = " + this.getCor()
                + "\nStatus = " + this.getStatus()
                + "\nPlaca = " + this.getPlaca();

    }

}
