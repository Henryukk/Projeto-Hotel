/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author aluno
 */
public class CheckHospede implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String tipoHospede;
    @Column
    private String obs;
    @Column
    private String status;
    @Column
    private Check check;
    @Column
    private Hospede hospede;

    public CheckHospede() {
    }

    public CheckHospede(int id, String tipoHospede, String obs, String status, Hospede hospede, Check check) {
        this.id = id;
        this.tipoHospede = tipoHospede;
        this.obs = obs;
        this.check= check;
        this.hospede= hospede;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoHospede() {
        return tipoHospede;
    }

    public void setTipoHospede(String tipoHospede) {
        this.tipoHospede = tipoHospede;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Check getCheck() {
        return check;
    }

    public void setCheck(Check check) {
        this.check = check;
    }

    public Hospede getHospede() {
        return hospede;
    }

    public void setHospede(Hospede hospede) {
        this.hospede = hospede;
    }
    

    @Override
    public String toString() {
        return "id = " + id + 
                "\ntipoHospede = " + tipoHospede + 
                "\nobs = " + obs + 
                "\nstatus = " + status;
    }
    
    
}
