package model.DAO;

import java.util.List;
import model.Fornecedor;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FornecedorDAO implements InterfaceDAO<Fornecedor> {
    
    private static FornecedorDAO instance;
    protected EntityManager entityManager;

    public FornecedorDAO() {
        entityManager = getEntityManager();
    }

    public static FornecedorDAO getInstance() {
        if (instance == null) {
            instance = new FornecedorDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU");
        if (entityManager == null) {
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    @Override
    public void Create(Fornecedor objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

     public Fornecedor Retrieve(int id) {
        entityManager.clear();
        java.util.List<Fornecedor> lista = entityManager.createQuery(
            "SELECT e FROM Fornecedor e WHERE e.id = :id", Fornecedor.class)
            .setParameter("id", id)
            .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }

    @Override
    public List<Fornecedor> Retrieve(String atributo, String valor) {

        entityManager.clear();
        List<Fornecedor> ListaFornecedor = new ArrayList<>();
        ListaFornecedor = entityManager.createQuery(
                    "SELECT func FROM Fornecedor func WHERE " +
                    (atributo.equalsIgnoreCase("status") ? "func.status = :valor" : "func." + atributo + " LIKE :valor"),
                    Fornecedor.class)
                .setParameter("valor", atributo.equalsIgnoreCase("status") ? valor.trim().charAt(0) : "%" + valor.trim() + "%")
                .getResultList();
                
        return ListaFornecedor;

    }

    @Override
    public void Update(Fornecedor objeto) {

        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    @Override
    public void Delete(Fornecedor objeto) {
        try{
            entityManager.getTransaction().begin();
            Fornecedor fornecedor = new Fornecedor();
            fornecedor = entityManager.find(Fornecedor.class, objeto.getId());
            if (fornecedor != null) {
                entityManager.remove(fornecedor);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}