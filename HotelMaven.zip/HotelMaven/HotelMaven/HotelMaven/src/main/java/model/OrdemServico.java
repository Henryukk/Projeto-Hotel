/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author aluno
 */
@Entity
public class OrdemServico implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String dataHoraCadastro;
    @Column
    private String dataHoraPrevistaInicio;
    @Column
    private String dataHoraPrevistaTermino;
    @Column
    private String obs;
    @Column
    private char status;
    @Column
    private int checkId;
    private int servicoId;
    private int quartoID;

    public OrdemServico() {
    }

    public OrdemServico(int id, String dataHoraCadastro, String dataHoraPrevistaInicio, String dataHoraPrevistaTermino, String obs, char status) {
        this.id = id;
        this.dataHoraCadastro = dataHoraCadastro;
        this.dataHoraPrevistaInicio = dataHoraPrevistaInicio;
        this.dataHoraPrevistaTermino = dataHoraPrevistaTermino;
        this.obs = obs;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataHoraCadastro() {
        return dataHoraCadastro;
    }

    public void setDataHoraCadastro(String dataHoraCadastro) {
        this.dataHoraCadastro = dataHoraCadastro;
    }

    public String getDataHoraPrevistaInicio() {
        return dataHoraPrevistaInicio;
    }

    public void setDataHoraPrevistaInicio(String dataHoraPrevistaInicio) {
        this.dataHoraPrevistaInicio = dataHoraPrevistaInicio;
    }

    public String getDataHoraPrevistaTermino() {
        return dataHoraPrevistaTermino;
    }

    public void setDataHoraPrevistaTermino(String dataHoraPrevistaTermino) {
        this.dataHoraPrevistaTermino = dataHoraPrevistaTermino;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public char getStatus() {
        return status;
    }

    public int getCheckId() {
        return checkId;
    }

    public void setCheckId(int checkId) {
        this.checkId = checkId;
    }

    public int getServicoId() {
        return servicoId;
    }

    public void setServicoId(int servicoId) {
        this.servicoId = servicoId;
    }

    public int getQuartoID() {
        return quartoID;
    }

    public void setQuartoID(int quartoID) {
        this.quartoID = quartoID;
    }
    

    public void setStatus(char status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "id = " + id + 
                "\ndataHoraCadastro = " + dataHoraCadastro + 
                "\ndataHoraPrevistaInicio = " + dataHoraPrevistaInicio + 
                "\ndataHoraPrevistaTermino = " + dataHoraPrevistaTermino + 
                "\nobs = " + obs + 
                "\nstatus = " + status;
    }
    
    
}
