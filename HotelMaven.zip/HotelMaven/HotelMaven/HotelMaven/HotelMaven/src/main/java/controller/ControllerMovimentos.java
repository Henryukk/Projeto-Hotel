package controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import model.Check;
import model.CheckHospede;
import model.CheckQuarto;
import model.Fornecedor;
import model.Funcionario;
import model.Hospede;
import model.Quarto;
import model.DAO.CheckDAO;
import model.DAO.CheckHospedeDAO;
import model.DAO.CheckQuartoDAO;
import view.TelaBuscaCheck;
import view.TelaBuscaFornecedor;
import view.TelaBuscaFuncionario;
import view.TelaBuscaQuarto;
import view.TelaBuscasHospede;
import view.TelaMovimentos;

public class ControllerMovimentos {

    public static int codigoHospede = 0;
    public static int codigoQuarto  = 0;

    private Check checkAtivoCheckOut = null;

    private final TelaMovimentos   tela;
    private final CheckDAO         checkDAO        = CheckDAO.getInstance();
    private final CheckQuartoDAO   checkQuartoDAO  = CheckQuartoDAO.getInstance();
    private final CheckHospedeDAO  checkHospedeDAO = CheckHospedeDAO.getInstance();
    private final SimpleDateFormat sdf             = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public ControllerMovimentos(TelaMovimentos tela) {
        this.tela = tela;
        registrarListeners();
    }

    // =========================================================================
    //  LISTENERS
    // =========================================================================
    private void registrarListeners() {

        // ABA CHECK-IN
        tela.getBtnBuscar1()              .addActionListener(e -> abrirMenuBuscaCheckIn());
        tela.getBtnBuscarHospedeCheckIn() .addActionListener(e -> abrirMenuBuscaCheckIn());
        tela.getBtnBuscarQuartoCheckIn()  .addActionListener(e -> abrirBuscaQuarto());
        tela.getBtnGravar1()              .addActionListener(e -> gravarCheckIn());
        tela.getBtnNovo1()                .addActionListener(e -> limparCheckIn());
        tela.getBtnCancelar1()            .addActionListener(e -> limparCheckIn());
        tela.getBtnSair1()                .addActionListener(e -> tela.dispose());

        // ABA CHECK-OUT — botão Buscar abre a TelaBuscaCheck
        tela.getBtnBuscar()               .addActionListener(e -> abrirBuscaCheck());
        tela.getBtnBuscarHospedeCheckOut().addActionListener(e -> abrirBuscaCheck());
        tela.getBtnGravar()               .addActionListener(e -> gravarCheckOut());
        tela.getBtnNovo()                 .addActionListener(e -> limparCheckOut());
        tela.getBtnCancelar()             .addActionListener(e -> limparCheckOut());
        tela.getBtnSair()                 .addActionListener(e -> tela.dispose());
    }

    // =========================================================================
    //  CHECK-IN — BUSCA
    // =========================================================================
    private void abrirMenuBuscaCheckIn() {
        String[] opcoes = {"Hospede", "Funcionario", "Fornecedor", "Quarto", "Veiculo"};
        int escolha = JOptionPane.showOptionDialog(
                tela, "O que deseja buscar?", "Buscar",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, opcoes, opcoes[0]);
        switch (escolha) {
            case 0: abrirBuscaHospede();     break;
            case 1: abrirBuscaFuncionario(); break;
            case 2: abrirBuscaFornecedor();  break;
            case 3: abrirBuscaQuarto();      break;
            case 4: abrirBuscaVeiculo();     break;
        }
    }

    private void abrirBuscaHospede() {
        ControllerCadHospede.codigo = 0;
        TelaBuscasHospede telaBusca = new TelaBuscasHospede(null, true);
        new ControllerBuscaHospede(telaBusca);
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadHospede.codigo;
        if (codigoHospede != 0) {
            Hospede h = service.HospedeService.Carregar(codigoHospede);
            if (h != null) preencherPessoaCheckIn(
                    h.getNome(), h.getCpf(), h.getCnpj(),
                    h.getContato(), h.getFone1(), h.getFone2(), "Hospede");
        }
    }

    private void abrirBuscaFuncionario() {
        ControllerCadFuncionario.codigo = 0;
        TelaBuscaFuncionario telaBusca = new TelaBuscaFuncionario(null, true);
        new ControllerBuscaFuncionario(telaBusca);
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadFuncionario.codigo;
        if (codigoHospede != 0) {
            Funcionario f = service.FuncionarioService.Carregar(codigoHospede);
            if (f != null) preencherPessoaCheckIn(
                    f.getNome(), f.getCpf(), "",
                    "", f.getFone1(), f.getFone2(), "Funcionario");
        }
    }

    private void abrirBuscaFornecedor() {
        ControllerCadFornecedor.codigo = 0;
        TelaBuscaFornecedor telaBusca = new TelaBuscaFornecedor(null, true);
        new ControllerBuscaFornecedor(telaBusca);
        telaBusca.setVisible(true);
        codigoHospede = ControllerCadFornecedor.codigo;
        if (codigoHospede != 0) {
            Fornecedor f = service.FornecedorService.Carregar(codigoHospede);
            if (f != null) preencherPessoaCheckIn(
                    f.getNome(), f.getCpf(), f.getCnpj(),
                    f.getContato(), f.getFone1(), f.getFone2(), "Fornecedor");
        }
    }

    private void preencherPessoaCheckIn(String nome, String cpf, String cnpj,
            String contato, String fone1, String fone2, String tipo) {
        tela.getjTextFieldNome()         .setText(nvl(nome));
        tela.getjTextFieldCPF()          .setText(nvl(cpf));
        tela.getjTextFieldCNPJ()         .setText(nvl(cnpj));
        tela.getjTextFieldContato()      .setText(nvl(contato));
        tela.getjTextFieldTelefone()     .setText(nvl(fone1));
        tela.getjTextFieldTelefone2()    .setText(nvl(fone2));
        tela.getjComboBoxTipoHospede()   .setSelectedItem(tipo);
    }

    private void abrirBuscaQuarto() {
        ControllerCadQuarto.codigo = 0;
        TelaBuscaQuarto telaBusca = new TelaBuscaQuarto(null, true);
        new ControllerBuscaQuarto(telaBusca);
        telaBusca.setVisible(true);
        codigoQuarto = ControllerCadQuarto.codigo;
        if (codigoQuarto != 0) {
            Quarto q = service.QuartoService.Carregar(codigoQuarto);
            if (q != null) {
                tela.getjTextFieldNumeroQuarto()    .setText(nvl(q.getIdentificacao()));
                tela.getjTextFieldAndarQuarto()     .setText(String.valueOf(q.getAndar()));
                tela.getjTextFieldCapacidadeQuarto().setText(String.valueOf(q.getCapacidadeHospedes()));
                tela.getjComboBoxPossuiAnimais()    .setSelectedItem(q.getFlagAnimais() ? "Sim" : "Não");
            }
        }
    }

    private void abrirBuscaVeiculo() {
        ControllerCadVeiculo.codigo = 0;
        view.TelaBuscaVeiculo telaBusca = new view.TelaBuscaVeiculo(null, true);
        new ControllerBuscaVeiculo(telaBusca);
        telaBusca.setVisible(true);
        int codigoVeiculo = ControllerCadVeiculo.codigo;
        if (codigoVeiculo != 0) {
            model.Veiculo v = service.VeiculoService.Carregar(codigoVeiculo);
            if (v != null) {
                tela.getjTextFieldPlaca()   .setText(nvl(v.getPlaca()));
                tela.getjComboBoxCor()      .setSelectedItem(nvl(v.getCor()));
                String desc = "";
                if (v.getModelo() != null) {
                    desc = nvl(v.getModelo().getDescricao());
                    if (v.getModelo().getMarca() != null)
                        desc = nvl(v.getModelo().getMarca().getDescricao()) + " / " + desc;
                }
                tela.getjTextFieldVeiculo().setText(desc);
            }
        }
    }

    // =========================================================================
    //  CHECK-IN — GRAVAR  (ordem: CheckQuarto → Check → CheckHospede)
    // =========================================================================
    private void gravarCheckIn() {
        if (codigoHospede == 0) {
            JOptionPane.showMessageDialog(tela, "Selecione um hóspede usando o botão Buscar.");
            return;
        }
        if (codigoQuarto == 0) {
            JOptionPane.showMessageDialog(tela, "Selecione um quarto usando o botão Buscar > Quarto.");
            return;
        }

        // Uma única transação / único EntityManager para evitar "detached entity"
        javax.persistence.EntityManager em = model.DAO.JPAUtil.createEntityManager();
        try {
            em.getTransaction().begin();

            String agora = sdf.format(new Date());

            // 1. Reanexar Quarto ao contexto atual e criar CheckQuarto
            model.Quarto quarto = em.find(model.Quarto.class, codigoQuarto);

            CheckQuarto cq = new CheckQuarto();
            cq.setQuarto(quarto);
            cq.setDataHoraInicio(textoOuAgora(tela.getjTextFieldHoraInicio().getText(), agora));
            cq.setDataHoraFim(textoOuNulo(tela.getjTextFieldHoraTermino().getText()));
            cq.setStatus('A');
            cq.setObs(textoOuNulo(tela.getjTextFieldObservacao().getText()));
            em.persist(cq);
            em.flush();

            // 2. Check
            Check check = new Check();
            check.setCheckQuarto(cq);
            check.setDataHoraCadastro(agora);
            check.setDataHoraEntrada(textoOuAgora(tela.getjTextFieldDataHoraEntrada().getText(), agora));
            check.setDataHoraSaida(textoOuNulo(tela.getjTextFieldDataHoraSaida().getText()));
            check.setObs(textoOuNulo(tela.getjTextFieldObservacao().getText()));
            check.setStatus('A');
            em.persist(check);
            em.flush();

            // 3. Reanexar Hospede e criar CheckHospede
            model.Hospede hospede = em.find(model.Hospede.class, codigoHospede);
            if (hospede != null) {
                CheckHospede ch = new CheckHospede();
                ch.setCheck(check);
                ch.setHospede(hospede);
                ch.setTipoHospede(
                        tela.getjComboBoxTipoHospede().getSelectedItem() != null
                        ? tela.getjComboBoxTipoHospede().getSelectedItem().toString()
                        : "Hospede");
                ch.setObs(null);
                ch.setStatus("A");
                em.persist(ch);
            }

            em.getTransaction().commit();

            JOptionPane.showMessageDialog(tela,
                    "Check-In gravado com sucesso!\nID do Check: " + check.getId());
            tela.getjTextFieldNumeroReserva().setText(String.valueOf(check.getId()));

        } catch (Exception ex) {
            ex.printStackTrace();
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            JOptionPane.showMessageDialog(tela, "Erro ao gravar Check-In:\n" + ex.getMessage());
        } finally {
            em.close();
        }
    }

    // =========================================================================
    //  CHECK-OUT — BUSCA  (usa TelaBuscaCheck)
    // =========================================================================
    private void abrirBuscaCheck() {
        ControllerBuscaCheck.codigo = 0;

        TelaBuscaCheck telaBusca = new TelaBuscaCheck(null, true);
        new ControllerBuscaCheck(telaBusca);
        telaBusca.setVisible(true);

        int idCheck = ControllerBuscaCheck.codigo;
        if (idCheck == 0) return;

        try {
            Check check = checkDAO.Retrieve(idCheck);
            if (check == null) {
                JOptionPane.showMessageDialog(tela, "Check não encontrado.");
                return;
            }

            if (check.getStatus() == 'F') {
                int confirmar = JOptionPane.showConfirmDialog(tela,
                        "Este Check já foi finalizado (status Fechado).\nDeseja carregá-lo mesmo assim?",
                        "Check já fechado", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (confirmar != JOptionPane.YES_OPTION) return;
            }

            checkAtivoCheckOut = check;
            preencherCamposCheckOut(check);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela, "Erro ao carregar Check:\n" + ex.getMessage());
        }
    }

    private void preencherCamposCheckOut(Check c) {
        // Dados do Check
        tela.getjTextFieldDataHoraEntrada2().setText(nvl(c.getDataHoraEntrada()));
        tela.getjTextFieldDataHoraSaida2()  .setText(nvl(c.getDataHoraSaida()));
        tela.getjTextFieldObservacao2()     .setText(nvl(c.getObs()));

        // Dados do Quarto
        CheckQuarto cq = c.getCheckQuarto();
        if (cq != null && cq.getQuarto() != null) {
            tela.getjTextFieldQuarto2().setText(nvl(cq.getQuarto().getIdentificacao()));
            tela.getjTextFieldAndar2() .setText(String.valueOf(cq.getQuarto().getAndar()));
        }

        // Dados do Hóspede
        CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
        if (ch != null && ch.getHospede() != null) {
            tela.getjTextFieldHospede2().setText(nvl(ch.getHospede().getNome()));
            tela.getjTextFieldCPF2()    .setText(nvl(ch.getHospede().getCpf()));
            tela.getjTextFieldCNPJ2()   .setText(nvl(ch.getHospede().getCnpj()));
        }

        tela.getjTextFieldTotal().setText("0,00");
    }

    // =========================================================================
    //  CHECK-OUT — GRAVAR
    // =========================================================================
    private void gravarCheckOut() {
        if (checkAtivoCheckOut == null) {
            JOptionPane.showMessageDialog(tela,
                    "Use o botão Buscar para localizar o Check-In antes de gravar.");
            return;
        }
        try {
            String saida = tela.getjTextFieldDataHoraSaida2().getText().trim();
            if (saida.isEmpty()) {
                saida = sdf.format(new Date());
                tela.getjTextFieldDataHoraSaida2().setText(saida);
            }
            checkAtivoCheckOut.setDataHoraSaida(saida);
            checkAtivoCheckOut.setObs(tela.getjTextFieldObservacao2().getText().trim());
            checkAtivoCheckOut.setStatus('F');
            checkDAO.Update(checkAtivoCheckOut);

            JOptionPane.showMessageDialog(tela,
                    "Check-Out registrado!\nID do Check: " + checkAtivoCheckOut.getId());
            checkAtivoCheckOut = null;
            limparCheckOut();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(tela, "Erro ao gravar Check-Out:\n" + ex.getMessage());
        }
    }

    // =========================================================================
    //  LIMPAR
    // =========================================================================
    private void limparCheckIn() {
        codigoHospede = 0;
        codigoQuarto  = 0;
        tela.getjTextFieldNumeroReserva()     .setText("");
        tela.getjTextFieldDataHoraEntrada()   .setText("");
        tela.getjTextFieldDataHoraSaida()     .setText("");
        tela.getjTextFieldNumeroQuarto()      .setText("");
        tela.getjTextFieldAndarQuarto()       .setText("");
        tela.getjTextFieldCapacidadeQuarto()  .setText("");
        tela.getjTextFieldHoraInicio()        .setText("");
        tela.getjTextFieldHoraTermino()       .setText("");
        tela.getjTextFieldNome()              .setText("");
        tela.getjTextFieldCNPJ()              .setText("");
        tela.getjTextFieldCPF()               .setText("");
        tela.getjTextFieldContato()           .setText("");
        tela.getjTextFieldTelefone()          .setText("");
        tela.getjTextFieldTelefone2()         .setText("");
        tela.getjTextFieldObservacao()        .setText("");
        tela.getjTextFieldVeiculo()           .setText("");
        tela.getjTextFieldVagaEstacionamento().setText("");
        tela.getjTextFieldPlaca()             .setText("");
        tela.getjComboBoxPossuiAnimais()      .setSelectedIndex(-1);
        tela.getjComboBoxTipoHospede()        .setSelectedIndex(-1);
        tela.getjComboBoxCor()                .setSelectedIndex(-1);
    }

    private void limparCheckOut() {
        checkAtivoCheckOut = null;
        tela.getjTextFieldHospede2()         .setText("");
        tela.getjTextFieldCPF2()             .setText("");
        tela.getjTextFieldCNPJ2()            .setText("");
        tela.getjTextFieldQuarto2()          .setText("");
        tela.getjTextFieldAndar2()           .setText("");
        tela.getjTextFieldDataHoraEntrada2() .setText("");
        tela.getjTextFieldDataHoraSaida2()   .setText("");
        tela.getjTextFieldTotal()            .setText("");
        tela.getjTextFieldObservacao2()      .setText("");
    }

    // =========================================================================
    //  UTILITÁRIOS
    // =========================================================================
    private String textoOuAgora(String texto, String fallback) {
        return (texto != null && !texto.trim().isEmpty()) ? texto.trim() : fallback;
    }

    /** Retorna null se o texto for vazio — evita string vazia em colunas datetime do MySQL. */
    private String textoOuNulo(String texto) {
        return (texto != null && !texto.trim().isEmpty()) ? texto.trim() : null;
    }

    private String nvl(String valor) {
        return valor != null ? valor : "";
    }
}
