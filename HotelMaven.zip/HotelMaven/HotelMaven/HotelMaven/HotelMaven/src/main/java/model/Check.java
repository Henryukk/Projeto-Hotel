package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`check`")   // ← crases forçam o MySQL a tratar como nome de tabela, não palavra reservada
public class Check implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "data_hora_cadastro")
    private String dataHoraCadastro;
    @Column(name = "data_hora_entrada")
    private String dataHoraEntrada;
    @Column(name = "data_hora_saida")
    private String dataHoraSaida;
    @Column(name = "obs")
    private String obs;
    @Column(name = "status")
    private char status;
    @ManyToOne
    @JoinColumn(name = "check_quarto_id")
    private CheckQuarto checkQuarto;

    public Check() {
    }

    public Check(int id, String dataHoraCadastro, CheckQuarto checkQuarto,
            String dataHoraEntrada, String dataHoraSaida, String obs) {
        this.id = id;
        this.dataHoraCadastro = dataHoraCadastro;
        this.dataHoraEntrada = dataHoraEntrada;
        this.dataHoraSaida = dataHoraSaida;
        this.checkQuarto = checkQuarto;
        this.obs = obs;
    }

    public int getId()                        { return id; }
    public void setId(int id)                 { this.id = id; }

    public String getDataHoraCadastro()       { return dataHoraCadastro; }
    public void setDataHoraCadastro(String v) { this.dataHoraCadastro = v; }

    public String getDataHoraEntrada()        { return dataHoraEntrada; }
    public void setDataHoraEntrada(String v)  { this.dataHoraEntrada = v; }

    public String getDataHoraSaida()          { return dataHoraSaida; }
    public void setDataHoraSaida(String v)    { this.dataHoraSaida = v; }

    public String getObs()                    { return obs; }
    public void setObs(String obs)            { this.obs = obs; }

    public char getStatus()                   { return status; }
    public void setStatus(char status)        { this.status = status; }

    public CheckQuarto getCheckQuarto()       { return checkQuarto; }
    public void setCheckQuarto(CheckQuarto cq){ this.checkQuarto = cq; }

    public int getCheckQuartoId() {
        return this.checkQuarto != null ? this.checkQuarto.getId() : 0;
    }

    @Override
    public String toString() {
        return "id = " + id
                + "\ndataHoraCadastro = " + dataHoraCadastro
                + "\ndataHoraEntrada = "  + dataHoraEntrada
                + "\ndataHoraSaida = "    + dataHoraSaida
                + "\nobs = "              + obs;
    }
}
