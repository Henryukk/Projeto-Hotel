package model.DAO;

import java.util.List;
import model.Funcionario;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import model.DAO.JPAUtil;
import model.DAO.InterfaceDAO;


public class FuncionarioDAO implements InterfaceDAO<Funcionario> {

    private static FuncionarioDAO instance;
    protected EntityManager entityManager;

    public FuncionarioDAO() {
        entityManager = getEntityManager();
    }

    public static FuncionarioDAO getInstance() {
        if (instance == null) {
            instance = new FuncionarioDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        return JPAUtil.createEntityManager();
    }

    @Override
    public void Create(Funcionario objeto) {

        try {
            entityManager.getTransaction().begin();
            entityManager.persist(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

    public Funcionario Retrieve(int id) {
        entityManager.clear();
        java.util.List<Funcionario> lista = entityManager.createQuery(
            "SELECT e FROM Funcionario e WHERE e.id = :id", Funcionario.class)
            .setParameter("id", id)
            .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<Funcionario> Retrieve(String atributo, String valor) {
        entityManager.clear();
        List<Funcionario> listaFuncionario = new ArrayList<>();
        try {
            String sql;
            Object parametro;

            if (atributo.equalsIgnoreCase("status")) {
                // status é varchar(1) no banco — compara como String
                sql = "SELECT * FROM funcionario WHERE status = ?";
                parametro = valor.trim();
            } else if (atributo.equalsIgnoreCase("nome")) {
                sql = "SELECT * FROM funcionario WHERE nome LIKE ?";
                parametro = "%" + valor.trim() + "%";
            } else if (atributo.equalsIgnoreCase("cpf")) {
                sql = "SELECT * FROM funcionario WHERE cpf LIKE ?";
                parametro = "%" + valor.trim() + "%";
            } else if (atributo.equalsIgnoreCase("email")) {
                sql = "SELECT * FROM funcionario WHERE email LIKE ?";
                parametro = "%" + valor.trim() + "%";
            } else if (atributo.equalsIgnoreCase("usuario")) {
                sql = "SELECT * FROM funcionario WHERE usuario LIKE ?";
                parametro = "%" + valor.trim() + "%";
            } else {
                // fallback genérico para qualquer coluna extra
                sql = "SELECT * FROM funcionario WHERE " + atributo + " LIKE ?";
                parametro = "%" + valor.trim() + "%";
            }

            listaFuncionario = entityManager
                    .createNativeQuery(sql, Funcionario.class)
                    .setParameter(1, parametro)
                    .getResultList();

        } catch (Exception ex) {
            ex.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null,
                "Erro ao buscar funcionário:\n" + ex.getMessage());
        }
        return listaFuncionario;
    }
    

    @Override
    public void Update(Funcionario objeto) {

        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }

    }

    @Override
    public void Delete(Funcionario objeto) {
        
        try{
            entityManager.getTransaction().begin();
            Funcionario funcionario = new Funcionario();
            funcionario = entityManager.find(Funcionario.class, objeto.getId());
            if (funcionario != null) {
                entityManager.remove(funcionario);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}
