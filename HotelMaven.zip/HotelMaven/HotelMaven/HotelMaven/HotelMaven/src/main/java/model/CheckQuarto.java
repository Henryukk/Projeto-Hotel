/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author aluno
 */
@Entity
@Table(name = "check_quarto")
public class CheckQuarto implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "data_hora_inicio")
    private String dataHoraInicio;
    @Column(name = "data_hora_fim")
    private String dataHoraFim;
    @Column(name = "obs")
    private String obs;
    @Column(name = "status")
    private char status;
    @ManyToOne
    @JoinColumn(name="quarto_id")
    private Quarto quarto;

    public CheckQuarto() {
    }

    public CheckQuarto(int id, String dataHoraInicio, String dataHoraFim, String obs, char status, Quarto quarto) {
        this.id = id;
        this.dataHoraInicio = dataHoraInicio;
        this.dataHoraFim = dataHoraFim;
        this.obs = obs;
        this.quarto = quarto;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataHoraInicio() {
        return dataHoraInicio;
    }

    public void setDataHoraInicio(String dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }

    public String getDataHoraFim() {
        return dataHoraFim;
    }

    public void setDataHoraFim(String dataHoraFim) {
        this.dataHoraFim = dataHoraFim;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public Quarto getQuarto() {
        return quarto;
    }

    public void setQuarto(Quarto quarto) {
        this.quarto = quarto;
    }
    

    @Override
    public String toString() {
        return "id = " + id + 
                "\ndataHoraInicio = " + dataHoraInicio + 
                "\ndataHoraFim = " + dataHoraFim + 
                "\nobs = " + obs + 
                "\nstatus = " + status;
    }
    
    
}
