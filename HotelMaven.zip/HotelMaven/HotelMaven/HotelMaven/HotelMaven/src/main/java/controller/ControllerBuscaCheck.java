package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Check;
import model.CheckHospede;
import model.DAO.CheckDAO;
import view.TelaBuscaCheck;

public class ControllerBuscaCheck implements ActionListener {

    // ID do Check selecionado — lido pelo ControllerMovimentos após fechar a tela
    public static int codigo = 0;

    private final TelaBuscaCheck telaBuscaCheck;
    private final CheckDAO       checkDAO = CheckDAO.getInstance();

    public ControllerBuscaCheck(TelaBuscaCheck telaBuscaCheck) {
        this.telaBuscaCheck = telaBuscaCheck;
        this.telaBuscaCheck.getjButtonCarregar().addActionListener(this);
        this.telaBuscaCheck.getjButtonFiltrar() .addActionListener(this);
        this.telaBuscaCheck.getjButtonSair()    .addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {

        // ── CARREGAR ─────────────────────────────────────────────────────────
        if (evento.getSource() == telaBuscaCheck.getjButtonCarregar()) {

            if (telaBuscaCheck.getjTableColunas().getRowCount() == 0
                    || telaBuscaCheck.getjTableColunas().getSelectedRow() == -1) {
                JOptionPane.showMessageDialog(null,
                        "Nenhum registro selecionado.\nClique em uma linha antes de Carregar.");
                return;
            }

            codigo = (int) telaBuscaCheck.getjTableColunas()
                    .getValueAt(telaBuscaCheck.getjTableColunas().getSelectedRow(), 0);

            telaBuscaCheck.dispose();

        // ── FILTRAR ──────────────────────────────────────────────────────────
        } else if (evento.getSource() == telaBuscaCheck.getjButtonFiltrar()) {

            String valor = telaBuscaCheck.getjTextFieldValor().getText().trim();
            if (valor.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Digite um valor para filtrar.");
                return;
            }

            int filtroIndex = telaBuscaCheck.getjComboBoxFiltrarPor().getSelectedIndex();
            if (filtroIndex == -1) {
                JOptionPane.showMessageDialog(null, "Selecione um campo para filtrar.");
                return;
            }

            DefaultTableModel tabela = (DefaultTableModel) telaBuscaCheck.getjTableColunas().getModel();
            tabela.setRowCount(0);

            try {
                switch (filtroIndex) {

                    case 0: // ── ID ───────────────────────────────────────────
                        Check check = checkDAO.Retrieve(Integer.parseInt(valor));
                        if (check != null) {
                            tabela.addRow(montarLinha(check));
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "Nenhum Check encontrado com ID " + valor + ".");
                        }
                        break;

                    case 1: // ── Hóspede (Nome) ───────────────────────────────
                        List<Check> todosHospede = new ArrayList<>();
                        todosHospede.addAll(checkDAO.Retrieve("status", "A"));
                        todosHospede.addAll(checkDAO.Retrieve("status", "F"));

                        for (Check c : todosHospede) {
                            CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
                            if (ch != null && ch.getHospede() != null
                                    && ch.getHospede().getNome() != null
                                    && ch.getHospede().getNome().toLowerCase()
                                            .contains(valor.toLowerCase())) {
                                tabela.addRow(montarLinha(c));
                            }
                        }
                        if (tabela.getRowCount() == 0)
                            JOptionPane.showMessageDialog(null,
                                    "Nenhum Check encontrado para hóspede \"" + valor + "\".");
                        break;

                    case 2: // ── Quarto ────────────────────────────────────────
                        List<Check> todosQuarto = new ArrayList<>();
                        todosQuarto.addAll(checkDAO.Retrieve("status", "A"));
                        todosQuarto.addAll(checkDAO.Retrieve("status", "F"));

                        for (Check c : todosQuarto) {
                            if (c.getCheckQuarto() != null
                                    && c.getCheckQuarto().getQuarto() != null
                                    && c.getCheckQuarto().getQuarto().getIdentificacao() != null
                                    && c.getCheckQuarto().getQuarto().getIdentificacao()
                                            .toLowerCase().contains(valor.toLowerCase())) {
                                tabela.addRow(montarLinha(c));
                            }
                        }
                        if (tabela.getRowCount() == 0)
                            JOptionPane.showMessageDialog(null,
                                    "Nenhum Check encontrado para quarto \"" + valor + "\".");
                        break;

                    case 3: // ── Status (A ou F) ───────────────────────────────
                        List<Check> porStatus = checkDAO.Retrieve("status", valor);
                        for (Check c : porStatus)
                            tabela.addRow(montarLinha(c));

                        if (tabela.getRowCount() == 0)
                            JOptionPane.showMessageDialog(null,
                                    "Nenhum Check encontrado com status \"" + valor + "\".\n"
                                    + "Use A para Aberto ou F para Fechado.");
                        break;
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null,
                        "Para filtrar por ID, digite apenas números.");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao buscar: " + ex.getMessage());
            }

        // ── SAIR ─────────────────────────────────────────────────────────────
        } else if (evento.getSource() == telaBuscaCheck.getjButtonSair()) {
            telaBuscaCheck.dispose();
        }
    }

    /**
     * Monta uma linha da tabela.
     * Colunas: ID | Hóspede | Quarto | Data/Hora Entrada | Status
     */
    private Object[] montarLinha(Check c) {
        String nomeHospede = "-";
        CheckHospede ch = checkDAO.buscarHospedeDoCheck(c.getId());
        if (ch != null && ch.getHospede() != null && ch.getHospede().getNome() != null)
            nomeHospede = ch.getHospede().getNome();

        String quarto = "-";
        if (c.getCheckQuarto() != null && c.getCheckQuarto().getQuarto() != null
                && c.getCheckQuarto().getQuarto().getIdentificacao() != null)
            quarto = c.getCheckQuarto().getQuarto().getIdentificacao();

        return new Object[]{
            c.getId(),
            nomeHospede,
            quarto,
            c.getDataHoraEntrada() != null ? c.getDataHoraEntrada() : "-",
            c.getStatus() == 'A' ? "Aberto" : "Fechado"
        };
    }
}
