package model.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Fábrica singleton de EntityManager.
 * Todos os DAOs devem usar esta classe para obter o mesmo contexto JPA,
 * evitando problemas de "detached entity" entre DAOs diferentes.
 */
public class JPAUtil {

    private static EntityManagerFactory factory;

    static {
        factory = Persistence.createEntityManagerFactory("PU");
    }

    public static EntityManagerFactory getFactory() {
        if (factory == null || !factory.isOpen()) {
            factory = Persistence.createEntityManagerFactory("PU");
        }
        return factory;
    }

    public static EntityManager createEntityManager() {
        return getFactory().createEntityManager();
    }
}
