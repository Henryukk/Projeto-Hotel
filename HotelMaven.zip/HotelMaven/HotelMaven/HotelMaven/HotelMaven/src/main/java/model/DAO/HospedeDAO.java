
package model.DAO;

import java.util.List;
import model.Hospede;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import model.DAO.JPAUtil;


public class HospedeDAO implements InterfaceDAO<Hospede> {

    private static HospedeDAO instance;
    protected EntityManager entityManager;

    public HospedeDAO() {
        entityManager = getEntityManager();
    }

    public static HospedeDAO getInstance() {
        if (instance == null) {
            instance = new HospedeDAO();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        return JPAUtil.createEntityManager();
    }

    @Override
    public void Create(Hospede objeto) {
        try {
                entityManager.clear();
                entityManager.getTransaction().begin();
                entityManager.persist(objeto);
                entityManager.getTransaction().commit();
        } catch (Exception ex) {
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    
}


    public Hospede Retrieve(int id) {
        entityManager.clear();
        java.util.List<Hospede> lista = entityManager.createQuery(
            "SELECT e FROM Hospede e WHERE e.id = :id", Hospede.class)
            .setParameter("id", id)
            .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }
    

    @Override
    public List<Hospede> Retrieve(String atributo, String valor) {

        entityManager.clear();
        List<Hospede> ListaHospede = new ArrayList<>();
        ListaHospede = entityManager.createQuery(
                    "SELECT hosp FROM Hospede hosp WHERE " +
                    (atributo.equalsIgnoreCase("status") ? "hosp.status = :valor" : "hosp." + atributo + " LIKE :valor"),
                    Hospede.class)
                .setParameter("valor", atributo.equalsIgnoreCase("status") ? valor.trim().charAt(0) : "%" + valor.trim() + "%")
                .getResultList();
                
        return ListaHospede;
        
        }
    
                
      

    @Override
    public void Update(Hospede objeto) {
        
        try {
            entityManager.clear();
            entityManager.getTransaction().begin();
            entityManager.merge(objeto);
            entityManager.getTransaction().commit();
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }

    }

    @Override
    public void Delete(Hospede objeto) {
        
        try{
            entityManager.getTransaction().begin();
            Hospede hospede = new Hospede();
            hospede = entityManager.find(Hospede.class, objeto.getId());
            if (hospede != null) {
                entityManager.remove(hospede);
            }
            
        } catch (Exception ex){
            ex.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}
