-- Execute este script no MySQL antes de rodar o sistema.
-- Permite NULL nas colunas de data/hora que só são preenchidas ao final do check.

ALTER TABLE `check_quarto`
    MODIFY COLUMN `data_hora_fim`    datetime NULL,
    MODIFY COLUMN `obs`              varchar(45) NULL;

ALTER TABLE `check`
    MODIFY COLUMN `data_hora_saida`  datetime NULL,
    MODIFY COLUMN `obs`              varchar(100) NULL;

ALTER TABLE `check_hospede`
    MODIFY COLUMN `obs`              varchar(100) NULL;
