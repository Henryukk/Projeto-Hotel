/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Utilities {

    public static void ativaDesativa(JPanel painel, boolean ativa) {

        Component[] vetComponentes = painel.getComponents();
        for (Component componenteAtual : vetComponentes) {

            if (componenteAtual instanceof JButton) {
                if (((JButton) componenteAtual).getActionCommand() == "0") {
                    componenteAtual.setEnabled(ativa);
                } else {
                    componenteAtual.setEnabled(!ativa);
                }

            }
        }
    }
    public static void limpaComponentes(JPanel painel, boolean ativa){
        Component [] vetComponents = painel.getComponents();
        for (Component componenteAtual : vetComponents) {
            if (componenteAtual instanceof JTextField) {
                ((JTextField) componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JFormattedTextField){
                ((JTextField)componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JComboBox){
                ((JComboBox) componenteAtual).setSelectedIndex(-1);
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JCheckBox){
                ((JCheckBox) componenteAtual).setSelected(false);
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JPasswordField){
                ((JPasswordField)componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }else if (componenteAtual instanceof JTextArea){
                ((JTextArea)componenteAtual).setText("");
                componenteAtual.setEnabled(ativa);
            }
        }
    }
}

