/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasHospede;
import view.TelaCadastroHospede;

public class ControllerCadHospede implements ActionListener {

    TelaCadastroHospede telaCadastroHospede;

    public ControllerCadHospede(TelaCadastroHospede telaCadastroHospede) {
        this.telaCadastroHospede = telaCadastroHospede;
        this.telaCadastroHospede.getjButtonNovo().addActionListener(this);
        this.telaCadastroHospede.getjButtonSair().addActionListener(this);
        this.telaCadastroHospede.getjButtonGravar().addActionListener(this);
        this.telaCadastroHospede.getjButtonCancelar().addActionListener(this);
        this.telaCadastroHospede.getjButtonBuscar().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), true);
        utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), false);

    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaCadastroHospede.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), false);
            utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), true);
        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), true);
            utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), true);
            utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonBuscar()) {

            TelaBuscasHospede telaBuscasHospede = new TelaBuscasHospede(null, true);
            ControllerBuscaHospede controllerBuscaHospede = new ControllerBuscaHospede(telaBuscasHospede);
            telaBuscasHospede.setVisible(true);
            
        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonSair()) {
            this.telaCadastroHospede.dispose();

        }
    }
}
