/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Hospede;
import view.TelaBuscasHospede;
import view.TelaCadastroHospede;

public class ControllerCadHospede implements ActionListener {

    TelaCadastroHospede telaCadastroHospede;
    public static int codigo;

    public ControllerCadHospede(TelaCadastroHospede telaCadastroHospede) {
        this.telaCadastroHospede = telaCadastroHospede;
        this.telaCadastroHospede.getjButtonNovo().addActionListener(this);
        this.telaCadastroHospede.getjButtonSair().addActionListener(this);
        this.telaCadastroHospede.getjButtonGravar().addActionListener(this);
        this.telaCadastroHospede.getjButtonCancelar().addActionListener(this);
        this.telaCadastroHospede.getjButtonBuscar().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), true);
        utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), false);

    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaCadastroHospede.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), false);
            utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), true);
        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonGravar()) {

            if (this.telaCadastroHospede.getjFormattedTextFieldNome().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "O atributo Nome é obrigatório...");
                this.telaCadastroHospede.getjFormattedTextFieldNome().requestFocus();
            } else {
                Hospede hospede = new Hospede();
                //COLOCAR TODOS OS ATRIBUTOS DA CLASSE CADASTRO HOSPEDE
                hospede.setId(Integer.parseInt(this.telaCadastroHospede.getjTextFieldID().getText()));
                hospede.setNome(this.telaCadastroHospede.getjFormattedTextFieldNome().getText());
                hospede.setRazaoSocial(this.telaCadastroHospede.getjTextFieldRazaoSocial().getText());

                if (this.telaCadastroHospede.getjTextFieldID().getText().trim().equalsIgnoreCase("")) {
                    //se for igual a nada incluir
                    service.HospedeService.Criar(hospede);

                } else {
                    //atualiza
                    hospede.setId(Integer.parseInt(this.telaCadastroHospede.getjTextFieldID().getText()));
                    service.HospedeService.Atualizar(hospede);
                }

                utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), true);
                utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), false);

            }

        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), true);
            utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonBuscar()) {

            codigo = 0;

            TelaBuscasHospede telaBuscasHospede = new TelaBuscasHospede(null, true);
            ControllerBuscaHospede controllerBuscaHospede = new ControllerBuscaHospede(telaBuscasHospede);
            telaBuscasHospede.setVisible(true);

            if (codigo != 0) {
                utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel1(), false);
                utilities.Utilities.limpaComponentes(this.telaCadastroHospede.getjPanel1(), true);

                this.telaCadastroHospede.getjTextFieldID().setText(codigo + "");
                this.telaCadastroHospede.getjTextFieldID().setEnabled(false);

                Hospede hospede = new Hospede();
                hospede = service.HospedeService.Carregar(codigo);
                //COLOCAR TODOS OS ATRIBUTOS DA CLASSE CADASTRO HOSPEDE
                this.telaCadastroHospede.getjFormattedTextFieldCEP().setText(hospede.getCep());
                this.telaCadastroHospede.getjFormattedTextFieldNome().setText(hospede.getNome());
                this.telaCadastroHospede.getjTextFieldRazaoSocial().setText(hospede.getRazaoSocial());
                this.telaCadastroHospede.getjFormattedTextFieldCPF().setText(hospede.getCpf());

                this.telaCadastroHospede.getjFormattedTextFieldNome().requestFocus();
            }

        } else if (evento.getSource() == this.telaCadastroHospede.getjButtonSair()) {
            this.telaCadastroHospede.dispose();

        }
    }
}
