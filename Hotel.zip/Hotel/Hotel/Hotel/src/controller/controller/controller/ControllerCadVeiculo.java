package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasVeiculo;
import view.TelaCadastroVeiculo;

public class ControllerCadVeiculo implements ActionListener {

    private TelaCadastroVeiculo telaCadastroVeiculo;

    public ControllerCadVeiculo(TelaCadastroVeiculo telaCadastroVeiculo) {
        this.telaCadastroVeiculo = telaCadastroVeiculo;
        this.telaCadastroVeiculo.getjButtonNovo().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonCancelar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonGravar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonBuscar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
        this.telaCadastroVeiculo.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroVeiculo.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroVeiculo.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroVeiculo.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroVeiculo.getjButtonBuscar()) {
            TelaBuscasVeiculo telaBuscasVeiculo = new TelaBuscasVeiculo(null, true);
            ControllerBuscasVeiculo controllerBuscasVeiculo = new ControllerBuscasVeiculo(telaBuscasVeiculo);
            telaBuscasVeiculo.setVisible(true);
        } else if (e.getSource() == this.telaCadastroVeiculo.getjButtonSair()) {
            this.telaCadastroVeiculo.dispose();
        }
    }
}