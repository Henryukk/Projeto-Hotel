package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasQuarto;
import view.TelaCadastroQuarto;

public class ControllerCadQuarto implements ActionListener {

    private TelaCadastroQuarto telaCadastroQuarto;

    public ControllerCadQuarto(TelaCadastroQuarto telaCadastroQuarto) {
        this.telaCadastroQuarto = telaCadastroQuarto;
        this.telaCadastroQuarto.getjButtonNovo().addActionListener(this);
        this.telaCadastroQuarto.getjButtonCancelar().addActionListener(this);
        this.telaCadastroQuarto.getjButtonGravar().addActionListener(this);
        this.telaCadastroQuarto.getjButtonBuscar().addActionListener(this);
        this.telaCadastroQuarto.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), false);
        this.telaCadastroQuarto.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroQuarto.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroQuarto.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroQuarto.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroQuarto.getjButtonBuscar()) {
            TelaBuscasQuarto telaBuscasQuarto = new TelaBuscasQuarto(null, true);
            ControllerBuscasQuarto controllerBuscasQuarto = new ControllerBuscasQuarto(telaBuscasQuarto);
            telaBuscasQuarto.setVisible(true);
        } else if (e.getSource() == this.telaCadastroQuarto.getjButtonSair()) {
            this.telaCadastroQuarto.dispose();
        }
    }
}
