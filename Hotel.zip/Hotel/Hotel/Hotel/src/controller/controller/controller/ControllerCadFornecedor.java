package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasFornecedor;
import view.TelaCadastroFornecedor;

public class ControllerCadFornecedor implements ActionListener {

    private TelaCadastroFornecedor telaCadastroFornecedor;

    public ControllerCadFornecedor(TelaCadastroFornecedor telaCadastroFornecedor) {
        this.telaCadastroFornecedor = telaCadastroFornecedor;
        this.telaCadastroFornecedor.getjButtonNovo().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonCancelar().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonGravar().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonBuscar().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), false);
        this.telaCadastroFornecedor.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroFornecedor.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroFornecedor.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroFornecedor.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroFornecedor.getjButtonBuscar()) {
            TelaBuscasFornecedor telaBuscasFornecedor = new TelaBuscasFornecedor(null, true);
            ControllerBuscasFornecedor controllerBuscasFornecedor = new ControllerBuscasFornecedor(telaBuscasFornecedor);
            telaBuscasFornecedor.setVisible(true);
        } else if (e.getSource() == this.telaCadastroFornecedor.getjButtonSair()) {
            this.telaCadastroFornecedor.dispose();
        }
    }
}