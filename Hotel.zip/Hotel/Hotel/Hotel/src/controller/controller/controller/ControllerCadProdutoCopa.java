package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasProdutoCopa;
import view.TelaCadastroProdutoCopa;

public class ControllerCadProdutoCopa implements ActionListener {

    private TelaCadastroProdutoCopa telaCadastroProdutoCopa;

    public ControllerCadProdutoCopa(TelaCadastroProdutoCopa telaCadastroProdutoCopa) {
        this.telaCadastroProdutoCopa = telaCadastroProdutoCopa;
        this.telaCadastroProdutoCopa.getjButtonNovo().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonCancelar().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonGravar().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonBuscar().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), false);
        this.telaCadastroProdutoCopa.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroProdutoCopa.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroProdutoCopa.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroProdutoCopa.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroProdutoCopa.getjButtonBuscar()) {
            TelaBuscasProdutoCopa telaBuscasProdutoCopa = new TelaBuscasProdutoCopa(null, true);
            ControllerBuscasProdutoCopa controllerBuscasProdutoCopa = new ControllerBuscasProdutoCopa(telaBuscasProdutoCopa);
            telaBuscasProdutoCopa.setVisible(true);
        } else if (e.getSource() == this.telaCadastroProdutoCopa.getjButtonSair()) {
            this.telaCadastroProdutoCopa.dispose();
        }
    }
}