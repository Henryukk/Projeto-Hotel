package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasMarca;
import view.TelaCadastroMarca;

public class ControllerCadMarca implements ActionListener {

    private TelaCadastroMarca telaCadastroMarca;

    public ControllerCadMarca(TelaCadastroMarca telaCadastroMarca) {
        this.telaCadastroMarca = telaCadastroMarca;
        this.telaCadastroMarca.getjButtonNovo().addActionListener(this);
        this.telaCadastroMarca.getjButtonCancelar().addActionListener(this);
        this.telaCadastroMarca.getjButtonGravar().addActionListener(this);
        this.telaCadastroMarca.getjButtonBuscar().addActionListener(this);
        this.telaCadastroMarca.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), false);
        this.telaCadastroMarca.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroMarca.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroMarca.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroMarca.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroMarca.getjButtonBuscar()) {
            TelaBuscasMarca telaBuscasMarca = new TelaBuscasMarca(null, true);
            ControllerBuscasMarca controllerBuscasMarca = new ControllerBuscasMarca(telaBuscasMarca);
            telaBuscasMarca.setVisible(true);
        } else if (e.getSource() == this.telaCadastroMarca.getjButtonSair()) {
            this.telaCadastroMarca.dispose();
        }
    }
}