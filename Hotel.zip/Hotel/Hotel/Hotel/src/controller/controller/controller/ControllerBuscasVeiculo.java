package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Veiculo;
import view.TelaBuscasVeiculo;

public class ControllerBuscasVeiculo implements ActionListener {

    TelaBuscasVeiculo telaBuscasVeiculo;
    
    public ControllerBuscasVeiculo(TelaBuscasVeiculo telaBuscasVeiculo) {
        this.telaBuscasVeiculo = telaBuscasVeiculo;
        
        this.telaBuscasVeiculo.getjButtonCarregar().addActionListener(this);
        this.telaBuscasVeiculo.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasVeiculo.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasVeiculo.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasVeiculo.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem dados selecionados!");
            } else {
                JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
            }
        } else if (evento.getSource() == this.telaBuscasVeiculo.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasVeiculo.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Seleção");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando informações...");
                if (this.telaBuscasVeiculo.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID");
                    Veiculo veiculo = new Veiculo();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    veiculo = service.VeiculoService.Carregar(Integer.parseInt(this.telaBuscasVeiculo.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasVeiculo.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{veiculo.getId(), veiculo.getPlaca(), veiculo.getStatus()});
                    
                } else if (this.telaBuscasVeiculo.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por Placa");
                    List<Veiculo> listaVeiculos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaVeiculos = service.VeiculoService.Carregar("placa", this.telaBuscasVeiculo.getjTextFieldValor().getText());
                    
                    Veiculo veiculo = new Veiculo();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasVeiculo.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Veiculo veiculoAtualDaLista : listaVeiculos) {
                        tabela.addRow(new Object[]{veiculoAtualDaLista.getId(), 
                        veiculoAtualDaLista.getPlaca(),
                        veiculoAtualDaLista.getStatus()});
                    }
                    
                } 
            }
        } else if (evento.getSource() == this.telaBuscasVeiculo.getjButtonSair()) {
            this.telaBuscasVeiculo.dispose();
        }
    }
}