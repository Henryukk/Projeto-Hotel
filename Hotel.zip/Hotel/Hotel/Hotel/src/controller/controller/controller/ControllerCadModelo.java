package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasModelo;
import view.TelaCadastroModelo;

public class ControllerCadModelo implements ActionListener {

    private TelaCadastroModelo telaCadastroModelo;

    public ControllerCadModelo(TelaCadastroModelo telaCadastroModelo) {
        this.telaCadastroModelo = telaCadastroModelo;
        this.telaCadastroModelo.getjButtonNovo().addActionListener(this);
        this.telaCadastroModelo.getjButtonCancelar().addActionListener(this);
        this.telaCadastroModelo.getjButtonGravar().addActionListener(this);
        this.telaCadastroModelo.getjButtonBuscar().addActionListener(this);
        this.telaCadastroModelo.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), false);
        this.telaCadastroModelo.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroModelo.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroModelo.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroModelo.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroModelo.getjButtonBuscar()) {
            TelaBuscasModelo telaBuscasModelo = new TelaBuscasModelo(null, true);
            ControllerBuscasModelo controllerBuscasModelo = new ControllerBuscasModelo(telaBuscasModelo);
            telaBuscasModelo.setVisible(true);
        } else if (e.getSource() == this.telaCadastroModelo.getjButtonSair()) {
            this.telaCadastroModelo.dispose();
        }
    }
}