package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Servico;
import view.TelaBuscasServico;

public class ControllerBuscasServico implements ActionListener {

    private TelaBuscasServico telaBuscasServico;
    
    public ControllerBuscasServico(TelaBuscasServico telaBuscasServico) {
        this.telaBuscasServico = telaBuscasServico;
        
        this.telaBuscasServico.getjButtonCarregar().addActionListener(this);
        this.telaBuscasServico.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasServico.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasServico.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasServico.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem serviços selecionados!");
            } else {
                JOptionPane.showMessageDialog(null, "Carregando dados do serviço para edição...");
            }
        } else if (evento.getSource() == this.telaBuscasServico.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasServico.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Selecao");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando serviços...");
                if (this.telaBuscasServico.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID do serviço");
                    Servico servico = new Servico();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    servico = service.ServicoService.Carregar(Integer.parseInt(this.telaBuscasServico.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasServico.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{servico.getId(), servico.getDescricao(), servico.getStatus()});
                } else if (this.telaBuscasServico.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por descriçao do serviço");
                    List<Servico> listaServicos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaServicos = service.ServicoService.Carregar("descricao", this.telaBuscasServico.getjTextFieldValor().getText());
                    
                    Servico servico = new Servico();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasServico.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Servico servicoAtualDaLista : listaServicos) {
                        tabela.addRow(new Object[]{servicoAtualDaLista.getId(), 
                        servicoAtualDaLista.getDescricao(),
                        servicoAtualDaLista.getStatus()});
                    }
                    
                }  
            }
        } else if (evento.getSource() == this.telaBuscasServico.getjButtonSair()) {
            this.telaBuscasServico.dispose();
        }
    }
}