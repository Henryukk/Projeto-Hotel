package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Quarto;
import view.TelaBuscasQuarto;

public class ControllerBuscasQuarto implements ActionListener {

    private TelaBuscasQuarto telaBuscasQuarto;
    
    public ControllerBuscasQuarto(TelaBuscasQuarto telaBuscasQuarto) {
        this.telaBuscasQuarto = telaBuscasQuarto;
        
        this.telaBuscasQuarto.getjButtonCarregar().addActionListener(this);
        this.telaBuscasQuarto.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasQuarto.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasQuarto.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasQuarto.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem quartos selecionados!");
            } else {
                JOptionPane.showMessageDialog(null, "Carregando dados do quarto para edição...");
            }
        } else if (evento.getSource() == this.telaBuscasQuarto.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasQuarto.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Selecao");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando quartos...");
                if (this.telaBuscasQuarto.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID do quarto");
                    Quarto quarto = new Quarto();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    quarto = service.QuartoService.Carregar(Integer.parseInt(this.telaBuscasQuarto.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasQuarto.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{quarto.getId(), quarto.getAndar(), quarto.getMetragem(), quarto.getIdentificacao(), quarto.getStatus()});
                    
                } else if (this.telaBuscasQuarto.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por andar do quarto");
                    List<Quarto> listaQuartos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaQuartos = service.QuartoService.Carregar("andar", this.telaBuscasQuarto.getjTextFieldValor().getText());
                    
                    Quarto quarto = new Quarto();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasQuarto.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Quarto quartoAtualDaLista : listaQuartos) {
                        tabela.addRow(new Object[]{quartoAtualDaLista.getId(), 
                        quartoAtualDaLista.getAndar(),
                        quartoAtualDaLista.getMetragem(),
                        quartoAtualDaLista.getIdentificacao(),
                        quartoAtualDaLista.getStatus()});
                    }
                    
                } else if (this.telaBuscasQuarto.getjComboBoxFiltrar().getSelectedIndex() == 2) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por metragem do quarto");
                    List<Quarto> listaQuartos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaQuartos = service.QuartoService.Carregar("metragem", this.telaBuscasQuarto.getjTextFieldValor().getText());
                    
                    Quarto quarto = new Quarto();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasQuarto.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Quarto quartoAtualDaLista : listaQuartos) {
                        tabela.addRow(new Object[]{quartoAtualDaLista.getId(), 
                        quartoAtualDaLista.getAndar(),
                        quartoAtualDaLista.getMetragem(),
                        quartoAtualDaLista.getIdentificacao(),
                        quartoAtualDaLista.getStatus()});
                    }
                    
                } else if (this.telaBuscasQuarto.getjComboBoxFiltrar().getSelectedIndex() == 3) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por identificaçao do quarto");
                    List<Quarto> listaQuartos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaQuartos = service.QuartoService.Carregar("identificacao", this.telaBuscasQuarto.getjTextFieldValor().getText());
                    
                    Quarto quarto = new Quarto();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasQuarto.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Quarto quartoAtualDaLista : listaQuartos) {
                        tabela.addRow(new Object[]{quartoAtualDaLista.getId(), 
                        quartoAtualDaLista.getAndar(),
                        quartoAtualDaLista.getMetragem(),
                        quartoAtualDaLista.getIdentificacao(),
                        quartoAtualDaLista.getStatus()});
                    }
                }
            }
        } else if (evento.getSource() == this.telaBuscasQuarto.getjButtonSair()) {
            this.telaBuscasQuarto.dispose();
        }
    }
}