package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import view.TelaBuscasModelo;

public class ControllerBuscasModelo implements ActionListener {

    private TelaBuscasModelo telaBuscasModelo;
    
    public ControllerBuscasModelo(TelaBuscasModelo telaBuscasModelo) {
        this.telaBuscasModelo = telaBuscasModelo;
        
        this.telaBuscasModelo.getjButtonCarregar().addActionListener(this);
        this.telaBuscasModelo.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasModelo.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasModelo.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasModelo.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem modelos selecionados!");
            } else {
                JOptionPane.showMessageDialog(null, "Carregando dados do modelo para edição...");
            }
        } else if (evento.getSource() == this.telaBuscasModelo.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasModelo.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Selecao");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando modelos...");
                if (this.telaBuscasModelo.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID");
                    Modelo modelo = new Modelo();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    modelo = service.ModeloService.Carregar(Integer.parseInt(this.telaBuscasModelo.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasModelo.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{modelo.getId(), modelo.getDescricao(), modelo.getStatus()});
                    
                } else if (this.telaBuscasModelo.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por descriçao");
                    List<Modelo> listaModelos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaModelos = service.ModeloService.Carregar("descricao", this.telaBuscasModelo.getjTextFieldValor().getText());
                    
                    Modelo modelo = new Modelo();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasModelo.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Modelo modeloAtualDaLista : listaModelos) {
                        tabela.addRow(new Object[]{modeloAtualDaLista.getId(), 
                        modeloAtualDaLista.getDescricao(),
                        modeloAtualDaLista.getStatus()});
                    }
                } 
            }
        } else if (evento.getSource() == this.telaBuscasModelo.getjButtonSair()) {
            this.telaBuscasModelo.dispose();
        }
    }
}