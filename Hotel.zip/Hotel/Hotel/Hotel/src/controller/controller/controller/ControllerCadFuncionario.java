package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasFuncionario;
import view.TelaCadastroFuncionario;

public class ControllerCadFuncionario implements ActionListener{
    
    TelaCadastroFuncionario telaCadastroFuncionario;

    public ControllerCadFuncionario(TelaCadastroFuncionario telaCadastroFuncionario) {
        this.telaCadastroFuncionario = telaCadastroFuncionario;
        this.telaCadastroFuncionario.getjButtonNovo().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonCancelar().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonGravar().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonBuscar().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), false);
    
        this.telaCadastroFuncionario.getjButtonNovo().setEnabled(true);
        }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaCadastroFuncionario.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), true);
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), false);
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), false);
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonBuscar()) {
            TelaBuscasFuncionario telaBuscasFuncionario = new TelaBuscasFuncionario(null, true);
        ControllerBuscasFuncionario controllerBuscasFuncionario = new ControllerBuscasFuncionario(telaBuscasFuncionario);
        telaBuscasFuncionario.setVisible(true);
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonSair()) {
            this.telaCadastroFuncionario.dispose();
        }
    }
    
}
