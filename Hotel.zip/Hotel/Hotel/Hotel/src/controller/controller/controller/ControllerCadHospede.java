package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasHospede;
import view.TelaCadastroHospede;

public class ControllerCadHospede implements ActionListener{


    TelaCadastroHospede telaCadastroHospede;

    public ControllerCadHospede(TelaCadastroHospede telaCadastroHospede) {
        this.telaCadastroHospede = telaCadastroHospede;
        this.telaCadastroHospede.getjButtonNovo().addActionListener(this);
        this.telaCadastroHospede.getjButtonCancelar().addActionListener(this);
        this.telaCadastroHospede.getjButtonGravar().addActionListener(this);
        this.telaCadastroHospede.getjButtonBuscar().addActionListener(this);
        this.telaCadastroHospede.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroHospede.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroHospede.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), true);
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonBuscar()) {
            TelaBuscasHospede telaBuscasHospede = new TelaBuscasHospede(null, true);
        ControllerBuscasHospede controllerBuscasHospede = new ControllerBuscasHospede(telaBuscasHospede);
        telaBuscasHospede.setVisible(true);
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonSair()) {
            this.telaCadastroHospede.dispose();
        }
    }
    
    
    
}
