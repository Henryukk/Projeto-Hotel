package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Fornecedor;
import view.TelaBuscasFornecedor; // (Trocar para a tela correspondente)

public class ControllerBuscasFornecedor implements ActionListener {

    TelaBuscasFornecedor telaBuscasFornecedor; // (Trocar para a tela correspondente)
    
    public ControllerBuscasFornecedor(TelaBuscasFornecedor telaBuscasFornecedor) {
        this.telaBuscasFornecedor = telaBuscasFornecedor;
        
        this.telaBuscasFornecedor.getjButtonCarregar().addActionListener(this);
        this.telaBuscasFornecedor.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasFornecedor.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasFornecedor.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasFornecedor.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem dados selecionados!");
            } else {
                JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
            }
        } else if (evento.getSource() == this.telaBuscasFornecedor.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasFornecedor.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Seleção");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando informações...");
                if (this.telaBuscasFornecedor.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID");
                    Fornecedor fornecedor = new Fornecedor();
                    
                    fornecedor = service.FornecedorService.Carregar(Integer.parseInt(this.telaBuscasFornecedor.getjTextFieldValor().getText()));
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasFornecedor.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{fornecedor.getId(), fornecedor.getNome(), fornecedor.getCpf(), fornecedor.getStatus()});
                    
                } else if (this.telaBuscasFornecedor.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por nome");
                    List<Fornecedor> listaFornecedores = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaFornecedores = service.FornecedorService.Carregar("nome", this.telaBuscasFornecedor.getjTextFieldValor().getText());
                    
                    Fornecedor fornecedor = new Fornecedor();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasFornecedor.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Fornecedor fornecedorAtualDaLista : listaFornecedores) {
                        tabela.addRow(new Object[]{fornecedorAtualDaLista.getId(), 
                        fornecedorAtualDaLista.getNome(),
                        fornecedorAtualDaLista.getInscricaoEstadual(),
                        fornecedorAtualDaLista.getStatus()});
                    }
                } else if (this.telaBuscasFornecedor.getjComboBoxFiltrar().getSelectedIndex() == 2) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por inscriçao estadual"); // (Ajustar conforme a entidade)
                    List<Fornecedor> listaFornecedores = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaFornecedores = service.FornecedorService.Carregar("inscricao estadual", this.telaBuscasFornecedor.getjTextFieldValor().getText());
                    
                    Fornecedor fornecedor = new Fornecedor();                  
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasFornecedor.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Fornecedor fornecedorAtualDaLista : listaFornecedores) {
                        tabela.addRow(new Object[]{fornecedorAtualDaLista.getId(), 
                        fornecedorAtualDaLista.getNome(),
                        fornecedorAtualDaLista.getInscricaoEstadual(),
                        fornecedorAtualDaLista.getStatus()});
                    }
                }
            }
        } else if (evento.getSource() == this.telaBuscasFornecedor.getjButtonSair()) {
            this.telaBuscasFornecedor.dispose();
        }
    }
}