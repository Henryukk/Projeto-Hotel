package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import view.TelaBuscasMarca;

public class ControllerBuscasMarca implements ActionListener {

    private TelaBuscasMarca telaBuscasMarca;
    
    public ControllerBuscasMarca(TelaBuscasMarca telaBuscasMarca) {
        this.telaBuscasMarca = telaBuscasMarca;
        
        this.telaBuscasMarca.getjButtonCarregar().addActionListener(this);
        this.telaBuscasMarca.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasMarca.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasMarca.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasMarca.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem marcas selecionadas!");
            } else {
                JOptionPane.showMessageDialog(null, "Carregando dados da marca para edição...");
            }
        } else if (evento.getSource() == this.telaBuscasMarca.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasMarca.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para Selecao");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando marcas...");
                if (this.telaBuscasMarca.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID da marca");
                    Marca marca = new Marca();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    marca = service.MarcaService.Carregar(Integer.parseInt(this.telaBuscasMarca.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasMarca.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{marca.getId(), marca.getDescricao(), marca.getStatus()});
                    
                } else if (this.telaBuscasMarca.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por descriçao da marca");
                    List<Marca> listaMarcas = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaMarcas = service.MarcaService.Carregar("descricao", this.telaBuscasMarca.getjTextFieldValor().getText());
                    
                    Marca marca = new Marca();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasMarca.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Marca marcaAtualDaLista : listaMarcas) {
                        tabela.addRow(new Object[]{marcaAtualDaLista.getId(), 
                        marcaAtualDaLista.getDescricao(),
                        marcaAtualDaLista.getStatus()});
                    }
                }
            }
        } else if (evento.getSource() == this.telaBuscasMarca.getjButtonSair()) {
            this.telaBuscasMarca.dispose();
        }
    }
}