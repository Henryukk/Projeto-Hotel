package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasVagaEstacionamento;
import view.TelaCadastroVagaEstacionamento;

public class ControllerCadVagaEstacionamento implements ActionListener {

    private TelaCadastroVagaEstacionamento telaCadastroVagaEstacionamento;

    public ControllerCadVagaEstacionamento(TelaCadastroVagaEstacionamento telaCadastroVagaEstacionamento) {
        this.telaCadastroVagaEstacionamento = telaCadastroVagaEstacionamento;
        this.telaCadastroVagaEstacionamento.getjButtonNovo().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonCancelar().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonGravar().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonBuscar().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), false);
        this.telaCadastroVagaEstacionamento.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaCadastroVagaEstacionamento.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), true);
        } else if (e.getSource() == this.telaCadastroVagaEstacionamento.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroVagaEstacionamento.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), false);
        } else if (e.getSource() == this.telaCadastroVagaEstacionamento.getjButtonBuscar()) {
            TelaBuscasVagaEstacionamento telaBuscasVagaEstacionamento = new TelaBuscasVagaEstacionamento(null, true);
            ControllerBuscasVagaEstacionamento controllerBuscasVagaEstacionamento = new ControllerBuscasVagaEstacionamento(telaBuscasVagaEstacionamento);
            telaBuscasVagaEstacionamento.setVisible(true);
        } else if (e.getSource() == this.telaCadastroVagaEstacionamento.getjButtonSair()) {
            this.telaCadastroVagaEstacionamento.dispose();
        }
    }
}