package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TelaBuscasServico;
import view.TelaCadastroServico;

public class ControllerCadServico implements ActionListener {

    private TelaCadastroServico telaServiço;

    public ControllerCadServico(TelaCadastroServico telaServiço) {
        this.telaServiço = telaServiço;
        this.telaServiço.getjButtonNovo().addActionListener(this);
        this.telaServiço.getjButtonCancelar().addActionListener(this);
        this.telaServiço.getjButtonGravar().addActionListener(this);
        this.telaServiço.getjButtonBuscar().addActionListener(this);
        this.telaServiço.getjButtonSair().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaServiço.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaServiço.getjPanel2(), false);
        this.telaServiço.getjButtonNovo().setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.telaServiço.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaServiço.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaServiço.getjPanel2(), true);
        } else if (e.getSource() == this.telaServiço.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaServiço.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaServiço.getjPanel2(), false);
        } else if (e.getSource() == this.telaServiço.getjButtonGravar()) {
            utilities.Utilities.ativaDesativa(this.telaServiço.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaServiço.getjPanel2(), false);
        } else if (e.getSource() == this.telaServiço.getjButtonBuscar()) {
            TelaBuscasServico telaBuscasServico = new TelaBuscasServico(null, true);
            ControllerBuscasServico controllerBuscasServico = new ControllerBuscasServico(telaBuscasServico);
            telaBuscasServico.setVisible(true);
        } else if (e.getSource() == this.telaServiço.getjButtonSair()) {
            this.telaServiço.dispose();
        }
    }
}