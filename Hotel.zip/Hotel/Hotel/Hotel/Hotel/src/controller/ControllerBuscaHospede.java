/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import view.TelaBuscasHospede;

/**
 *
 * @author aluno
 */
public class ControllerBuscaHospede implements ActionListener {

    TelaBuscasHospede telaBuscaHospede;

    public ControllerBuscaHospede(TelaBuscasHospede telaBuscaHospede) {
        this.telaBuscaHospede = telaBuscaHospede;

        this.telaBuscaHospede.getjButtonCarregar().addActionListener(this);
        this.telaBuscaHospede.getjButtonFiltrar().addActionListener(this);
        this.telaBuscaHospede.getjButtonSair().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscaHospede.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Presionado...");
            if (this.telaBuscaHospede.getjTableColunas().getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Errou. \nNão Existe Dados Selecionados");
                
            }else {
                JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
            }

        
            
        } else if (evento.getSource() == this.telaBuscaHospede.getjButtonFiltrar()) {
            JOptionPane.showMessageDialog(null, "Botão Filtrar Presionado...");
            if(this.telaBuscaHospede.getjTextFieldValor().getText().trim().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(null, "Sem Dados para a Seleção...");
                
            }else{
              JOptionPane.showMessageDialog(null,"Filtrando informações...");
              if(this.telaBuscaHospede.getjComboBoxFiltrarPor().getSelectedIndex()==0){
                  JOptionPane.showMessageDialog(null, "Filtrando por ID");
              }else if (this.telaBuscaHospede.getjComboBoxFiltrarPor().getSelectedIndex()==1){
                  JOptionPane.showMessageDialog(null, "Filtrando por Nome");
              }else if (this.telaBuscaHospede.getjComboBoxFiltrarPor().getSelectedIndex()==2){
                  JOptionPane.showMessageDialog(null,"Filtrando por CPF");
              }
            }
        } else if (evento.getSource() == this.telaBuscaHospede.getjButtonSair()) {
            this.telaBuscaHospede.dispose();

        }
    }

}
