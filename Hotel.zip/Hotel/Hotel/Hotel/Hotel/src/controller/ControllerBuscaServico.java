/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import view.TelaBuscaServico;

/**
 *   
 * @author aluno
 */
public class ControllerBuscaServico implements ActionListener {

    TelaBuscaServico telaBuscaServico;

    public ControllerBuscaServico(TelaBuscaServico telaBuscaServico) {
        this.telaBuscaServico = telaBuscaServico;

        this.telaBuscaServico.getjButtonCarregar().addActionListener(this);
        this.telaBuscaServico.getjButtonFiltrar().addActionListener(this);
        this.telaBuscaServico.getjButtonSair().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscaServico.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Presionado...");
            if (this.telaBuscaServico.getjTableColunas().getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Errou. \nNão Existe Dados Selecionados");
                
            }else {
                JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
            }

        
            
        } else if (evento.getSource() == this.telaBuscaServico.getjButtonFiltrar()) {
            JOptionPane.showMessageDialog(null, "Botão Filtrar Presionado...");
            if(this.telaBuscaServico.getjTextFieldValor().getText().trim().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(null, "Sem Dados para a Seleção...");
                
            }else{
              JOptionPane.showMessageDialog(null,"Filtrando informações...");
              if(this.telaBuscaServico.getjComboBoxFiltrarPor().getSelectedIndex()==0){
                  JOptionPane.showMessageDialog(null, "Filtrando por ID");
              }else if (this.telaBuscaServico.getjComboBoxFiltrarPor().getSelectedIndex()==1){
                  JOptionPane.showMessageDialog(null, "Filtrando por Descrição");
              }else if (this.telaBuscaServico.getjComboBoxFiltrarPor().getSelectedIndex()==2){
                  JOptionPane.showMessageDialog(null,"Filtrando por Status");
              }
            }
        } else if (evento.getSource() == this.telaBuscaServico.getjButtonSair()) {
            this.telaBuscaServico.dispose();

        }
    }

}
