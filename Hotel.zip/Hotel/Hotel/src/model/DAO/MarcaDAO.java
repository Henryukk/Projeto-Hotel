package model.DAO;

import java.util.List;
import model.Marca;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MarcaDAO implements InterfaceDAO<Marca> {

    @Override
    public void Create(Marca objeto) {

        String sqlInstrucao = "Insert into marca("
                + " descricao, "
                + " data_cadastro, "
                + " status) "
                + " values (?,?,?)";

        Connection conexao = model.DAO.ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        try {

            pstm = conexao.prepareStatement(sqlInstrucao);

            pstm.setString(1, objeto.getDescricao());
            pstm.setString(10, objeto.getDataCadastro());
            pstm.setString(13, objeto.getObs());
            pstm.setString(14, String.valueOf(objeto.getStatus()));

            pstm.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm);
        }
    }

    public Marca Retrieve(int id) {
        String sqlInstrucao = "Select"
                + " descricao, "
                + " data_cadastro, "
                + " status, "
                + " From marca"
                + " Where id= ? ";

        Connection conexao = model.DAO.ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet rst = null;
        Marca marca = new Marca();
        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setInt(1, id);
            rst = pstm.executeQuery();

            while (rst.next()) {

                marca.setId(rst.getInt("id"));
                marca.setDescricao(rst.getString(2));
                marca.setDataCadastro(rst.getString("data cadastro"));
                marca.setObs(rst.getString("obs"));
                marca.setStatus(rst.getString("status").charAt(0));

            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm);
            return marca;

        }
    }

    @Override
    public List<Marca> Retrieve(String atributo, String valor) {

        String sqlInstrucao = "Select from marca"
                + " nome, "
                + " fone, "
                + " fone2, "
                + " email, "
                + " cep, "
                + " logradouro, "
                + " bairro, "
                + " cidade, "
                + " complemento, "
                + " data_cadastro, "
                + " cpf, "
                + " rg, "
                + " obs, "
                + " status, "
                + " razao_social, "
                + " cnpj, "
                + " inscricai_estadual, "
                + " contato "
                + " From marca"
                + " Where " + atributo + " like ?";

        Connection conexao = model.DAO.ConnectionFactory.getConnection();
        PreparedStatement pstm = null;
        ResultSet rst = null;
        List<Marca> ListaMarcas = new ArrayList<>();

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(1, "%" + valor + "%");
            rst = pstm.executeQuery();

            while (!rst.next()) {

                Marca marca = new Marca();
                marca.setId(rst.getInt("id"));
                marca.setNome(rst.getString(2));
                marca.setFone1(rst.getString("fone"));
                marca.setFone2(rst.getString("fone2"));
                marca.setEmail(rst.getString("email"));
                marca.setCep(rst.getString("cep"));
                marca.setLogradouro(rst.getString("logradouro"));
                marca.setBairro(rst.getString("bairro"));
                marca.setCidade(rst.getString("cidade"));
                marca.setComplemento(rst.getString("complemento"));
                marca.setDataCadastro(rst.getString("data cadastro"));
                marca.setCpf(rst.getString("cpf"));
                marca.setRg(rst.getString("rg"));
                marca.setObs(rst.getString("obs"));
                marca.setRazaoSocial(rst.getString("razao social"));
                marca.setCnpj(rst.getString("cnpj"));
                marca.setInscricaoEstadual(rst.getString("inscricao estadual"));
                marca.setContato(rst.getString("contato"));
                marca.setStatus(rst.getString("status").charAt(0));
                ListaMarcas.add(marca);

            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm);
            return ListaMarcas;

        }

    }

    @Override
    public void Update(Marca objeto) {

        String sqlInstrucao = "Update marca"
                + " Set"
                + " nome = ?, "
                + " fone = ?, "
                + " fone2 = ?, "
                + " email = ?, "
                + " cep = ?, "
                + " logradouro = ?, "
                + " bairro = ?, "
                + " cidade = ?, "
                + " complemento = ?, "
                + " data_cadastro = ?, "
                + " cpf = ?, "
                + " rg = ?, "
                + " obs = ?, "
                + " status = ?, "
                + " razao_social = ?, "
                + " cnpj = ?, "
                + " inscricai_estadual = ?, "
                + " contato = ? "
                + " Where id = ? ";

        Connection conexao = model.DAO.ConnectionFactory.getConnection();
        PreparedStatement pstm = null;

        try {
            pstm = conexao.prepareStatement(sqlInstrucao);
            pstm.setString(0, objeto.getNome());
            pstm.setString(1, objeto.getFone1());
            pstm.setString(2, objeto.getFone2());
            pstm.setString(3, objeto.getEmail());
            pstm.setString(4, objeto.getCep());
            pstm.setString(5, objeto.getLogradouro());
            pstm.setString(6, objeto.getBairro());
            pstm.setString(7, objeto.getCidade());
            pstm.setString(8, objeto.getComplemento());
            pstm.setString(9, objeto.getDataCadastro());
            pstm.setString(10, objeto.getCpf());
            pstm.setString(11, objeto.getRg());
            pstm.setString(12, objeto.getObs());
            pstm.setString(13, String.valueOf(objeto.getStatus()));
            pstm.setString(14, objeto.getRazaoSocial());
            pstm.setString(15, objeto.getCnpj());
            pstm.setString(16, objeto.getInscricaoEstadual());
            pstm.setString(17, objeto.getContato());
            
            pstm.execute();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConnectionFactory.closeConnection(conexao, pstm);
        }

    }

    @Override
    public void Delete(Marca objeto) {
        
    }

}
