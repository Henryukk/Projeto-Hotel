/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import view.TelaBuscaFuncionario;

/**
 *
 * @author aluno
 */
public class ControllerBuscaFuncionario implements ActionListener {

    TelaBuscaFuncionario telaBuscaFuncionario;

    public ControllerBuscaFuncionario(TelaBuscaFuncionario telaBuscaFuncionario) {
        this.telaBuscaFuncionario = telaBuscaFuncionario;

        this.telaBuscaFuncionario.getjButtonCarregar().addActionListener(this);
        this.telaBuscaFuncionario.getjButtonFiltrar().addActionListener(this);
        this.telaBuscaFuncionario.getjButtonSair().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscaFuncionario.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Presionado...");
            if (this.telaBuscaFuncionario.getjTableColunas().getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Errou. \nNão Existe Dados Selecionados");
                
            }else {
                JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
            }

        
            
        } else if (evento.getSource() == this.telaBuscaFuncionario.getjButtonFiltrar()) {
            JOptionPane.showMessageDialog(null, "Botão Filtrar Presionado...");
            if(this.telaBuscaFuncionario.getjTextFieldValor().getText().trim().equalsIgnoreCase("")){
                JOptionPane.showMessageDialog(null, "Sem Dados para a Seleção...");
                
            }else{
              JOptionPane.showMessageDialog(null,"Filtrando informações...");
              if(this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex()==0){
                  JOptionPane.showMessageDialog(null, "Filtrando por ID");
              }else if (this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex()==1){
                  JOptionPane.showMessageDialog(null, "Filtrando por Nome");
              }else if (this.telaBuscaFuncionario.getjComboBoxFiltrarPor().getSelectedIndex()==2){
                  JOptionPane.showMessageDialog(null,"Filtrando por CPF");
              }
            }
        } else if (evento.getSource() == this.telaBuscaFuncionario.getjButtonSair()) {
            this.telaBuscaFuncionario.dispose();

        }
    }

}
