/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import static controller.ControllerCadHospede.codigo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Modelo;
import model.Veiculo;
import service.ModeloService;
import view.TelaBuscaVeiculo;
import view.TelaCadastroVeiculo;

public class ControllerCadVeiculo implements ActionListener {

    TelaCadastroVeiculo telaCadastroVeiculo;

    public ControllerCadVeiculo(TelaCadastroVeiculo telaCadastroVeiculo) {
        this.telaCadastroVeiculo = telaCadastroVeiculo;
        this.telaCadastroVeiculo.getjButtonNovo().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonSair().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonGravar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonCancelar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonBuscar().addActionListener(this);

        utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel1(), true);
        utilities.Utilities.limpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);

    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaCadastroVeiculo.getjButtonNovo()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel1(), false);
            utilities.Utilities.limpaComponentes(this.telaCadastroVeiculo.getjPanel2(), true);
            
            this.telaCadastroVeiculo.getjTextFieldIDVeiculo().setEnabled(false);
            
    //_____________________________________________________________________________________________________________
    
        } else if (evento.getSource() == this.telaCadastroVeiculo.getjButtonGravar()) {
            
             //exemplo com atributo obrigatorio
            
                Veiculo veiculo = new Veiculo();
            veiculo.setId(Integer.parseInt(this.telaCadastroVeiculo.getjTextFieldIDVeiculo().getText()));
            veiculo.setPlaca(this.telaCadastroVeiculo.getjFormattedTextFieldPlaca().getText());
            veiculo.setCor(this.telaCadastroVeiculo.getjComboBoxCorDoVeiculo().getItemAt(codigo));
            
            Modelo modelo = new Modelo();
            modelo = (Modelo) ModeloService.Carregar("Descricao", this.telaCadastroVeiculo.getjComboBoxModelo().getSelectedItem().toString());
            
            veiculo.setStatus(this.telaCadastroVeiculo.getjTextFieldStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroVeiculo.getjTextFieldIDVeiculo().getText().trim().equalsIgnoreCase("")){
                //inclusao
                veiculo.setStatus('A');
                service.VeiculoService.Criar(veiculo);
            }else {
                //atualizacao
                veiculo.setId(Integer.parseInt(this.telaCadastroVeiculo.getjTextFieldIDVeiculo().getText()));
                service.VeiculoService.Atualizar(veiculo);
            }
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel1(), true);
            utilities.Utilities.limpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
            
    //_____________________________________________________________________________________________________________
        
        } else if (evento.getSource() == this.telaCadastroVeiculo.getjButtonCancelar()) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel1(), true);
            utilities.Utilities.limpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
            
    //_____________________________________________________________________________________________________________   
        
        } else if (evento.getSource() == this.telaCadastroVeiculo.getjButtonBuscar()) {

            TelaBuscaVeiculo telaBuscaVeiculo = new TelaBuscaVeiculo(null, true);
            ControllerBuscaVeiculo controllerBuscaVeiculo = new ControllerBuscaVeiculo(telaBuscaVeiculo);
            telaBuscaVeiculo.setVisible(true);
            
    //_____________________________________________________________________________________________________________
    
        } else if (evento.getSource() == this.telaCadastroVeiculo.getjButtonSair()) {
            this.telaCadastroVeiculo.dispose();

        }
    }
}
