package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Marca;
import view.TelaBuscasMarca;
import view.TelaCadastroMarca;

public class ControllerCadMarca implements ActionListener {

    private TelaCadastroMarca telaCadastroMarca;

    public static int codigo;

    public ControllerCadMarca(TelaCadastroMarca telaCadastroMarca) {
        this.telaCadastroMarca = telaCadastroMarca;
        this.telaCadastroMarca.getjButtonNovo().addActionListener(this);
        this.telaCadastroMarca.getjButtonCancelar().addActionListener(this);
        this.telaCadastroMarca.getjButtonGravar().addActionListener(this);
        this.telaCadastroMarca.getjButtonBuscar().addActionListener(this);
        this.telaCadastroMarca.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroMarca.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroMarca.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), true);
            
            this.telaCadastroMarca.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroMarca.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroMarca.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                Marca marca = new Marca();
            marca.setId(Integer.parseInt(this.telaCadastroMarca.getjTextFieldID().getText()));
            marca.setDescricao(this.telaCadastroMarca.getjTextDescricao().getText());
            marca.setStatus(this.telaCadastroMarca.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroMarca.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                marca.setStatus('A');
                service.MarcaService.Criar(marca);
            }else {
                //atualizacao
                marca.setId(Integer.parseInt(this.telaCadastroMarca.getjTextFieldID().getText()));
                service.MarcaService.Atualizar(marca);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroMarca.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasMarca telaBuscasMarca = new TelaBuscasMarca(null, true);
        ControllerBuscasMarca controllerBuscasMarca = new ControllerBuscasMarca(telaBuscasMarca);
        telaBuscasMarca.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroMarca.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroMarca.getjPanel2(), true);
            
            this.telaCadastroMarca.getjTextFieldID().setText(codigo + "");
            this.telaCadastroMarca.getjTextFieldID().setEnabled(false);
            
            Marca marca = new Marca();
            marca = service.MarcaService.Carregar(codigo);
            
            this.telaCadastroMarca.getjTextDescricao().setText(marca.getDescricao());
            this.telaCadastroMarca.getjTextStatus().setText(String.valueOf(marca.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroMarca.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroMarca.getjButtonSair()) {
            this.telaCadastroMarca.dispose();
        }
    }
    }
    
    