package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.ProdutoCopa;
import view.TelaBuscasProdutoCopa;
import view.TelaCadastroProdutoCopa;

public class ControllerCadProdutoCopa implements ActionListener {

    private TelaCadastroProdutoCopa telaCadastroProdutoCopa;

    public static int codigo;

    public ControllerCadProdutoCopa(TelaCadastroProdutoCopa telaCadastroProdutoCopa) {
        this.telaCadastroProdutoCopa = telaCadastroProdutoCopa;
        this.telaCadastroProdutoCopa.getjButtonNovo().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonCancelar().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonGravar().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonBuscar().addActionListener(this);
        this.telaCadastroProdutoCopa.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroProdutoCopa.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroProdutoCopa.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), true);
            
            this.telaCadastroProdutoCopa.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroProdutoCopa.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroProdutoCopa.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                ProdutoCopa produtoCopa = new ProdutoCopa();
            produtoCopa.setId(Integer.parseInt(this.telaCadastroProdutoCopa.getjTextFieldID().getText()));
            produtoCopa.setDescricao(this.telaCadastroProdutoCopa.getjTextDescricao().getText());
            produtoCopa.setStatus(this.telaCadastroProdutoCopa.getjTextStatus().getText().charAt(0));
            produtoCopa.setObs(this.telaCadastroProdutoCopa.getjTextObservacao().getText());
            produtoCopa.setValor(Float.parseFloat(this.telaCadastroProdutoCopa.getjTextValor().getText()));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroProdutoCopa.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                produtoCopa.setStatus('A');
                service.ProdutoCopaService.Criar(produtoCopa);
            }else {
                //atualizacao
                produtoCopa.setId(Integer.parseInt(this.telaCadastroProdutoCopa.getjTextFieldID().getText()));
                service.ProdutoCopaService.Atualizar(produtoCopa);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroProdutoCopa.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasProdutoCopa telaBuscasProdutoCopa = new TelaBuscasProdutoCopa(null, true);
        ControllerBuscasProdutoCopa controllerBuscasProdutoCopa = new ControllerBuscasProdutoCopa(telaBuscasProdutoCopa);
        telaBuscasProdutoCopa.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroProdutoCopa.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroProdutoCopa.getjPanel2(), true);
            
            this.telaCadastroProdutoCopa.getjTextFieldID().setText(codigo + "");
            this.telaCadastroProdutoCopa.getjTextFieldID().setEnabled(false);
            
            ProdutoCopa produtoCopa = new ProdutoCopa();
            produtoCopa = service.ProdutoCopaService.Carregar(codigo);
            
            this.telaCadastroProdutoCopa.getjTextObservacao().setText(produtoCopa.getObs());
            this.telaCadastroProdutoCopa.getjTextValor().setText(String.valueOf(produtoCopa.getValor()));
            this.telaCadastroProdutoCopa.getjTextDescricao().setText(produtoCopa.getDescricao());
            this.telaCadastroProdutoCopa.getjTextStatus().setText(String.valueOf(produtoCopa.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroProdutoCopa.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroProdutoCopa.getjButtonSair()) {
            this.telaCadastroProdutoCopa.dispose();
        }
    }
    }