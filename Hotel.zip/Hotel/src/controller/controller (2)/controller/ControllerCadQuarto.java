package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Quarto;
import view.TelaBuscasQuarto;
import view.TelaCadastroQuarto;

public class ControllerCadQuarto implements ActionListener {

    private TelaCadastroQuarto telaCadastroQuarto;

    
    public static int codigo;

    public ControllerCadQuarto(TelaCadastroQuarto telaCadastroQuarto) {
        this.telaCadastroQuarto = telaCadastroQuarto;
        this.telaCadastroQuarto.getjButtonNovo().addActionListener(this);
        this.telaCadastroQuarto.getjButtonCancelar().addActionListener(this);
        this.telaCadastroQuarto.getjButtonGravar().addActionListener(this);
        this.telaCadastroQuarto.getjButtonBuscar().addActionListener(this);
        this.telaCadastroQuarto.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroQuarto.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroQuarto.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), true);
            
            this.telaCadastroQuarto.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroQuarto.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroQuarto.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                Quarto quarto = new Quarto();
            quarto.setId(Integer.parseInt(this.telaCadastroQuarto.getjTextFieldID().getText()));
            quarto.setDescricao(this.telaCadastroQuarto.getjTextDescricao().getText());
            quarto.setStatus(this.telaCadastroQuarto.getjTextStatus().getText().charAt(0));
            quarto.setObs(this.telaCadastroQuarto.getjTextObservacao().getText());
            quarto.setIdentificacao(this.telaCadastroQuarto.getjTextIdentificacao().getText());
            quarto.setFlagAnimais( Boolean.parseBoolean( this.telaCadastroQuarto.getjComboBoxAnimal().getItemAt(codigo)));
            quarto.setAndar(Integer.parseInt(this.telaCadastroQuarto.getjComboBoxAndar().getItemAt(codigo)));
            quarto.setCapacidadeDeHospedes( Integer.parseInt(this.telaCadastroQuarto.getjTextCapacidadeHospedes().getText()));
            quarto.setMetragem(Float.parseFloat(this.telaCadastroQuarto.getjComboBoxMetragem().getItemAt(codigo)));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroQuarto.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                quarto.setStatus('A');
                service.QuartoService.Criar(quarto);
            }else {
                //atualizacao
                quarto.setId(Integer.parseInt(this.telaCadastroQuarto.getjTextFieldID().getText()));
                service.QuartoService.Atualizar(quarto);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroQuarto.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasQuarto telaBuscasQuarto = new TelaBuscasQuarto(null, true);
        ControllerBuscasQuarto controllerBuscasQuarto = new ControllerBuscasQuarto(telaBuscasQuarto);
        telaBuscasQuarto.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroQuarto.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroQuarto.getjPanel2(), true);
            
            this.telaCadastroQuarto.getjTextFieldID().setText(codigo + "");
            this.telaCadastroQuarto.getjTextFieldID().setEnabled(false);
            
            Quarto quarto = new Quarto();
            quarto = service.QuartoService.Carregar(codigo);
            
            this.telaCadastroQuarto.getjTextObservacao().setText(quarto.getObs());
            this.telaCadastroQuarto.getjComboBoxMetragem().setSelectedItem(String.valueOf(quarto.getMetragem()));
            this.telaCadastroQuarto.getjComboBoxAndar().setSelectedItem(String.valueOf(quarto.getAndar()));
            this.telaCadastroQuarto.getjComboBoxAnimal().setSelectedItem(String.valueOf(quarto.getFlagAnimais()));
            this.telaCadastroQuarto.getjTextCapacidadeHospedes().setText(String.valueOf(quarto.getCapacidadeDeHospedes()));
            this.telaCadastroQuarto.getjTextDescricao().setText(quarto.getDescricao());
            this.telaCadastroQuarto.getjTextIdentificacao().setText(quarto.getIdentificacao());
            this.telaCadastroQuarto.getjTextStatus().setText(String.valueOf(quarto.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroQuarto.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroQuarto.getjButtonSair()) {
            this.telaCadastroQuarto.dispose();
        }
    }
    }