package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import model.Hospede;
import view.TelaBuscasHospede;
import view.TelaCadastroHospede;
import java.util.Date;

public class ControllerCadHospede implements ActionListener{

    public static int codigo;


    TelaCadastroHospede telaCadastroHospede;

    public ControllerCadHospede(TelaCadastroHospede telaCadastroHospede) {
        this.telaCadastroHospede = telaCadastroHospede;
        this.telaCadastroHospede.getjButtonNovo().addActionListener(this);
        this.telaCadastroHospede.getjButtonCancelar().addActionListener(this);
        this.telaCadastroHospede.getjButtonGravar().addActionListener(this);
        this.telaCadastroHospede.getjButtonBuscar().addActionListener(this);
        this.telaCadastroHospede.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroHospede.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroHospede.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), true);
            
            //colocar isso em todas as telas que possuem data de cadastro
            java.util.Date dataAtual = new Date();
            
            SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");
            String novaData = dataFormatada.format(dataAtual);
            this.telaCadastroHospede.getjFormattedDataCadastro().setText(novaData);
            this.telaCadastroHospede.getjFormattedDataCadastro().setEnabled(false);
            //-------------------------------------------------------------------------
            
            this.telaCadastroHospede.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            if (this.telaCadastroHospede.getjTextFieldNome().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "O atributo Nome é obrigatório...");
                this.telaCadastroHospede.getjTextFieldNome().requestFocus();
            } else {
                Hospede hospede = new Hospede();
            hospede.setId(Integer.parseInt(this.telaCadastroHospede.getjTextFieldID().getText()));
            hospede.setNome(this.telaCadastroHospede.getjTextFieldNome().getText());
            hospede.setBairro(this.telaCadastroHospede.getjTextBairro().getText());
            hospede.setCep(this.telaCadastroHospede.getjFormattedCEP().getText());
            hospede.setCidade(this.telaCadastroHospede.getjTextCidade().getText());
            hospede.setCnpj(this.telaCadastroHospede.getjFormattedCNPJ().getText());
            hospede.setComplemento(this.telaCadastroHospede.getjTextComplemento().getText());
            hospede.setContato(this.telaCadastroHospede.getjFormattedContato().getText());
            hospede.setCpf(this.telaCadastroHospede.getjFormattedCPF().getText());
            hospede.setDataCadastro(this.telaCadastroHospede.getjFormattedDataCadastro().getText());
            hospede.setEmail(this.telaCadastroHospede.getjFormattedEmail().getText());
            hospede.setFone1(this.telaCadastroHospede.getjFormattedFone1().getText());
            hospede.setFone2(this.telaCadastroHospede.getjFormattedFone2().getText());
            hospede.setInscricaoEstadual(this.telaCadastroHospede.getjTextInscricaoEstadual().getText());
            hospede.setLogradouro(this.telaCadastroHospede.getjTextLogradouro().getText());
            hospede.setObs(this.telaCadastroHospede.getjTextObservacao().getText());
            hospede.setRazaoSocial(this.telaCadastroHospede.getjTextRazaoSocial().getText());
            hospede.setRg(this.telaCadastroHospede.getjTextFieldRG().getText());
            hospede.setSexo(this.telaCadastroHospede.getjComboBoxSexo().getSelectedItem().toString());
            hospede.setStatus(this.telaCadastroHospede.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroHospede.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                hospede.setStatus('A');
                service.HospedeService.Criar(hospede);
            }else {
                //atualizacao
                hospede.setId(Integer.parseInt(this.telaCadastroHospede.getjTextFieldID().getText()));
                service.HospedeService.Atualizar(hospede);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), false);
            }
            
            
        } else if(evento.getSource() == this.telaCadastroHospede.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasHospede telaBuscasHospede = new TelaBuscasHospede(null, true);
        ControllerBuscasHospede controllerBuscasHospede = new ControllerBuscasHospede(telaBuscasHospede);
        telaBuscasHospede.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroHospede.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroHospede.getjPanel2(), true);
            
            this.telaCadastroHospede.getjTextFieldID().setText(codigo + "");
            this.telaCadastroHospede.getjTextFieldID().setEnabled(false);
            
            Hospede hospede = new Hospede();
            hospede = service.HospedeService.Carregar(codigo);
            
            this.telaCadastroHospede.getjFormattedCEP().setText(hospede.getCep());
            this.telaCadastroHospede.getjComboBoxSexo().setSelectedItem(hospede.getSexo());
            this.telaCadastroHospede.getjFormattedCNPJ().setText(hospede.getCnpj());
            this.telaCadastroHospede.getjFormattedCPF().setText(hospede.getCpf());
            this.telaCadastroHospede.getjFormattedContato().setText(hospede.getContato());
            this.telaCadastroHospede.getjFormattedDataCadastro().setText(hospede.getDataCadastro());
            this.telaCadastroHospede.getjFormattedEmail().setText(hospede.getEmail());
            this.telaCadastroHospede.getjFormattedFone1().setText(hospede.getFone1());
            this.telaCadastroHospede.getjFormattedFone2().setText(hospede.getFone2());
            this.telaCadastroHospede.getjTextBairro().setText(hospede.getBairro());
            this.telaCadastroHospede.getjTextCidade().setText(hospede.getCidade());
            this.telaCadastroHospede.getjTextComplemento().setText(hospede.getComplemento());
            this.telaCadastroHospede.getjTextFieldNome().setText(hospede.getNome());
            this.telaCadastroHospede.getjTextFieldRG().setText(hospede.getRg());
            this.telaCadastroHospede.getjTextInscricaoEstadual().setText(hospede.getInscricaoEstadual());
            this.telaCadastroHospede.getjTextLogradouro().setText(hospede.getLogradouro());
            this.telaCadastroHospede.getjTextObservacao().setText(hospede.getObs());
            this.telaCadastroHospede.getjTextRazaoSocial().setText(hospede.getRazaoSocial());
            this.telaCadastroHospede.getjTextStatus().setText(String.valueOf(hospede.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroHospede.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource()== this.telaCadastroHospede.getjButtonSair()) {
            this.telaCadastroHospede.dispose();
        }
    }
    
    
    
}
