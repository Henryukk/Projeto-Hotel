package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.VagaEstacionamento;
import view.TelaBuscasVagaEstacionamento;

public class ControllerBuscasVagaEstacionamento implements ActionListener {

    private TelaBuscasVagaEstacionamento telaBuscasVagaEstacionamento;
    
    public ControllerBuscasVagaEstacionamento(TelaBuscasVagaEstacionamento telaBuscasVagaEstacionamento) {
        this.telaBuscasVagaEstacionamento = telaBuscasVagaEstacionamento;
        
        this.telaBuscasVagaEstacionamento.getjButtonCarregar().addActionListener(this);
        this.telaBuscasVagaEstacionamento.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasVagaEstacionamento.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasVagaEstacionamento.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasVagaEstacionamento.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem vagas selecionadas!");
            } else {
                //JOptionPane.showMessageDialog(null, "Carregando dados da vaga para edição...");
                ControllerCadVagaEstacionamento.codigo = (int) this.telaBuscasVagaEstacionamento.getjTable1().getValueAt(this.telaBuscasVagaEstacionamento.getjTable1().getSelectedRow(), 0);
                this.telaBuscasVagaEstacionamento.dispose();
            }
        } else if (evento.getSource() == this.telaBuscasVagaEstacionamento.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasVagaEstacionamento.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Selecao");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando vagas...");
                if (this.telaBuscasVagaEstacionamento.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID da vaga");
                    VagaEstacionamento vagaEstacionamento = new VagaEstacionamento();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    vagaEstacionamento = service.VagaEstacionamentoService.Carregar(Integer.parseInt(this.telaBuscasVagaEstacionamento.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasVagaEstacionamento.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{vagaEstacionamento.getId(), vagaEstacionamento.getMetragemVaga(), vagaEstacionamento.getStatus()});
                    
                } else if (this.telaBuscasVagaEstacionamento.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por Metragem da vaga");
                    List<VagaEstacionamento> listaVagasEstacionamentos = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaVagasEstacionamentos = service.VagaEstacionamentoService.Carregar("metragem", this.telaBuscasVagaEstacionamento.getjTextFieldValor().getText());
                    
                    VagaEstacionamento vagaEstacionamento = new VagaEstacionamento();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasVagaEstacionamento.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (VagaEstacionamento vagaEstacionamentoAtualDaLista : listaVagasEstacionamentos) {
                        tabela.addRow(new Object[]{vagaEstacionamentoAtualDaLista.getId(), 
                        vagaEstacionamentoAtualDaLista.getMetragemVaga(),
                        vagaEstacionamentoAtualDaLista.getStatus()});
                    }
                    
                } 
            }
        } else if (evento.getSource() == this.telaBuscasVagaEstacionamento.getjButtonSair()) {
            this.telaBuscasVagaEstacionamento.dispose();
        }
    }
}