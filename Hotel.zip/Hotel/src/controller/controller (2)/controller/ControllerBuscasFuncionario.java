package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Funcionario;
import view.TelaBuscasFuncionario;

public class ControllerBuscasFuncionario implements ActionListener{

    TelaBuscasFuncionario telaBuscasFuncionario;
    
    public ControllerBuscasFuncionario(TelaBuscasFuncionario telaBuscasFuncionario){
    this.telaBuscasFuncionario = telaBuscasFuncionario;
    
    this.telaBuscasFuncionario.getjButtonCarregar().addActionListener(this);
    this.telaBuscasFuncionario.getjButtonFiltrar().addActionListener(this);
    this.telaBuscasFuncionario.getjButtonSair().addActionListener(this);
    
    
    }
    
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if(evento.getSource() == this.telaBuscasFuncionario.getjButtonCarregar()){
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if(this.telaBuscasFuncionario.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Errou. \nNão Existem dados selecionados!");
                
            }else {
                JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
            }
        }else if(evento.getSource() == this.telaBuscasFuncionario.getjButtonFiltrar()){
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if(this.telaBuscasFuncionario.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Seleção");
            }else {
                //JOptionPane.showMessageDialog(null, "Filtrando informações...");
                if(this.telaBuscasFuncionario.getjComboBoxFiltrar().getSelectedIndex() == 0){
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID");
                    Funcionario funcionario = new Funcionario();
                    
                    funcionario = service.FuncionarioService.Carregar(Integer.parseInt(this.telaBuscasFuncionario.getjTextFieldValor().getText()));
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasFuncionario.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{funcionario.getId(), funcionario.getNome(), funcionario.getCpf(), funcionario.getStatus()});
                    
                }else if(this.telaBuscasFuncionario.getjComboBoxFiltrar().getSelectedIndex() == 1){
                    //JOptionPane.showMessageDialog(null, "Filtrando por nome");
                    //Criando a lista para receber os hospedes
                    List<Funcionario> listaFuncionarios = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaFuncionarios = service.FuncionarioService.Carregar("nome", this.telaBuscasFuncionario.getjTextFieldValor().getText());
                    
                    Funcionario funcionario = new Funcionario();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasFuncionario.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Funcionario funcionarioAtualDaLista : listaFuncionarios) {
                        tabela.addRow(new Object[]{funcionarioAtualDaLista.getId(), 
                        funcionarioAtualDaLista.getNome(),
                        funcionarioAtualDaLista.getCpf(),
                        funcionarioAtualDaLista.getStatus()});
                    }
                }else if(this.telaBuscasFuncionario.getjComboBoxFiltrar().getSelectedIndex() == 2) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por CPF");
                     List<Funcionario> listaFuncionarios = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaFuncionarios = service.FuncionarioService.Carregar("cpf", this.telaBuscasFuncionario.getjTextFieldValor().getText());
                    
                    Funcionario funcionario = new Funcionario();                  
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasFuncionario.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Funcionario funcionarioAtualDaLista : listaFuncionarios) {
                        tabela.addRow(new Object[]{funcionarioAtualDaLista.getId(), 
                        funcionarioAtualDaLista.getNome(),
                        funcionarioAtualDaLista.getCpf(),
                        funcionarioAtualDaLista.getStatus()});
                    }
                }
            }
        }else if(evento.getSource() == this.telaBuscasFuncionario.getjButtonSair()){
            this.telaBuscasFuncionario.dispose();
        }
    }
    
}
