package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Modelo;
import model.Veiculo;
import service.ModeloService;
import view.TelaBuscasVeiculo;
import view.TelaCadastroVeiculo;

public class ControllerCadVeiculo implements ActionListener {

    private TelaCadastroVeiculo telaCadastroVeiculo;

    
    public static int codigo;

    public ControllerCadVeiculo(TelaCadastroVeiculo telaCadastroVeiculo) {
        this.telaCadastroVeiculo = telaCadastroVeiculo;
        this.telaCadastroVeiculo.getjButtonNovo().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonCancelar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonGravar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonBuscar().addActionListener(this);
        this.telaCadastroVeiculo.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroVeiculo.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroVeiculo.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), true);
            
            this.telaCadastroVeiculo.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroVeiculo.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroVeiculo.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                Veiculo veiculo = new Veiculo();
            veiculo.setId(Integer.parseInt(this.telaCadastroVeiculo.getjTextFieldID().getText()));
            veiculo.setPlaca(this.telaCadastroVeiculo.getjTextPlaca().getText());
            veiculo.setCor(this.telaCadastroVeiculo.getjComboBoxCor().getItemAt(codigo));
            
            Modelo modelo = new Modelo();
            modelo = (Modelo) ModeloService.Carregar("Descricao", this.telaCadastroVeiculo.getjComboBoxModelo().getSelectedItem().toString());
            
            veiculo.setStatus(this.telaCadastroVeiculo.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroVeiculo.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                veiculo.setStatus('A');
                service.VeiculoService.Criar(veiculo);
            }else {
                //atualizacao
                veiculo.setId(Integer.parseInt(this.telaCadastroVeiculo.getjTextFieldID().getText()));
                service.VeiculoService.Atualizar(veiculo);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroVeiculo.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasVeiculo telaBuscasVeiculo = new TelaBuscasVeiculo(null, true);
        ControllerBuscasVeiculo controllerBuscasVeiculo = new ControllerBuscasVeiculo(telaBuscasVeiculo);
        telaBuscasVeiculo.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVeiculo.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVeiculo.getjPanel2(), true);
            
            this.telaCadastroVeiculo.getjTextFieldID().setText(codigo + "");
            this.telaCadastroVeiculo.getjTextFieldID().setEnabled(false);
            
            Veiculo veiculo = new Veiculo();
            veiculo = service.VeiculoService.Carregar(codigo);
            Modelo modelo = new Modelo();
            this.telaCadastroVeiculo.getjTextPlaca().setText(veiculo.getPlaca());
            //this.telaCadastroVeiculo.getjComboBoxModelo().setSelectedItem(veiculo.setModelo(modelo));
            this.telaCadastroVeiculo.getjComboBoxCor().setSelectedItem(veiculo.getCor());
            this.telaCadastroVeiculo.getjTextStatus().setText(String.valueOf(veiculo.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroVeiculo.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroVeiculo.getjButtonSair()) {
            this.telaCadastroVeiculo.dispose();
        }
    }
}