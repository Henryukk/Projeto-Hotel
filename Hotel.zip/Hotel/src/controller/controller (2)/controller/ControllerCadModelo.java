package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Modelo;
import view.TelaBuscasModelo;
import view.TelaCadastroModelo;

public class ControllerCadModelo implements ActionListener {

    private TelaCadastroModelo telaCadastroModelo;

    public static int codigo;

    public ControllerCadModelo(TelaCadastroModelo telaCadastroModelo) {
        this.telaCadastroModelo = telaCadastroModelo;
        this.telaCadastroModelo.getjButtonNovo().addActionListener(this);
        this.telaCadastroModelo.getjButtonCancelar().addActionListener(this);
        this.telaCadastroModelo.getjButtonGravar().addActionListener(this);
        this.telaCadastroModelo.getjButtonBuscar().addActionListener(this);
        this.telaCadastroModelo.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroModelo.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroModelo.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), true);
            
            this.telaCadastroModelo.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroModelo.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroModelo.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                Modelo modelo = new Modelo();
            modelo.setId(Integer.parseInt(this.telaCadastroModelo.getjTextFieldID().getText()));
            modelo.setDescricao(this.telaCadastroModelo.getjTextDescricao().getText());
            modelo.setStatus(this.telaCadastroModelo.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroModelo.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                modelo.setStatus('A');
                service.ModeloService.Criar(modelo);
            }else {
                //atualizacao
                modelo.setId(Integer.parseInt(this.telaCadastroModelo.getjTextFieldID().getText()));
                service.ModeloService.Atualizar(modelo);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroModelo.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasModelo telaBuscasModelo = new TelaBuscasModelo(null, true);
        ControllerBuscasModelo controllerBuscasModelo = new ControllerBuscasModelo(telaBuscasModelo);
        telaBuscasModelo.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroModelo.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroModelo.getjPanel2(), true);
            
            this.telaCadastroModelo.getjTextFieldID().setText(codigo + "");
            this.telaCadastroModelo.getjTextFieldID().setEnabled(false);
            
            Modelo modelo = new Modelo();
            modelo = service.ModeloService.Carregar(codigo);
            
            this.telaCadastroModelo.getjTextDescricao().setText(modelo.getDescricao());
            this.telaCadastroModelo.getjTextStatus().setText(String.valueOf(modelo.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroModelo.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroModelo.getjButtonSair()) {
            this.telaCadastroModelo.dispose();
        }
    }
    }