package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Servico;
import view.TelaBuscasServico;
import view.TelaCadastroServico;

public class ControllerCadServico implements ActionListener {

    private TelaCadastroServico telaCadastroServico;

    
    public static int codigo;

    public ControllerCadServico(TelaCadastroServico telaCadastroServico) {
        this.telaCadastroServico = telaCadastroServico;
        this.telaCadastroServico.getjButtonNovo().addActionListener(this);
        this.telaCadastroServico.getjButtonCancelar().addActionListener(this);
        this.telaCadastroServico.getjButtonGravar().addActionListener(this);
        this.telaCadastroServico.getjButtonBuscar().addActionListener(this);
        this.telaCadastroServico.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroServico.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroServico.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroServico.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroServico.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroServico.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroServico.getjPanel2(), true);
            
            this.telaCadastroServico.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroServico.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroServico.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroServico.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroServico.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                Servico servico = new Servico();
            servico.setId(Integer.parseInt(this.telaCadastroServico.getjTextFieldID().getText()));
            servico.setDescricao(this.telaCadastroServico.getjTextDescricao().getText());
            servico.setObs(this.telaCadastroServico.getjTextObservacao().getText());
            servico.setStatus(this.telaCadastroServico.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroServico.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                servico.setStatus('A');
                service.ServicoService.Criar(servico);
            }else {
                //atualizacao
                servico.setId(Integer.parseInt(this.telaCadastroServico.getjTextFieldID().getText()));
                service.ServicoService.Atualizar(servico);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroServico.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroServico.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroServico.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasServico telaBuscasServico = new TelaBuscasServico(null, true);
        ControllerBuscasServico controllerBuscasServico = new ControllerBuscasServico(telaBuscasServico);
        telaBuscasServico.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroServico.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroServico.getjPanel2(), true);
            
            this.telaCadastroServico.getjTextFieldID().setText(codigo + "");
            this.telaCadastroServico.getjTextFieldID().setEnabled(false);
            
            Servico servico = new Servico();
            servico = service.ServicoService.Carregar(codigo);
            
            this.telaCadastroServico.getjTextObservacao().setText(servico.getObs());
            this.telaCadastroServico.getjTextDescricao().setText(servico.getDescricao());
            this.telaCadastroServico.getjTextStatus().setText(String.valueOf(servico.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroServico.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroServico.getjButtonSair()) {
            this.telaCadastroServico.dispose();
        }
    }
}