package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Hospede;
import view.TelaBuscasHospede;

public class ControllerBuscasHospede implements ActionListener{
    
    TelaBuscasHospede telaBuscasHospede;
    
    public ControllerBuscasHospede(TelaBuscasHospede telaBuscasHospede){
    this.telaBuscasHospede = telaBuscasHospede;
    
    this.telaBuscasHospede.getjButtonCarregar().addActionListener(this);
    this.telaBuscasHospede.getjButtonFiltrar().addActionListener(this);
    this.telaBuscasHospede.getjButtonSair().addActionListener(this);
    
    
    }
    
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if(evento.getSource() == this.telaBuscasHospede.getjButtonCarregar()){
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if(this.telaBuscasHospede.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Errou. \nNão Existem dados selecionados!");
                
            }else {
                //JOptionPane.showMessageDialog(null, "Carregando Dados para Edição...");
                ControllerCadHospede.codigo = (int) this.telaBuscasHospede.getjTable1().getValueAt(this.telaBuscasHospede.getjTable1().getSelectedRow(), 0);
                this.telaBuscasHospede.dispose();
            }
        }else if(evento.getSource() == this.telaBuscasHospede.getjButtonFiltrar()){
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if(this.telaBuscasHospede.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Seleção");
            }else {
                //JOptionPane.showMessageDialog(null, "Filtrando informações...");
                if(this.telaBuscasHospede.getjComboBoxFiltrar().getSelectedIndex() == 0){
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID");
                    // Criando objeto para receber o dado que vira do banco de dados
                    Hospede hospede = new Hospede();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    hospede = service.HospedeService.Carregar(Integer.parseInt(this.telaBuscasHospede.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasHospede.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{hospede.getId(), hospede.getNome(), hospede.getCpf(), hospede.getStatus()});
                    
                            
                }else if(this.telaBuscasHospede.getjComboBoxFiltrar().getSelectedIndex() == 1){
                    //JOptionPane.showMessageDialog(null, "Filtrando por nome");
                    //Criando a lista para receber os hospedes
                    List<Hospede> listaHospedes = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaHospedes = service.HospedeService.Carregar("nome", this.telaBuscasHospede.getjTextFieldValor().getText());
                    
                    Hospede hospede = new Hospede();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasHospede.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Hospede hospedeAtualDaLista : listaHospedes) {
                        tabela.addRow(new Object[]{hospedeAtualDaLista.getId(), 
                        hospedeAtualDaLista.getNome(),
                        hospedeAtualDaLista.getCpf(),
                        hospedeAtualDaLista.getStatus()});
                    }
                    
                }else if(this.telaBuscasHospede.getjComboBoxFiltrar().getSelectedIndex() == 2) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por CPF");
                    List<Hospede> listaHospedes = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaHospedes = service.HospedeService.Carregar("cpf", this.telaBuscasHospede.getjTextFieldValor().getText());
                    
                    Hospede hospede = new Hospede();                  
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasHospede.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (Hospede hospedeAtualDaLista : listaHospedes) {
                        tabela.addRow(new Object[]{hospedeAtualDaLista.getId(), 
                        hospedeAtualDaLista.getNome(),
                        hospedeAtualDaLista.getCpf(),
                        hospedeAtualDaLista.getStatus()});
                    }
                }
            }
        }else if(evento.getSource() == this.telaBuscasHospede.getjButtonSair()){
            this.telaBuscasHospede.dispose();
        }
    }

    
    
}
