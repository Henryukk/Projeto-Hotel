package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Fornecedor;
import view.TelaBuscasFornecedor;
import view.TelaCadastroFornecedor;

public class ControllerCadFornecedor implements ActionListener {

    private TelaCadastroFornecedor telaCadastroFornecedor;
  
    public static int codigo;

    public ControllerCadFornecedor(TelaCadastroFornecedor telaCadastroFornecedor) {
        this.telaCadastroFornecedor = telaCadastroFornecedor;
        this.telaCadastroFornecedor.getjButtonNovo().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonCancelar().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonGravar().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonBuscar().addActionListener(this);
        this.telaCadastroFornecedor.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroFornecedor.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroFornecedor.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), true);
            
            this.telaCadastroFornecedor.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroFornecedor.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroFornecedor.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            if (this.telaCadastroFornecedor.getjTextFieldNome().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "O atributo Nome é obrigatório...");
                this.telaCadastroFornecedor.getjTextFieldNome().requestFocus();
            } else {
                Fornecedor fornecedor = new Fornecedor();
            fornecedor.setId(Integer.parseInt(this.telaCadastroFornecedor.getjTextFieldID().getText()));
            fornecedor.setNome(this.telaCadastroFornecedor.getjTextFieldNome().getText());
            fornecedor.setBairro(this.telaCadastroFornecedor.getjTextBairro().getText());
            fornecedor.setCep(this.telaCadastroFornecedor.getjFormattedCEP().getText());
            fornecedor.setCidade(this.telaCadastroFornecedor.getjTextCidade().getText());
            fornecedor.setCnpj(this.telaCadastroFornecedor.getjFormattedCNPJ().getText());
            fornecedor.setComplemento(this.telaCadastroFornecedor.getjTextComplemento().getText());
            fornecedor.setContato(this.telaCadastroFornecedor.getjTextContato().getText());
            fornecedor.setCpf(this.telaCadastroFornecedor.getjFormattedCPF().getText());
            fornecedor.setDataCadastro(this.telaCadastroFornecedor.getjFormattedDataCadastro().getText());
            fornecedor.setEmail(this.telaCadastroFornecedor.getjFormattedEmail().getText());
            fornecedor.setFone1(this.telaCadastroFornecedor.getjFormattedFone1().getText());
            fornecedor.setFone2(this.telaCadastroFornecedor.getjFormattedFone2().getText());
            fornecedor.setInscricaoEstadual(this.telaCadastroFornecedor.getjTextInscricaoEstadual().getText());
            fornecedor.setLogradouro(this.telaCadastroFornecedor.getjTextLogradouro().getText());
            fornecedor.setObs(this.telaCadastroFornecedor.getjTextObservacao().getText());
            fornecedor.setRazaoSocial(this.telaCadastroFornecedor.getjTextFieldRazaoSocial().getText());
            fornecedor.setRg(this.telaCadastroFornecedor.getjTextFieldRG().getText());
            fornecedor.setStatus(this.telaCadastroFornecedor.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroFornecedor.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                fornecedor.setStatus('A');
                service.FornecedorService.Criar(fornecedor);
            }else {
                //atualizacao
                fornecedor.setId(Integer.parseInt(this.telaCadastroFornecedor.getjTextFieldID().getText()));
                service.FornecedorService.Atualizar(fornecedor);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), false);
            }
            
            
        } else if(evento.getSource() == this.telaCadastroFornecedor.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasFornecedor telaBuscasFornecedor = new TelaBuscasFornecedor(null, true);
        ControllerBuscasFornecedor controllerBuscasFornecedor = new ControllerBuscasFornecedor(telaBuscasFornecedor);
        telaBuscasFornecedor.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFornecedor.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFornecedor.getjPanel2(), true);
            
            this.telaCadastroFornecedor.getjTextFieldID().setText(codigo + "");
            this.telaCadastroFornecedor.getjTextFieldID().setEnabled(false);
            
            Fornecedor fornecedor = new Fornecedor();
            fornecedor = service.FornecedorService.Carregar(codigo);
            
            this.telaCadastroFornecedor.getjFormattedCEP().setText(fornecedor.getCep());
            this.telaCadastroFornecedor.getjFormattedCNPJ().setText(fornecedor.getCnpj());
            this.telaCadastroFornecedor.getjFormattedCPF().setText(fornecedor.getCpf());
            this.telaCadastroFornecedor.getjTextContato().setText(fornecedor.getContato());
            this.telaCadastroFornecedor.getjFormattedDataCadastro().setText(fornecedor.getDataCadastro());
            this.telaCadastroFornecedor.getjFormattedEmail().setText(fornecedor.getEmail());
            this.telaCadastroFornecedor.getjFormattedFone1().setText(fornecedor.getFone1());
            this.telaCadastroFornecedor.getjFormattedFone2().setText(fornecedor.getFone2());
            this.telaCadastroFornecedor.getjTextBairro().setText(fornecedor.getBairro());
            this.telaCadastroFornecedor.getjTextCidade().setText(fornecedor.getCidade());
            this.telaCadastroFornecedor.getjTextComplemento().setText(fornecedor.getComplemento());
            this.telaCadastroFornecedor.getjTextFieldNome().setText(fornecedor.getNome());
            this.telaCadastroFornecedor.getjTextFieldRG().setText(fornecedor.getRg());
            this.telaCadastroFornecedor.getjTextInscricaoEstadual().setText(fornecedor.getInscricaoEstadual());
            this.telaCadastroFornecedor.getjTextLogradouro().setText(fornecedor.getLogradouro());
            this.telaCadastroFornecedor.getjTextObservacao().setText(fornecedor.getObs());
            this.telaCadastroFornecedor.getjTextFieldRazaoSocial().setText(fornecedor.getRazaoSocial());
            this.telaCadastroFornecedor.getjTextStatus().setText(String.valueOf(fornecedor.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroFornecedor.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroFornecedor.getjButtonSair()) {
            this.telaCadastroFornecedor.dispose();
        }
    }
    
    
    
}