package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.ProdutoCopa;
import view.TelaBuscasProdutoCopa;

public class ControllerBuscasProdutoCopa implements ActionListener {

    private TelaBuscasProdutoCopa telaBuscasProdutoCopa;
    
    public ControllerBuscasProdutoCopa(TelaBuscasProdutoCopa telaBuscasProdutoCopa) {
        this.telaBuscasProdutoCopa = telaBuscasProdutoCopa;
        
        this.telaBuscasProdutoCopa.getjButtonCarregar().addActionListener(this);
        this.telaBuscasProdutoCopa.getjButtonFiltrar().addActionListener(this);
        this.telaBuscasProdutoCopa.getjButtonSair().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        if (evento.getSource() == this.telaBuscasProdutoCopa.getjButtonCarregar()) {
            JOptionPane.showMessageDialog(null, "Botão Carregar Pressionado...");
            if (this.telaBuscasProdutoCopa.getjTable1().getRowCount() <= 0) {
                JOptionPane.showMessageDialog(null, "Erro. \nNão existem produtos selecionados!");
            } else {
                //JOptionPane.showMessageDialog(null, "Carregando dados do produto para edição...");
                ControllerCadProdutoCopa.codigo = (int) this.telaBuscasProdutoCopa.getjTable1().getValueAt(this.telaBuscasProdutoCopa.getjTable1().getSelectedRow(), 0);
                this.telaBuscasProdutoCopa.dispose();
            }
        } else if (evento.getSource() == this.telaBuscasProdutoCopa.getjButtonFiltrar()) {
            //JOptionPane.showMessageDialog(null, "Botão Filtrar Pressionado...");
            if (this.telaBuscasProdutoCopa.getjTextFieldValor().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "Sem dados para a Selecao");
            } else {
                //JOptionPane.showMessageDialog(null, "Filtrando produtos...");
                if (this.telaBuscasProdutoCopa.getjComboBoxFiltrar().getSelectedIndex() == 0) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por ID");
                    ProdutoCopa produtoCopa = new ProdutoCopa();
                    
                    //Carregando o registro de hospede na entidade para o objeto hospede
                    produtoCopa = service.ProdutoCopaService.Carregar(Integer.parseInt(this.telaBuscasProdutoCopa.getjTextFieldValor().getText()));
                    
                    //Criando um objeto tabela do tipo defaulttablemodel e atribuindo o nosso modelo de tabela a ele
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasProdutoCopa.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    tabela.addRow(new Object[]{produtoCopa.getId(), produtoCopa.getDescricao(), produtoCopa.getValor(), produtoCopa.getStatus()});
                    
                } else if (this.telaBuscasProdutoCopa.getjComboBoxFiltrar().getSelectedIndex() == 1) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por descriçao do produto");
                    List<ProdutoCopa> listaProdutosCopa = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaProdutosCopa = service.ProdutoCopaService.Carregar("descricao", this.telaBuscasProdutoCopa.getjTextFieldValor().getText());
                    
                    ProdutoCopa produtoCopa = new ProdutoCopa();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasProdutoCopa.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (ProdutoCopa produtoCopaAtualDaLista : listaProdutosCopa) {
                        tabela.addRow(new Object[]{produtoCopaAtualDaLista.getId(), 
                        produtoCopaAtualDaLista.getDescricao(),
                        produtoCopaAtualDaLista.getValor(),
                        produtoCopaAtualDaLista.getStatus()});
                    }
                    
                } else if (this.telaBuscasProdutoCopa.getjComboBoxFiltrar().getSelectedIndex() == 2) {
                    //JOptionPane.showMessageDialog(null, "Filtrando por valor do produto");
                    List<ProdutoCopa> listaProdutosCopa = new ArrayList<>();
                    //Carregando os hospedes via sql para dentro da lista
                    listaProdutosCopa = service.ProdutoCopaService.Carregar("valor", this.telaBuscasProdutoCopa.getjTextFieldValor().getText());
                    
                    ProdutoCopa produtoCopa = new ProdutoCopa();
                    
                    
                    DefaultTableModel tabela = (DefaultTableModel) this.telaBuscasProdutoCopa.getjTable1().getModel();
                    tabela.setRowCount(0);
                    
                    for (ProdutoCopa produtoCopaAtualDaLista : listaProdutosCopa) {
                        tabela.addRow(new Object[]{produtoCopaAtualDaLista.getId(), 
                        produtoCopaAtualDaLista.getDescricao(),
                        produtoCopaAtualDaLista.getValor(),
                        produtoCopaAtualDaLista.getStatus()});
                    }
                } 
            }
        } else if (evento.getSource() == this.telaBuscasProdutoCopa.getjButtonSair()) {
            this.telaBuscasProdutoCopa.dispose();
        }
    }
}