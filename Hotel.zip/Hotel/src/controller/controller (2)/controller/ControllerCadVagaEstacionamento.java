package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.VagaEstacionamento;
import view.TelaBuscasVagaEstacionamento;
import view.TelaCadastroVagaEstacionamento;

public class ControllerCadVagaEstacionamento implements ActionListener {

    private TelaCadastroVagaEstacionamento telaCadastroVagaEstacionamento;

    
    public static int codigo;

    public ControllerCadVagaEstacionamento(TelaCadastroVagaEstacionamento telaCadastroVagaEstacionamento) {
        this.telaCadastroVagaEstacionamento = telaCadastroVagaEstacionamento;
        this.telaCadastroVagaEstacionamento.getjButtonNovo().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonCancelar().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonGravar().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonBuscar().addActionListener(this);
        this.telaCadastroVagaEstacionamento.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroVagaEstacionamento.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroVagaEstacionamento.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), true);
            
            this.telaCadastroVagaEstacionamento.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroVagaEstacionamento.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroVagaEstacionamento.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            
                VagaEstacionamento vagaEstacionamento = new VagaEstacionamento();
            vagaEstacionamento.setId(Integer.parseInt(this.telaCadastroVagaEstacionamento.getjTextFieldID().getText()));
            vagaEstacionamento.setDescricao(this.telaCadastroVagaEstacionamento.getjTextDescricao().getText());
            vagaEstacionamento.setObs(this.telaCadastroVagaEstacionamento.getjTextObservacao().getText());
            vagaEstacionamento.setStatus(this.telaCadastroVagaEstacionamento.getjTextStatus().getText().charAt(0));
            vagaEstacionamento.setMetragemVaga(Float.parseFloat(this.telaCadastroVagaEstacionamento.getjComboBoxMetragemVaga().getItemAt(codigo)));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroVagaEstacionamento.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                vagaEstacionamento.setStatus('A');
                service.VagaEstacionamentoService.Criar(vagaEstacionamento);
            }else {
                //atualizacao
                vagaEstacionamento.setId(Integer.parseInt(this.telaCadastroVagaEstacionamento.getjTextFieldID().getText()));
                service.VagaEstacionamentoService.Atualizar(vagaEstacionamento);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), false);
            
            
            
        } else if(evento.getSource() == this.telaCadastroVagaEstacionamento.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasVagaEstacionamento telaBuscasVagaEstacionamento = new TelaBuscasVagaEstacionamento(null, true);
        ControllerBuscasVagaEstacionamento controllerBuscasVagaEstacionamento = new ControllerBuscasVagaEstacionamento(telaBuscasVagaEstacionamento);
        telaBuscasVagaEstacionamento.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroVagaEstacionamento.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroVagaEstacionamento.getjPanel2(), true);
            
            this.telaCadastroVagaEstacionamento.getjTextFieldID().setText(codigo + "");
            this.telaCadastroVagaEstacionamento.getjTextFieldID().setEnabled(false);
            
            VagaEstacionamento vagaEstacionamento = new VagaEstacionamento();
            vagaEstacionamento = service.VagaEstacionamentoService.Carregar(codigo);
            
            this.telaCadastroVagaEstacionamento.getjTextObservacao().setText(vagaEstacionamento.getObs());
            this.telaCadastroVagaEstacionamento.getjTextDescricao().setText(vagaEstacionamento.getDescricao());
            this.telaCadastroVagaEstacionamento.getjComboBoxMetragemVaga().setSelectedItem(String.valueOf(vagaEstacionamento.getMetragemVaga()));
            this.telaCadastroVagaEstacionamento.getjTextStatus().setText(String.valueOf(vagaEstacionamento.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroVagaEstacionamento.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroVagaEstacionamento.getjButtonSair()) {
            this.telaCadastroVagaEstacionamento.dispose();
        }
    }
}