package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Funcionario;
import view.TelaBuscasFuncionario;
import view.TelaCadastroFuncionario;

public class ControllerCadFuncionario implements ActionListener{
    
    TelaCadastroFuncionario telaCadastroFuncionario;
    
    public static int codigo;


    public ControllerCadFuncionario(TelaCadastroFuncionario telaCadastroFuncionario) {
        this.telaCadastroFuncionario = telaCadastroFuncionario;
        this.telaCadastroFuncionario.getjButtonNovo().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonCancelar().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonGravar().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonBuscar().addActionListener(this);
        this.telaCadastroFuncionario.getjButtonSair().addActionListener(this);
    
        utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), true);
        utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), false);
        //Desenvolver as setagens de situação inicial dos componentes
    
        this.telaCadastroFuncionario.getjButtonNovo().setEnabled(true);
        }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == this.telaCadastroFuncionario.getjButtonNovo()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), true);
            
            this.telaCadastroFuncionario.getjTextFieldID().setEnabled(false);
            
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonCancelar()) {
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), false);
            
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonGravar()) {
            
            //exemplo com atributo obrigatorio
            if (this.telaCadastroFuncionario.getjTextFieldNome().getText().trim().equalsIgnoreCase("")) {
                JOptionPane.showMessageDialog(null, "O atributo Nome é obrigatório...");
                this.telaCadastroFuncionario.getjTextFieldNome().requestFocus();
            } else {
                Funcionario funcionario = new Funcionario();
            funcionario.setId(Integer.parseInt(this.telaCadastroFuncionario.getjTextFieldID().getText()));
            funcionario.setNome(this.telaCadastroFuncionario.getjTextFieldNome().getText());
            funcionario.setBairro(this.telaCadastroFuncionario.getjTextBairro().getText());
            funcionario.setCep(this.telaCadastroFuncionario.getjFormattedCEP().getText());
            funcionario.setCidade(this.telaCadastroFuncionario.getjTextCidade().getText());
            funcionario.setComplemento(this.telaCadastroFuncionario.getjTextComplemento().getText());
            funcionario.setCpf(this.telaCadastroFuncionario.getjFormattedCPF().getText());
            funcionario.setDataCadastro(this.telaCadastroFuncionario.getjFormattedDataCadastro().getText());
            funcionario.setEmail(this.telaCadastroFuncionario.getjFormattedEmail().getText());
            funcionario.setFone1(this.telaCadastroFuncionario.getjFormattedFone1().getText());
            funcionario.setFone2(this.telaCadastroFuncionario.getjFormattedFone2().getText());
            funcionario.setLogradouro(this.telaCadastroFuncionario.getjTextLogradouro().getText());
            funcionario.setObs(this.telaCadastroFuncionario.getjTextObservacao().getText());
            funcionario.setRg(this.telaCadastroFuncionario.getjTextFieldRG().getText());
            funcionario.setSexo(this.telaCadastroFuncionario.getjComboBoxSexo().getItemAt(codigo));
            funcionario.setUsuario(this.telaCadastroFuncionario.getjTextUsuario().getText());
            funcionario.setSenha(new String(this.telaCadastroFuncionario.getjPasswordSenha().getPassword()));
            funcionario.setStatus(this.telaCadastroFuncionario.getjTextStatus().getText().charAt(0));
            //fazer o resto ------------------------------------------------------
            //nao efetuar a atribuicao do status pq ainda nao estamos considerando estas situacoes 
            //e no caso estou setando somente no momento da inclusao
            if(this.telaCadastroFuncionario.getjTextFieldID().getText().trim().equalsIgnoreCase("")){
                //inclusao
                funcionario.setStatus('A');
                service.FuncionarioService.Criar(funcionario);
            }else {
                //atualizacao
                funcionario.setId(Integer.parseInt(this.telaCadastroFuncionario.getjTextFieldID().getText()));
                service.FuncionarioService.Atualizar(funcionario);
            }
            
            
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), true);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), false);
            }
            
            
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonBuscar()) {
            codigo = 0;
            
            TelaBuscasFuncionario telaBuscasFuncionario = new TelaBuscasFuncionario(null, true);
        ControllerBuscasFuncionario controllerBuscasFuncionario = new ControllerBuscasFuncionario(telaBuscasFuncionario);
        telaBuscasFuncionario.setVisible(true);
        
        if(codigo != 0) {
            utilities.Utilities.ativaDesativa(this.telaCadastroFuncionario.getjPanel3(), false);
            utilities.Utilities.LimpaComponentes(this.telaCadastroFuncionario.getjPanel2(), true);
            
            this.telaCadastroFuncionario.getjTextFieldID().setText(codigo + "");
            this.telaCadastroFuncionario.getjTextFieldID().setEnabled(false);
            
            Funcionario funcionario = new Funcionario();
            funcionario = service.FuncionarioService.Carregar(codigo);
            
            this.telaCadastroFuncionario.getjFormattedCEP().setText(funcionario.getCep());
            this.telaCadastroFuncionario.getjComboBoxSexo().setSelectedItem(funcionario.getSexo());
            this.telaCadastroFuncionario.getjFormattedCPF().setText(funcionario.getCpf());
            this.telaCadastroFuncionario.getjFormattedDataCadastro().setText(funcionario.getDataCadastro());
            this.telaCadastroFuncionario.getjFormattedEmail().setText(funcionario.getEmail());
            this.telaCadastroFuncionario.getjFormattedFone1().setText(funcionario.getFone1());
            this.telaCadastroFuncionario.getjFormattedFone2().setText(funcionario.getFone2());
            this.telaCadastroFuncionario.getjTextBairro().setText(funcionario.getBairro());
            this.telaCadastroFuncionario.getjTextCidade().setText(funcionario.getCidade());
            this.telaCadastroFuncionario.getjTextComplemento().setText(funcionario.getComplemento());
            this.telaCadastroFuncionario.getjTextFieldNome().setText(funcionario.getNome());
            this.telaCadastroFuncionario.getjTextFieldRG().setText(funcionario.getRg());
            this.telaCadastroFuncionario.getjTextLogradouro().setText(funcionario.getLogradouro());
            this.telaCadastroFuncionario.getjTextObservacao().setText(funcionario.getObs());
            this.telaCadastroFuncionario.getjTextUsuario().setText(funcionario.getUsuario());
            this.telaCadastroFuncionario.getjPasswordSenha().setText(funcionario.getSenha());
            this.telaCadastroFuncionario.getjTextStatus().setText(String.valueOf(funcionario.getStatus()));
            // fazer o resto ---------------------------------------------------
            
                    
            this.telaCadastroFuncionario.getjTextFieldID().requestFocus();
        }
        
        } else if(evento.getSource() == this.telaCadastroFuncionario.getjButtonSair()) {
            this.telaCadastroFuncionario.dispose();
        }
    }
    
    
    
}
